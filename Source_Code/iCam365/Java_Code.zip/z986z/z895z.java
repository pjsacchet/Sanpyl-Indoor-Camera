package z986z;

/* loaded from: classes12.dex */
public abstract class z895z {

    /* loaded from: classes12.dex */
    public interface z235z {
        void onError(int i);

        void onWakeupAudio(byte[] bArr, int i, int i2, Object obj);

        void onWakeupMsg(int i, int i2, int i3, byte[] bArr, int i4, byte[] bArr2, int i5, byte[] bArr3, int i6);
    }

    /* renamed from: z986z.z895z$z895z, reason: collision with other inner class name */
    /* loaded from: classes12.dex */
    public interface InterfaceC5473z895z {
        void onError(int i);

        void onRecogAudio(byte[] bArr, int i, int i2, Object obj);
    }

    public static z895z a(String str) {
        return z743z.z895z.c(str);
    }

    public static z895z b() {
        return z743z.z895z.h();
    }

    public static int c() {
        return z743z.z895z.c();
    }

    public static String d() {
        return z743z.z895z.d();
    }

    public abstract int a(String str, String str2);

    public abstract int a(byte[] bArr, int i, int i2);

    public abstract void a();

    public abstract void a(z235z z235zVar);

    public abstract void a(InterfaceC5473z895z interfaceC5473z895z);

    public abstract void a(boolean z, int i);

    public abstract String b(String str);

    public abstract void b(z235z z235zVar);

    public abstract void b(InterfaceC5473z895z interfaceC5473z895z);

    public abstract int e();

    public abstract int f();

    public abstract void g();
}
