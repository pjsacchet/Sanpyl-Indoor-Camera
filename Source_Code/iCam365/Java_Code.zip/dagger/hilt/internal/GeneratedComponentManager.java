package dagger.hilt.internal;

/* loaded from: classes7.dex */
public interface GeneratedComponentManager<T> {
    T generatedComponent();
}
