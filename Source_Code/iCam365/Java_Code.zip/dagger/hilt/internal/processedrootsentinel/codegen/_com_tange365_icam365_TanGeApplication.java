package dagger.hilt.internal.processedrootsentinel.codegen;

import dagger.hilt.internal.processedrootsentinel.ProcessedRootSentinel;

@ProcessedRootSentinel(roots = {"com.tange365.icam365.TanGeApplication"})
/* loaded from: classes7.dex */
public final class _com_tange365_icam365_TanGeApplication {
}
