package dagger.hilt.internal;

/* loaded from: classes7.dex */
public final class UnsafeCasts {
    /* JADX WARN: Multi-variable type inference failed */
    public static <T> T unsafeCast(Object obj) {
        return obj;
    }
}
