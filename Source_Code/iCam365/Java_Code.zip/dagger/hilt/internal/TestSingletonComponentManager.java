package dagger.hilt.internal;

/* loaded from: classes7.dex */
public interface TestSingletonComponentManager extends GeneratedComponentManager<Object> {
    Object earlySingletonComponent();
}
