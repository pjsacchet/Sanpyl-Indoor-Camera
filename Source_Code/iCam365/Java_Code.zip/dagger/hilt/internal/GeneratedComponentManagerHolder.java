package dagger.hilt.internal;

/* loaded from: classes7.dex */
public interface GeneratedComponentManagerHolder extends GeneratedComponentManager<Object> {
    GeneratedComponentManager<?> componentManager();
}
