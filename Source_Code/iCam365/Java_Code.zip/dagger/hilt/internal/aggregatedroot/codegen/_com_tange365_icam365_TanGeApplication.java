package dagger.hilt.internal.aggregatedroot.codegen;

import com.tange365.icam365.BuildConfig;
import com.tange365.icam365.TanGeApplication;
import dagger.hilt.android.HiltAndroidApp;
import dagger.hilt.internal.aggregatedroot.AggregatedRoot;

@AggregatedRoot(originatingRoot = "com.tange365.icam365.TanGeApplication", originatingRootPackage = BuildConfig.APPLICATION_ID, originatingRootSimpleNames = {TanGeApplication.f10524}, root = "com.tange365.icam365.TanGeApplication", rootAnnotation = HiltAndroidApp.class, rootPackage = BuildConfig.APPLICATION_ID, rootSimpleNames = {TanGeApplication.f10524})
/* loaded from: classes7.dex */
public class _com_tange365_icam365_TanGeApplication {
}
