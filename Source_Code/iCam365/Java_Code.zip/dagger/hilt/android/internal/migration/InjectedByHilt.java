package dagger.hilt.android.internal.migration;

/* loaded from: classes7.dex */
public interface InjectedByHilt {
    boolean wasInjectedByHilt();
}
