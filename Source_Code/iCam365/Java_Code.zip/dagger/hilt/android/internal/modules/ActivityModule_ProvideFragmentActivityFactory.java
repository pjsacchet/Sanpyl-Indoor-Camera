package dagger.hilt.android.internal.modules;

import android.app.Activity;
import androidx.fragment.app.FragmentActivity;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;
import p133.AbstractC6657;

@ScopeMetadata("dagger.Reusable")
@DaggerGenerated
@QualifierMetadata
/* loaded from: classes7.dex */
public final class ActivityModule_ProvideFragmentActivityFactory implements Factory<FragmentActivity> {

    /* renamed from: 㫞, reason: contains not printable characters */
    public final Provider<Activity> f18804;

    public ActivityModule_ProvideFragmentActivityFactory(Provider<Activity> activityProvider) {
        this.f18804 = activityProvider;
    }

    public static ActivityModule_ProvideFragmentActivityFactory create(Provider<Activity> activityProvider) {
        return new ActivityModule_ProvideFragmentActivityFactory(activityProvider);
    }

    public static FragmentActivity provideFragmentActivity(Activity activity) {
        return (FragmentActivity) Preconditions.checkNotNullFromProvides(AbstractC6657.m18648(activity));
    }

    @Override // javax.inject.Provider
    public FragmentActivity get() {
        return provideFragmentActivity(this.f18804.get());
    }
}
