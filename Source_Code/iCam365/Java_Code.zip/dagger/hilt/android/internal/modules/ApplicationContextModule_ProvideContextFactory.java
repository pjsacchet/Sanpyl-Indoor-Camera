package dagger.hilt.android.internal.modules;

import android.content.Context;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata
@DaggerGenerated
@QualifierMetadata({"dagger.hilt.android.qualifiers.ApplicationContext"})
/* loaded from: classes7.dex */
public final class ApplicationContextModule_ProvideContextFactory implements Factory<Context> {

    /* renamed from: 㫞, reason: contains not printable characters */
    public final ApplicationContextModule f18807;

    public ApplicationContextModule_ProvideContextFactory(ApplicationContextModule module) {
        this.f18807 = module;
    }

    public static ApplicationContextModule_ProvideContextFactory create(ApplicationContextModule module) {
        return new ApplicationContextModule_ProvideContextFactory(module);
    }

    public static Context provideContext(ApplicationContextModule instance) {
        return (Context) Preconditions.checkNotNullFromProvides(instance.provideContext());
    }

    @Override // javax.inject.Provider
    public Context get() {
        return provideContext(this.f18807);
    }
}
