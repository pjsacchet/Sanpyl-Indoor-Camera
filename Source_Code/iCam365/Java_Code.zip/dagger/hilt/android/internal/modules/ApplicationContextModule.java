package dagger.hilt.android.internal.modules;

import android.app.Application;
import android.content.Context;
import dagger.Module;
import dagger.Provides;
import dagger.hilt.InstallIn;
import dagger.hilt.android.internal.Contexts;
import dagger.hilt.android.qualifiers.ApplicationContext;
import dagger.hilt.components.SingletonComponent;

@Module
@InstallIn({SingletonComponent.class})
/* loaded from: classes7.dex */
public final class ApplicationContextModule {

    /* renamed from: 㫞, reason: contains not printable characters */
    public final Context f18805;

    public ApplicationContextModule(Context applicationContext) {
        this.f18805 = applicationContext;
    }

    @Provides
    public Application provideApplication() {
        return Contexts.getApplication(this.f18805);
    }

    @Provides
    @ApplicationContext
    public Context provideContext() {
        return this.f18805;
    }
}
