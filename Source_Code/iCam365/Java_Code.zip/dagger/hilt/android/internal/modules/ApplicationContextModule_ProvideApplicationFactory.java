package dagger.hilt.android.internal.modules;

import android.app.Application;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@ScopeMetadata
@DaggerGenerated
@QualifierMetadata
/* loaded from: classes7.dex */
public final class ApplicationContextModule_ProvideApplicationFactory implements Factory<Application> {

    /* renamed from: 㫞, reason: contains not printable characters */
    public final ApplicationContextModule f18806;

    public ApplicationContextModule_ProvideApplicationFactory(ApplicationContextModule module) {
        this.f18806 = module;
    }

    public static ApplicationContextModule_ProvideApplicationFactory create(ApplicationContextModule module) {
        return new ApplicationContextModule_ProvideApplicationFactory(module);
    }

    public static Application provideApplication(ApplicationContextModule instance) {
        return (Application) Preconditions.checkNotNullFromProvides(instance.provideApplication());
    }

    @Override // javax.inject.Provider
    public Application get() {
        return provideApplication(this.f18806);
    }
}
