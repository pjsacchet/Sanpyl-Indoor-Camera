package dagger.hilt.android.internal.modules;

import dagger.Module;
import dagger.hilt.InstallIn;
import dagger.hilt.android.components.ActivityComponent;
import dagger.hilt.codegen.OriginatingElement;
import p133.AbstractC6657;

@OriginatingElement(topLevelClass = AbstractC6657.class)
@Module(includes = {AbstractC6657.class})
@InstallIn({ActivityComponent.class})
/* loaded from: classes7.dex */
public final class HiltWrapper_ActivityModule {
}
