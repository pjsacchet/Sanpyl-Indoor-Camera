package dagger.hilt.android.internal.lifecycle;

import android.os.Bundle;
import androidx.activity.ComponentActivity;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.savedstate.SavedStateRegistryOwner;
import dagger.Module;
import dagger.hilt.EntryPoint;
import dagger.hilt.EntryPoints;
import dagger.hilt.InstallIn;
import dagger.hilt.android.components.ActivityComponent;
import dagger.hilt.android.components.FragmentComponent;
import dagger.hilt.android.internal.builders.ViewModelComponentBuilder;
import dagger.hilt.android.internal.lifecycle.HiltViewModelMap;
import dagger.hilt.internal.Preconditions;
import dagger.multibindings.Multibinds;
import java.util.Set;
import javax.inject.Inject;

/* loaded from: classes7.dex */
public final class DefaultViewModelFactories {

    @EntryPoint
    @InstallIn({ActivityComponent.class})
    /* loaded from: classes7.dex */
    public interface ActivityEntryPoint {
        InternalFactoryFactory getHiltInternalFactoryFactory();
    }

    @EntryPoint
    @InstallIn({FragmentComponent.class})
    /* loaded from: classes7.dex */
    public interface FragmentEntryPoint {
        InternalFactoryFactory getHiltInternalFactoryFactory();
    }

    /* loaded from: classes7.dex */
    public static final class InternalFactoryFactory {

        /* renamed from: ᇰ, reason: contains not printable characters */
        public final ViewModelComponentBuilder f18765;

        /* renamed from: 㫞, reason: contains not printable characters */
        public final Set<String> f18766;

        @Inject
        public InternalFactoryFactory(@HiltViewModelMap.KeySet Set<String> keySet, ViewModelComponentBuilder viewModelComponentBuilder) {
            this.f18766 = keySet;
            this.f18765 = viewModelComponentBuilder;
        }

        public ViewModelProvider.Factory fromActivity(ComponentActivity activity, ViewModelProvider.Factory delegateFactory) {
            Bundle bundle;
            if (activity.getIntent() != null) {
                bundle = activity.getIntent().getExtras();
            } else {
                bundle = null;
            }
            return m12363(activity, bundle, delegateFactory);
        }

        public ViewModelProvider.Factory fromFragment(Fragment fragment, ViewModelProvider.Factory delegateFactory) {
            return m12363(fragment, fragment.getArguments(), delegateFactory);
        }

        /* renamed from: 㫞, reason: contains not printable characters */
        public final ViewModelProvider.Factory m12363(SavedStateRegistryOwner owner, @Nullable Bundle defaultArgs, ViewModelProvider.Factory delegate) {
            return new HiltViewModelFactory(owner, defaultArgs, this.f18766, (ViewModelProvider.Factory) Preconditions.checkNotNull(delegate), this.f18765);
        }
    }

    @Module
    @InstallIn({ActivityComponent.class})
    /* renamed from: dagger.hilt.android.internal.lifecycle.DefaultViewModelFactories$㫞, reason: contains not printable characters */
    /* loaded from: classes7.dex */
    public interface InterfaceC4771 {
        @HiltViewModelMap.KeySet
        @Multibinds
        /* renamed from: 㫞, reason: contains not printable characters */
        Set<String> m12364();
    }

    public static ViewModelProvider.Factory getActivityFactory(ComponentActivity activity, ViewModelProvider.Factory delegateFactory) {
        return ((ActivityEntryPoint) EntryPoints.get(activity, ActivityEntryPoint.class)).getHiltInternalFactoryFactory().fromActivity(activity, delegateFactory);
    }

    public static ViewModelProvider.Factory getFragmentFactory(Fragment fragment, ViewModelProvider.Factory delegateFactory) {
        return ((FragmentEntryPoint) EntryPoints.get(fragment, FragmentEntryPoint.class)).getHiltInternalFactoryFactory().fromFragment(fragment, delegateFactory);
    }
}
