package dagger.hilt.android.internal.lifecycle;

import androidx.annotation.NonNull;
import dagger.hilt.android.ActivityRetainedLifecycle;
import dagger.hilt.android.ViewModelLifecycle;
import dagger.hilt.android.internal.ThreadUtil;
import dagger.hilt.android.lifecycle.RetainedLifecycle;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/* loaded from: classes7.dex */
public final class RetainedLifecycleImpl implements ActivityRetainedLifecycle, ViewModelLifecycle {

    /* renamed from: 㫞, reason: contains not printable characters */
    public final Set<RetainedLifecycle.OnClearedListener> f18775 = new HashSet();

    /* renamed from: ᇰ, reason: contains not printable characters */
    public boolean f18774 = false;

    @Override // dagger.hilt.android.lifecycle.RetainedLifecycle
    public void addOnClearedListener(@NonNull RetainedLifecycle.OnClearedListener listener) {
        ThreadUtil.ensureMainThread();
        m12366();
        this.f18775.add(listener);
    }

    public void dispatchOnCleared() {
        ThreadUtil.ensureMainThread();
        this.f18774 = true;
        Iterator<RetainedLifecycle.OnClearedListener> it = this.f18775.iterator();
        while (it.hasNext()) {
            it.next().onCleared();
        }
    }

    @Override // dagger.hilt.android.lifecycle.RetainedLifecycle
    public void removeOnClearedListener(@NonNull RetainedLifecycle.OnClearedListener listener) {
        ThreadUtil.ensureMainThread();
        m12366();
        this.f18775.remove(listener);
    }

    /* renamed from: 㫞, reason: contains not printable characters */
    public final void m12366() {
        if (!this.f18774) {
        } else {
            throw new IllegalStateException("There was a race between the call to add/remove an OnClearedListener and onCleared(). This can happen when posting to the Main thread from a background thread, which is not supported.");
        }
    }
}
