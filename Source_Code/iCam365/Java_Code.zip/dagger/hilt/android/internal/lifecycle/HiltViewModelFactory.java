package dagger.hilt.android.internal.lifecycle;

import android.app.Activity;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.AbstractSavedStateViewModelFactory;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.savedstate.SavedStateRegistryOwner;
import dagger.Module;
import dagger.hilt.EntryPoint;
import dagger.hilt.EntryPoints;
import dagger.hilt.InstallIn;
import dagger.hilt.android.components.ActivityComponent;
import dagger.hilt.android.components.ViewModelComponent;
import dagger.hilt.android.internal.builders.ViewModelComponentBuilder;
import dagger.hilt.android.internal.lifecycle.HiltViewModelMap;
import dagger.multibindings.Multibinds;
import java.io.Closeable;
import java.util.Map;
import java.util.Set;
import javax.inject.Provider;

/* loaded from: classes7.dex */
public final class HiltViewModelFactory implements ViewModelProvider.Factory {

    /* renamed from: ᇰ, reason: contains not printable characters */
    public final ViewModelProvider.Factory f18769;

    /* renamed from: 㫞, reason: contains not printable characters */
    public final Set<String> f18770;

    /* renamed from: 㫿, reason: contains not printable characters */
    public final AbstractSavedStateViewModelFactory f18771;

    @EntryPoint
    @InstallIn({ViewModelComponent.class})
    /* loaded from: classes7.dex */
    public interface ViewModelFactoriesEntryPoint {
        @HiltViewModelMap
        Map<String, Provider<ViewModel>> getHiltViewModelMap();
    }

    @EntryPoint
    @InstallIn({ActivityComponent.class})
    /* renamed from: dagger.hilt.android.internal.lifecycle.HiltViewModelFactory$ᇰ, reason: contains not printable characters */
    /* loaded from: classes7.dex */
    public interface InterfaceC4772 {
        /* renamed from: ᇰ */
        ViewModelComponentBuilder mo6080();

        @HiltViewModelMap.KeySet
        /* renamed from: 㫞 */
        Set<String> mo6087();
    }

    /* renamed from: dagger.hilt.android.internal.lifecycle.HiltViewModelFactory$㫞, reason: contains not printable characters */
    /* loaded from: classes7.dex */
    public class C4773 extends AbstractSavedStateViewModelFactory {

        /* renamed from: 㫞, reason: contains not printable characters */
        public final /* synthetic */ ViewModelComponentBuilder f18773;

        public C4773(final ViewModelComponentBuilder val$viewModelComponentBuilder) {
            this.f18773 = val$viewModelComponentBuilder;
        }

        @Override // androidx.lifecycle.AbstractSavedStateViewModelFactory
        @NonNull
        public <T extends ViewModel> T create(@NonNull String key, @NonNull Class<T> modelClass, @NonNull SavedStateHandle handle) {
            final RetainedLifecycleImpl retainedLifecycleImpl = new RetainedLifecycleImpl();
            Provider<ViewModel> provider = ((ViewModelFactoriesEntryPoint) EntryPoints.get(this.f18773.savedStateHandle(handle).viewModelLifecycle(retainedLifecycleImpl).build(), ViewModelFactoriesEntryPoint.class)).getHiltViewModelMap().get(modelClass.getName());
            if (provider != null) {
                T t = (T) provider.get();
                t.addCloseable(new Closeable() { // from class: dagger.hilt.android.internal.lifecycle.㫞
                    @Override // java.io.Closeable, java.lang.AutoCloseable
                    public final void close() {
                        RetainedLifecycleImpl.this.dispatchOnCleared();
                    }
                });
                return t;
            }
            throw new IllegalStateException("Expected the @HiltViewModel-annotated class '" + modelClass.getName() + "' to be available in the multi-binding of @HiltViewModelMap but none was found.");
        }
    }

    @Module
    @InstallIn({ViewModelComponent.class})
    /* renamed from: dagger.hilt.android.internal.lifecycle.HiltViewModelFactory$㫿, reason: contains not printable characters */
    /* loaded from: classes7.dex */
    public interface InterfaceC4774 {
        @HiltViewModelMap
        @Multibinds
        /* renamed from: 㫞, reason: contains not printable characters */
        Map<String, ViewModel> m12365();
    }

    public HiltViewModelFactory(@NonNull SavedStateRegistryOwner owner, @Nullable Bundle defaultArgs, @NonNull Set<String> hiltViewModelKeys, @NonNull ViewModelProvider.Factory delegateFactory, @NonNull ViewModelComponentBuilder viewModelComponentBuilder) {
        this.f18770 = hiltViewModelKeys;
        this.f18769 = delegateFactory;
        this.f18771 = new C4773(viewModelComponentBuilder);
    }

    public static ViewModelProvider.Factory createInternal(@NonNull Activity activity, @NonNull SavedStateRegistryOwner owner, @Nullable Bundle defaultArgs, @NonNull ViewModelProvider.Factory delegateFactory) {
        InterfaceC4772 interfaceC4772 = (InterfaceC4772) EntryPoints.get(activity, InterfaceC4772.class);
        return new HiltViewModelFactory(owner, defaultArgs, interfaceC4772.mo6087(), delegateFactory, interfaceC4772.mo6080());
    }

    @Override // androidx.lifecycle.ViewModelProvider.Factory
    @NonNull
    public <T extends ViewModel> T create(@NonNull Class<T> cls, @NonNull CreationExtras creationExtras) {
        if (this.f18770.contains(cls.getName())) {
            return (T) this.f18771.create(cls, creationExtras);
        }
        return (T) this.f18769.create(cls, creationExtras);
    }

    @Override // androidx.lifecycle.ViewModelProvider.Factory
    @NonNull
    public <T extends ViewModel> T create(@NonNull Class<T> cls) {
        if (this.f18770.contains(cls.getName())) {
            return (T) this.f18771.create(cls);
        }
        return (T) this.f18769.create(cls);
    }
}
