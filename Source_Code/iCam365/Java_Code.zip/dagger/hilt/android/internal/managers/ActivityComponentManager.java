package dagger.hilt.android.internal.managers;

import android.app.Activity;
import android.app.Application;
import androidx.activity.ComponentActivity;
import dagger.hilt.EntryPoint;
import dagger.hilt.EntryPoints;
import dagger.hilt.InstallIn;
import dagger.hilt.android.components.ActivityRetainedComponent;
import dagger.hilt.android.internal.builders.ActivityComponentBuilder;
import dagger.hilt.internal.GeneratedComponentManager;

/* loaded from: classes7.dex */
public class ActivityComponentManager implements GeneratedComponentManager<Object> {
    public final Activity activity;

    /* renamed from: ᇰ, reason: contains not printable characters */
    public final Object f18777 = new Object();

    /* renamed from: 㫞, reason: contains not printable characters */
    public volatile Object f18778;

    /* renamed from: 㫿, reason: contains not printable characters */
    public final GeneratedComponentManager<ActivityRetainedComponent> f18779;

    @EntryPoint
    @InstallIn({ActivityRetainedComponent.class})
    /* loaded from: classes7.dex */
    public interface ActivityComponentBuilderEntryPoint {
        ActivityComponentBuilder activityComponentBuilder();
    }

    public ActivityComponentManager(Activity activity) {
        this.activity = activity;
        this.f18779 = new ActivityRetainedComponentManager((ComponentActivity) activity);
    }

    public Object createComponent() {
        if (!(this.activity.getApplication() instanceof GeneratedComponentManager)) {
            if (Application.class.equals(this.activity.getApplication().getClass())) {
                throw new IllegalStateException("Hilt Activity must be attached to an @HiltAndroidApp Application. Did you forget to specify your Application's class name in your manifest's <application />'s android:name attribute?");
            }
            throw new IllegalStateException("Hilt Activity must be attached to an @AndroidEntryPoint Application. Found: " + this.activity.getApplication().getClass());
        }
        return ((ActivityComponentBuilderEntryPoint) EntryPoints.get(this.f18779, ActivityComponentBuilderEntryPoint.class)).activityComponentBuilder().activity(this.activity).build();
    }

    @Override // dagger.hilt.internal.GeneratedComponentManager
    public Object generatedComponent() {
        if (this.f18778 == null) {
            synchronized (this.f18777) {
                if (this.f18778 == null) {
                    this.f18778 = createComponent();
                }
            }
        }
        return this.f18778;
    }
}
