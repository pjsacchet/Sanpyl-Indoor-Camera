package dagger.hilt.android.internal.managers;

import android.content.Context;
import androidx.activity.ComponentActivity;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;
import dagger.Module;
import dagger.Provides;
import dagger.hilt.EntryPoint;
import dagger.hilt.EntryPoints;
import dagger.hilt.InstallIn;
import dagger.hilt.android.ActivityRetainedLifecycle;
import dagger.hilt.android.EntryPointAccessors;
import dagger.hilt.android.components.ActivityRetainedComponent;
import dagger.hilt.android.internal.builders.ActivityRetainedComponentBuilder;
import dagger.hilt.android.internal.lifecycle.RetainedLifecycleImpl;
import dagger.hilt.android.scopes.ActivityRetainedScoped;
import dagger.hilt.components.SingletonComponent;
import dagger.hilt.internal.GeneratedComponentManager;

/* loaded from: classes7.dex */
public final class ActivityRetainedComponentManager implements GeneratedComponentManager<ActivityRetainedComponent> {

    /* renamed from: ᇰ, reason: contains not printable characters */
    @Nullable
    public volatile ActivityRetainedComponent f18780;

    /* renamed from: 㫞, reason: contains not printable characters */
    public final ViewModelProvider f18781;

    /* renamed from: 㫿, reason: contains not printable characters */
    public final Object f18782 = new Object();

    @EntryPoint
    @InstallIn({SingletonComponent.class})
    /* loaded from: classes7.dex */
    public interface ActivityRetainedComponentBuilderEntryPoint {
        ActivityRetainedComponentBuilder retainedComponentBuilder();
    }

    @EntryPoint
    @InstallIn({ActivityRetainedComponent.class})
    /* loaded from: classes7.dex */
    public interface ActivityRetainedLifecycleEntryPoint {
        ActivityRetainedLifecycle getActivityRetainedLifecycle();
    }

    /* renamed from: dagger.hilt.android.internal.managers.ActivityRetainedComponentManager$ᇰ, reason: contains not printable characters */
    /* loaded from: classes7.dex */
    public static final class C4776 extends ViewModel {

        /* renamed from: 㫞, reason: contains not printable characters */
        public final ActivityRetainedComponent f18783;

        public C4776(ActivityRetainedComponent component) {
            this.f18783 = component;
        }

        @Override // androidx.lifecycle.ViewModel
        public void onCleared() {
            super.onCleared();
            ((RetainedLifecycleImpl) ((ActivityRetainedLifecycleEntryPoint) EntryPoints.get(this.f18783, ActivityRetainedLifecycleEntryPoint.class)).getActivityRetainedLifecycle()).dispatchOnCleared();
        }

        /* renamed from: 㫞, reason: contains not printable characters */
        public ActivityRetainedComponent m12370() {
            return this.f18783;
        }
    }

    /* renamed from: dagger.hilt.android.internal.managers.ActivityRetainedComponentManager$㫞, reason: contains not printable characters */
    /* loaded from: classes7.dex */
    public class C4777 implements ViewModelProvider.Factory {

        /* renamed from: 㫞, reason: contains not printable characters */
        public final /* synthetic */ Context f18785;

        public C4777(final Context val$context) {
            this.f18785 = val$context;
        }

        @Override // androidx.lifecycle.ViewModelProvider.Factory
        @NonNull
        public <T extends ViewModel> T create(@NonNull Class<T> aClass) {
            return new C4776(((ActivityRetainedComponentBuilderEntryPoint) EntryPointAccessors.fromApplication(this.f18785, ActivityRetainedComponentBuilderEntryPoint.class)).retainedComponentBuilder().build());
        }
    }

    @Module
    @InstallIn({ActivityRetainedComponent.class})
    /* renamed from: dagger.hilt.android.internal.managers.ActivityRetainedComponentManager$㫿, reason: contains not printable characters */
    /* loaded from: classes7.dex */
    public static abstract class AbstractC4778 {
        @Provides
        @ActivityRetainedScoped
        /* renamed from: 㫞, reason: contains not printable characters */
        public static ActivityRetainedLifecycle m12371() {
            return new RetainedLifecycleImpl();
        }
    }

    public ActivityRetainedComponentManager(ComponentActivity activity) {
        this.f18781 = m12369(activity, activity);
    }

    @Override // dagger.hilt.internal.GeneratedComponentManager
    /* renamed from: ᇰ, reason: contains not printable characters and merged with bridge method [inline-methods] */
    public ActivityRetainedComponent generatedComponent() {
        if (this.f18780 == null) {
            synchronized (this.f18782) {
                if (this.f18780 == null) {
                    this.f18780 = m12368();
                }
            }
        }
        return this.f18780;
    }

    /* renamed from: 㫞, reason: contains not printable characters */
    public final ActivityRetainedComponent m12368() {
        return ((C4776) this.f18781.get(C4776.class)).m12370();
    }

    /* renamed from: 㫿, reason: contains not printable characters */
    public final ViewModelProvider m12369(ViewModelStoreOwner owner, Context context) {
        return new ViewModelProvider(owner, new C4777(context));
    }
}
