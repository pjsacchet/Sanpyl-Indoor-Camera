package dagger.hilt.android.internal.managers;

/* loaded from: classes7.dex */
public interface ComponentSupplier {
    Object get();
}
