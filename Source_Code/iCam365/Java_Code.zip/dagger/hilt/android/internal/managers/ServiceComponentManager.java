package dagger.hilt.android.internal.managers;

import android.app.Application;
import android.app.Service;
import dagger.hilt.EntryPoint;
import dagger.hilt.EntryPoints;
import dagger.hilt.InstallIn;
import dagger.hilt.android.internal.builders.ServiceComponentBuilder;
import dagger.hilt.components.SingletonComponent;
import dagger.hilt.internal.GeneratedComponentManager;
import dagger.hilt.internal.Preconditions;

/* loaded from: classes7.dex */
public final class ServiceComponentManager implements GeneratedComponentManager<Object> {

    /* renamed from: ᇰ, reason: contains not printable characters */
    public Object f18793;

    /* renamed from: 㫞, reason: contains not printable characters */
    public final Service f18794;

    @EntryPoint
    @InstallIn({SingletonComponent.class})
    /* loaded from: classes7.dex */
    public interface ServiceComponentBuilderEntryPoint {
        ServiceComponentBuilder serviceComponentBuilder();
    }

    public ServiceComponentManager(Service service) {
        this.f18794 = service;
    }

    @Override // dagger.hilt.internal.GeneratedComponentManager
    public Object generatedComponent() {
        if (this.f18793 == null) {
            this.f18793 = m12374();
        }
        return this.f18793;
    }

    /* renamed from: 㫞, reason: contains not printable characters */
    public final Object m12374() {
        Application application = this.f18794.getApplication();
        Preconditions.checkState(application instanceof GeneratedComponentManager, "Hilt service must be attached to an @AndroidEntryPoint Application. Found: %s", application.getClass());
        return ((ServiceComponentBuilderEntryPoint) EntryPoints.get(application, ServiceComponentBuilderEntryPoint.class)).serviceComponentBuilder().service(this.f18794).build();
    }
}
