package dagger.hilt.android.internal.managers;

import android.content.Context;
import android.content.ContextWrapper;
import android.view.LayoutInflater;
import android.view.View;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleOwner;
import dagger.hilt.EntryPoint;
import dagger.hilt.EntryPoints;
import dagger.hilt.InstallIn;
import dagger.hilt.android.components.ActivityComponent;
import dagger.hilt.android.components.FragmentComponent;
import dagger.hilt.android.internal.Contexts;
import dagger.hilt.android.internal.builders.ViewComponentBuilder;
import dagger.hilt.android.internal.builders.ViewWithFragmentComponentBuilder;
import dagger.hilt.internal.GeneratedComponentManager;
import dagger.hilt.internal.Preconditions;

/* loaded from: classes7.dex */
public final class ViewComponentManager implements GeneratedComponentManager<Object> {

    /* renamed from: ᇰ, reason: contains not printable characters */
    public final Object f18795 = new Object();

    /* renamed from: 㫞, reason: contains not printable characters */
    public volatile Object f18796;

    /* renamed from: 㫿, reason: contains not printable characters */
    public final boolean f18797;

    /* renamed from: 㯿, reason: contains not printable characters */
    public final View f18798;

    @EntryPoint
    @InstallIn({ActivityComponent.class})
    /* loaded from: classes7.dex */
    public interface ViewComponentBuilderEntryPoint {
        ViewComponentBuilder viewComponentBuilder();
    }

    @EntryPoint
    @InstallIn({FragmentComponent.class})
    /* loaded from: classes7.dex */
    public interface ViewWithFragmentComponentBuilderEntryPoint {
        ViewWithFragmentComponentBuilder viewWithFragmentComponentBuilder();
    }

    public ViewComponentManager(View view, boolean hasFragmentBindings) {
        this.f18798 = view;
        this.f18797 = hasFragmentBindings;
    }

    /* renamed from: 㯿, reason: contains not printable characters */
    public static Context m12375(Context context, Class<?> target) {
        while ((context instanceof ContextWrapper) && !target.isInstance(context)) {
            context = ((ContextWrapper) context).getBaseContext();
        }
        return context;
    }

    @Override // dagger.hilt.internal.GeneratedComponentManager
    public Object generatedComponent() {
        if (this.f18796 == null) {
            synchronized (this.f18795) {
                if (this.f18796 == null) {
                    this.f18796 = m12377();
                }
            }
        }
        return this.f18796;
    }

    public GeneratedComponentManager<?> maybeGetParentComponentManager() {
        return m12376(true);
    }

    /* renamed from: ᇰ, reason: contains not printable characters */
    public final GeneratedComponentManager<?> m12376(boolean allowMissing) {
        if (this.f18797) {
            Context m12378 = m12378(FragmentContextWrapper.class, allowMissing);
            if (m12378 instanceof FragmentContextWrapper) {
                return (GeneratedComponentManager) ((FragmentContextWrapper) m12378).getFragment();
            }
            if (allowMissing) {
                return null;
            }
            Preconditions.checkState(!(r7 instanceof GeneratedComponentManager), "%s, @WithFragmentBindings Hilt view must be attached to an @AndroidEntryPoint Fragment. Was attached to context %s", this.f18798.getClass(), m12378(GeneratedComponentManager.class, allowMissing).getClass().getName());
        } else {
            Object m123782 = m12378(GeneratedComponentManager.class, allowMissing);
            if (m123782 instanceof GeneratedComponentManager) {
                return (GeneratedComponentManager) m123782;
            }
            if (allowMissing) {
                return null;
            }
        }
        throw new IllegalStateException(String.format("%s, Hilt view must be attached to an @AndroidEntryPoint Fragment or Activity.", this.f18798.getClass()));
    }

    /* renamed from: 㫞, reason: contains not printable characters */
    public final Object m12377() {
        GeneratedComponentManager<?> m12376 = m12376(false);
        if (this.f18797) {
            return ((ViewWithFragmentComponentBuilderEntryPoint) EntryPoints.get(m12376, ViewWithFragmentComponentBuilderEntryPoint.class)).viewWithFragmentComponentBuilder().view(this.f18798).build();
        }
        return ((ViewComponentBuilderEntryPoint) EntryPoints.get(m12376, ViewComponentBuilderEntryPoint.class)).viewComponentBuilder().view(this.f18798).build();
    }

    /* renamed from: 㫿, reason: contains not printable characters */
    public final Context m12378(Class<?> parentType, boolean allowMissing) {
        Context m12375 = m12375(this.f18798.getContext(), parentType);
        if (m12375 == Contexts.getApplication(m12375.getApplicationContext())) {
            Preconditions.checkState(allowMissing, "%s, Hilt view cannot be created using the application context. Use a Hilt Fragment or Activity context.", this.f18798.getClass());
            return null;
        }
        return m12375;
    }

    /* loaded from: classes7.dex */
    public static final class FragmentContextWrapper extends ContextWrapper {

        /* renamed from: ᇰ, reason: contains not printable characters */
        public LayoutInflater f18799;

        /* renamed from: 㫞, reason: contains not printable characters */
        public Fragment f18800;

        /* renamed from: 㫿, reason: contains not printable characters */
        public LayoutInflater f18801;

        /* renamed from: 㯿, reason: contains not printable characters */
        public final LifecycleEventObserver f18802;

        public FragmentContextWrapper(Context base, Fragment fragment) {
            super((Context) Preconditions.checkNotNull(base));
            LifecycleEventObserver lifecycleEventObserver = new LifecycleEventObserver() { // from class: dagger.hilt.android.internal.managers.ViewComponentManager.FragmentContextWrapper.1
                @Override // androidx.lifecycle.LifecycleEventObserver
                public void onStateChanged(LifecycleOwner source, Lifecycle.Event event) {
                    if (event == Lifecycle.Event.ON_DESTROY) {
                        FragmentContextWrapper.this.f18800 = null;
                        FragmentContextWrapper.this.f18799 = null;
                        FragmentContextWrapper.this.f18801 = null;
                    }
                }
            };
            this.f18802 = lifecycleEventObserver;
            this.f18799 = null;
            Fragment fragment2 = (Fragment) Preconditions.checkNotNull(fragment);
            this.f18800 = fragment2;
            fragment2.getLifecycle().addObserver(lifecycleEventObserver);
        }

        public Fragment getFragment() {
            Preconditions.checkNotNull(this.f18800, "The fragment has already been destroyed.");
            return this.f18800;
        }

        @Override // android.content.ContextWrapper, android.content.Context
        public Object getSystemService(String name) {
            if (!"layout_inflater".equals(name)) {
                return getBaseContext().getSystemService(name);
            }
            if (this.f18801 == null) {
                if (this.f18799 == null) {
                    this.f18799 = (LayoutInflater) getBaseContext().getSystemService("layout_inflater");
                }
                this.f18801 = this.f18799.cloneInContext(this);
            }
            return this.f18801;
        }

        public FragmentContextWrapper(LayoutInflater baseInflater, Fragment fragment) {
            super((Context) Preconditions.checkNotNull(((LayoutInflater) Preconditions.checkNotNull(baseInflater)).getContext()));
            LifecycleEventObserver lifecycleEventObserver = new LifecycleEventObserver() { // from class: dagger.hilt.android.internal.managers.ViewComponentManager.FragmentContextWrapper.1
                @Override // androidx.lifecycle.LifecycleEventObserver
                public void onStateChanged(LifecycleOwner source, Lifecycle.Event event) {
                    if (event == Lifecycle.Event.ON_DESTROY) {
                        FragmentContextWrapper.this.f18800 = null;
                        FragmentContextWrapper.this.f18799 = null;
                        FragmentContextWrapper.this.f18801 = null;
                    }
                }
            };
            this.f18802 = lifecycleEventObserver;
            this.f18799 = baseInflater;
            Fragment fragment2 = (Fragment) Preconditions.checkNotNull(fragment);
            this.f18800 = fragment2;
            fragment2.getLifecycle().addObserver(lifecycleEventObserver);
        }
    }
}
