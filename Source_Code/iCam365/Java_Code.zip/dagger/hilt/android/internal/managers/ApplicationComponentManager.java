package dagger.hilt.android.internal.managers;

import dagger.hilt.internal.GeneratedComponentManager;

/* loaded from: classes7.dex */
public final class ApplicationComponentManager implements GeneratedComponentManager<Object> {

    /* renamed from: ᇰ, reason: contains not printable characters */
    public final Object f18787 = new Object();

    /* renamed from: 㫞, reason: contains not printable characters */
    public volatile Object f18788;

    /* renamed from: 㫿, reason: contains not printable characters */
    public final ComponentSupplier f18789;

    public ApplicationComponentManager(ComponentSupplier componentCreator) {
        this.f18789 = componentCreator;
    }

    @Override // dagger.hilt.internal.GeneratedComponentManager
    public Object generatedComponent() {
        if (this.f18788 == null) {
            synchronized (this.f18787) {
                if (this.f18788 == null) {
                    this.f18788 = this.f18789.get();
                }
            }
        }
        return this.f18788;
    }
}
