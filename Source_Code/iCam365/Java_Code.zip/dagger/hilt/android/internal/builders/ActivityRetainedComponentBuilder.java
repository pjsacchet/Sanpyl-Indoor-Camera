package dagger.hilt.android.internal.builders;

import dagger.hilt.DefineComponent;
import dagger.hilt.android.components.ActivityRetainedComponent;

@DefineComponent.Builder
/* loaded from: classes7.dex */
public interface ActivityRetainedComponentBuilder {
    ActivityRetainedComponent build();
}
