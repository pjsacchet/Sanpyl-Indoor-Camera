package dagger.hilt.android.internal;

import android.os.Looper;

/* loaded from: classes7.dex */
public final class ThreadUtil {

    /* renamed from: 㫞, reason: contains not printable characters */
    public static Thread f18764;

    public static void ensureMainThread() {
        if (isMainThread()) {
        } else {
            throw new IllegalStateException("Must be called on the Main thread.");
        }
    }

    public static boolean isMainThread() {
        if (f18764 == null) {
            f18764 = Looper.getMainLooper().getThread();
        }
        if (Thread.currentThread() == f18764) {
            return true;
        }
        return false;
    }
}
