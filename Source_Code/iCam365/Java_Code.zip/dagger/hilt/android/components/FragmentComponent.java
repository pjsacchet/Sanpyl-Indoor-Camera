package dagger.hilt.android.components;

import dagger.hilt.DefineComponent;
import dagger.hilt.android.scopes.FragmentScoped;

@FragmentScoped
@DefineComponent(parent = ActivityComponent.class)
/* loaded from: classes7.dex */
public interface FragmentComponent {
}
