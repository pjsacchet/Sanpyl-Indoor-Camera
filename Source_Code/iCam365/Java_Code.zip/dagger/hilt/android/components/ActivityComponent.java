package dagger.hilt.android.components;

import dagger.hilt.DefineComponent;
import dagger.hilt.android.scopes.ActivityScoped;

@ActivityScoped
@DefineComponent(parent = ActivityRetainedComponent.class)
/* loaded from: classes7.dex */
public interface ActivityComponent {
}
