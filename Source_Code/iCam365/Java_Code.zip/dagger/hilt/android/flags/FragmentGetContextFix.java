package dagger.hilt.android.flags;

import android.content.Context;
import dagger.Module;
import dagger.hilt.EntryPoint;
import dagger.hilt.InstallIn;
import dagger.hilt.android.EntryPointAccessors;
import dagger.hilt.components.SingletonComponent;
import dagger.hilt.internal.Preconditions;
import dagger.multibindings.Multibinds;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;
import java.util.Set;
import javax.inject.Qualifier;

/* loaded from: classes7.dex */
public final class FragmentGetContextFix {

    @Target({ElementType.METHOD, ElementType.PARAMETER, ElementType.FIELD})
    @Qualifier
    /* loaded from: classes7.dex */
    public @interface DisableFragmentGetContextFix {
    }

    @EntryPoint
    @InstallIn({SingletonComponent.class})
    /* loaded from: classes7.dex */
    public interface FragmentGetContextFixEntryPoint {
        @DisableFragmentGetContextFix
        Set<Boolean> getDisableFragmentGetContextFix();
    }

    @Module
    @InstallIn({SingletonComponent.class})
    /* renamed from: dagger.hilt.android.flags.FragmentGetContextFix$㫞, reason: contains not printable characters */
    /* loaded from: classes7.dex */
    public static abstract class AbstractC4770 {
        @DisableFragmentGetContextFix
        @Multibinds
        /* renamed from: 㫞, reason: contains not printable characters */
        public abstract Set<Boolean> m12362();
    }

    public static boolean isFragmentGetContextFixDisabled(Context context) {
        boolean z;
        Set<Boolean> disableFragmentGetContextFix = ((FragmentGetContextFixEntryPoint) EntryPointAccessors.fromApplication(context, FragmentGetContextFixEntryPoint.class)).getDisableFragmentGetContextFix();
        if (disableFragmentGetContextFix.size() <= 1) {
            z = true;
        } else {
            z = false;
        }
        Preconditions.checkState(z, "Cannot bind the flag @DisableFragmentGetContextFix more than once.", new Object[0]);
        if (disableFragmentGetContextFix.isEmpty()) {
            return true;
        }
        return disableFragmentGetContextFix.iterator().next().booleanValue();
    }
}
