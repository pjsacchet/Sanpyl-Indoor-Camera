package dagger.hilt.android;

import dagger.hilt.android.lifecycle.RetainedLifecycle;

/* loaded from: classes7.dex */
public interface ViewModelLifecycle extends RetainedLifecycle {
}
