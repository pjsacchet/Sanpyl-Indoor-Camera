package dagger;

/* loaded from: classes7.dex */
public interface Lazy<T> {
    T get();
}
