package dagger;

/* loaded from: classes7.dex */
public interface MembersInjector<T> {
    void injectMembers(T t);
}
