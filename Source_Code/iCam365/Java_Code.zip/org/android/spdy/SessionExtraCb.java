package org.android.spdy;

/* loaded from: classes7.dex */
public interface SessionExtraCb {
    void spdySessionOnWritable(SpdySession spdySession, Object obj, int i);
}
