package org.android.spdy;

/* loaded from: classes7.dex */
public enum SslVersion {
    SLIGHT_VERSION_V1(0);

    private int code;

    SslVersion(int i) {
        this.code = i;
    }

    public int getint() {
        return this.code;
    }
}
