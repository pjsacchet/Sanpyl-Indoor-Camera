package org.android.spdy;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

/* loaded from: classes7.dex */
public class SoInstallMgrSdk {
    private static final String ARMEABI = "armeabi";
    private static final int EventID_SO_INIT = 21033;
    public static final String LOGTAG = "INIT_SO";
    private static final String MIPS = "mips";
    private static final String X86 = "x86";
    public static Context mContext;

    private static String _cpuType() {
        String _getFieldReflectively = _getFieldReflectively(new Build(), "CPU_ABI");
        if (_getFieldReflectively == null || _getFieldReflectively.length() == 0 || _getFieldReflectively.equals("Unknown")) {
            _getFieldReflectively = ARMEABI;
        }
        return _getFieldReflectively.toLowerCase();
    }

    private static String _getFieldReflectively(Build build, String str) {
        try {
            return Build.class.getField(str).get(build).toString();
        } catch (Exception unused) {
            return "Unknown";
        }
    }

    public static boolean _loadUnzipSo(String str, int i, ClassLoader classLoader) {
        try {
            if (isExist(str, i)) {
                if (classLoader == null) {
                    System.load(_targetSoFile(str, i));
                } else {
                    Runtime runtime = Runtime.getRuntime();
                    Method declaredMethod = Runtime.class.getDeclaredMethod("load", String.class, ClassLoader.class);
                    declaredMethod.setAccessible(true);
                    declaredMethod.invoke(runtime, _targetSoFile(str, i), classLoader);
                }
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } catch (UnsatisfiedLinkError e2) {
            e2.printStackTrace();
            return false;
        } catch (Error e3) {
            e3.printStackTrace();
            return false;
        }
    }

    public static String _targetSoFile(String str, int i) {
        Context context = mContext;
        if (context == null) {
            return "";
        }
        String str2 = "/data/data/" + context.getPackageName() + "/files";
        File filesDir = context.getFilesDir();
        if (filesDir != null) {
            str2 = filesDir.getPath();
        }
        return str2 + "/lib" + str + "bk" + i + ".so";
    }

    public static void init(Context context) {
        mContext = context;
    }

    public static boolean initSo(String str, int i) {
        return initSo(str, i, null);
    }

    public static boolean isExist(String str, int i) {
        return new File(_targetSoFile(str, i)).exists();
    }

    public static void removeSoIfExit(String str, int i) {
        File file = new File(_targetSoFile(str, i));
        if (file.exists()) {
            file.delete();
        }
    }

    public static boolean unZipSelectedFiles(String str, int i, ClassLoader classLoader) throws ZipException, IOException {
        String str2;
        Context context;
        FileChannel fileChannel;
        FileOutputStream fileOutputStream;
        String str3 = "lib/armeabi/lib" + str + ".so";
        try {
            str2 = "";
            context = mContext;
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (context == null) {
            return false;
        }
        ApplicationInfo applicationInfo = context.getApplicationInfo();
        if (applicationInfo != null) {
            str2 = applicationInfo.sourceDir;
        }
        ZipFile zipFile = new ZipFile(str2);
        Enumeration<? extends ZipEntry> entries = zipFile.entries();
        while (entries.hasMoreElements()) {
            ZipEntry nextElement = entries.nextElement();
            String name = nextElement.getName();
            if (!name.contains("..") && !name.contains("\\") && !name.contains("%")) {
                if (nextElement.getName().startsWith(str3)) {
                    InputStream inputStream = null;
                    FileChannel fileChannel2 = null;
                    try {
                        removeSoIfExit(str, i);
                        InputStream inputStream2 = zipFile.getInputStream(nextElement);
                        try {
                            fileOutputStream = context.openFileOutput("lib" + str + "bk" + i + ".so", 0);
                            try {
                                fileChannel2 = fileOutputStream.getChannel();
                                byte[] bArr = new byte[1024];
                                int i2 = 0;
                                while (true) {
                                    int read = inputStream2.read(bArr);
                                    if (read > 0) {
                                        fileChannel2.write(ByteBuffer.wrap(bArr, 0, read));
                                        i2 += read;
                                    } else {
                                        try {
                                            break;
                                        } catch (Exception e2) {
                                            e2.printStackTrace();
                                        }
                                    }
                                }
                                inputStream2.close();
                                if (fileChannel2 != null) {
                                    try {
                                        fileChannel2.close();
                                    } catch (Exception e3) {
                                        e3.printStackTrace();
                                    }
                                }
                                try {
                                    fileOutputStream.close();
                                } catch (Exception e4) {
                                    e4.printStackTrace();
                                }
                                zipFile.close();
                                if (i2 <= 0) {
                                    return false;
                                }
                                return _loadUnzipSo(str, i, classLoader);
                            } catch (Throwable th) {
                                th = th;
                                fileChannel = fileChannel2;
                                inputStream = inputStream2;
                                if (inputStream != null) {
                                    try {
                                        inputStream.close();
                                    } catch (Exception e5) {
                                        e5.printStackTrace();
                                    }
                                }
                                if (fileChannel != null) {
                                    try {
                                        fileChannel.close();
                                    } catch (Exception e6) {
                                        e6.printStackTrace();
                                    }
                                }
                                if (fileOutputStream != null) {
                                    try {
                                        fileOutputStream.close();
                                    } catch (Exception e7) {
                                        e7.printStackTrace();
                                    }
                                }
                                zipFile.close();
                                throw th;
                            }
                        } catch (Throwable th2) {
                            th = th2;
                            fileChannel = null;
                            fileOutputStream = null;
                        }
                    } catch (Throwable th3) {
                        th = th3;
                        fileChannel = null;
                        fileOutputStream = null;
                    }
                }
            }
            return false;
        }
        return false;
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x003d A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static boolean initSo(String str, int i, ClassLoader classLoader) {
        boolean z = true;
        try {
            if (classLoader == null) {
                System.loadLibrary(str);
            } else {
                Runtime runtime = Runtime.getRuntime();
                Method declaredMethod = Runtime.class.getDeclaredMethod("loadLibrary", String.class, ClassLoader.class);
                declaredMethod.setAccessible(true);
                declaredMethod.invoke(runtime, str, classLoader);
            }
        } catch (Exception e) {
            e.printStackTrace();
            z = false;
            if (!z) {
            }
            return z;
        } catch (UnsatisfiedLinkError e2) {
            e2.printStackTrace();
            z = false;
            if (!z) {
            }
            return z;
        } catch (Error e3) {
            e3.printStackTrace();
            z = false;
            if (!z) {
            }
            return z;
        }
        if (!z) {
            try {
                if (isExist(str, i)) {
                    boolean _loadUnzipSo = _loadUnzipSo(str, i, classLoader);
                    if (_loadUnzipSo) {
                        return _loadUnzipSo;
                    }
                    removeSoIfExit(str, i);
                }
                String _cpuType = _cpuType();
                if (!_cpuType.equalsIgnoreCase(MIPS) && !_cpuType.equalsIgnoreCase(X86)) {
                    try {
                        return unZipSelectedFiles(str, i, classLoader);
                    } catch (ZipException e4) {
                        e4.printStackTrace();
                    } catch (IOException e5) {
                        e5.printStackTrace();
                    }
                }
            } catch (Error e6) {
                e6.printStackTrace();
                return false;
            } catch (Exception e7) {
                e7.printStackTrace();
                return false;
            } catch (UnsatisfiedLinkError e8) {
                e8.printStackTrace();
                return false;
            }
        }
        return z;
    }
}
