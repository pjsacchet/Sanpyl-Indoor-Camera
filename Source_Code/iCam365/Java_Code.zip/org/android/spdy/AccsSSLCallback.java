package org.android.spdy;

/* loaded from: classes7.dex */
public interface AccsSSLCallback {
    byte[] getSSLPublicKey(int i, byte[] bArr);
}
