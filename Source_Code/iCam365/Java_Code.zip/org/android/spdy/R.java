package org.android.spdy;

/* loaded from: classes7.dex */
public final class R {
    private R() {
    }
}
