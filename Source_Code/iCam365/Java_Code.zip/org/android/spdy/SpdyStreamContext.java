package org.android.spdy;

/* loaded from: classes7.dex */
public class SpdyStreamContext {
    public Spdycb callBack;
    public Object streamContext;
    public int streamId;

    public SpdyStreamContext(Object obj) {
        this.streamContext = obj;
        this.callBack = null;
        this.streamId = -1;
    }

    public static int getContext(Object obj) {
        if (obj != null && (obj instanceof Integer)) {
            return ((Integer) obj).intValue();
        }
        return 0;
    }

    public SpdyStreamContext(Object obj, Spdycb spdycb) {
        this.streamContext = obj;
        this.callBack = spdycb;
    }
}
