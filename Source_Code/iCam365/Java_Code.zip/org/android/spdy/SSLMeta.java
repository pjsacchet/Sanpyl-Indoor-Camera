package org.android.spdy;

/* loaded from: classes7.dex */
public class SSLMeta {
    public byte[] sslMeta = null;
    public int sslMetaLength = 0;
}
