package org.android.spdy;

/* loaded from: classes7.dex */
public class SslPublickey {
    public int error;
    public byte[] exponent;
    public byte[] module;
    public int seqnum;
}
