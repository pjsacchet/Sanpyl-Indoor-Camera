package org.android.spdy;

/* loaded from: classes7.dex */
public class SslPermData {
    public int genrequest;
    public int invalidkey;
    public int keyrequest;
    public int requestnum;
    public int requesttime;
}
