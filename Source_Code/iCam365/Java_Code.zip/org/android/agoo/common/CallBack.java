package org.android.agoo.common;

/* loaded from: classes7.dex */
public interface CallBack {
    void onFailure(String str, String str2);

    void onSuccess();
}
