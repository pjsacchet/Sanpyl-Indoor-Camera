package org.android.agoo.control;

import android.content.Context;
import com.taobao.accs.ACCSManager;
import com.taobao.accs.IACCSManager;
import com.taobao.accs.base.TaoBaseService;
import com.taobao.accs.utl.ALog;
import com.taobao.accs.utl.AdapterUtilityImpl;
import com.taobao.accs.utl.UTMini;
import java.util.HashMap;
import java.util.Map;
import org.android.agoo.common.AgooConstants;
import org.android.agoo.common.Config;
import org.json.JSONObject;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes7.dex */
public class m implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ String f49781a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ String f49782b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ String f49783c;
    public final /* synthetic */ String d;
    public final /* synthetic */ boolean e;
    public final /* synthetic */ NotifManager f;

    public m(NotifManager notifManager, String str, String str2, String str3, String str4, boolean z) {
        this.f = notifManager;
        this.f49781a = str;
        this.f49782b = str2;
        this.f49783c = str3;
        this.d = str4;
        this.e = z;
    }

    @Override // java.lang.Runnable
    public void run() {
        Context context;
        Context context2;
        Context context3;
        Context context4;
        Context context5;
        Context context6;
        Context context7;
        Context context8;
        String sendPushResponse;
        Context context9;
        try {
            HashMap hashMap = new HashMap();
            String str = this.f49781a;
            if (str != null) {
                hashMap.put("sdkVer", str);
            }
            hashMap.put("thirdTokenType", this.f49782b);
            hashMap.put("token", this.f49783c);
            context2 = NotifManager.mContext;
            hashMap.put("appkey", Config.b(context2));
            context3 = NotifManager.mContext;
            hashMap.put("utdid", AdapterUtilityImpl.getDeviceId(context3));
            String str2 = this.d;
            if (str2 != null) {
                hashMap.put("vendorSdkVersion", str2);
            }
            StringBuilder sb = new StringBuilder();
            sb.append("report,utdid=");
            context4 = NotifManager.mContext;
            sb.append(AdapterUtilityImpl.getDeviceId(context4));
            sb.append(",regId=");
            sb.append(this.f49783c);
            sb.append(",type=");
            sb.append(this.f49782b);
            sb.append(" sdkVer=");
            sb.append(this.f49781a);
            sb.append(" thirdVer=");
            sb.append(this.d);
            ALog.d("NotifManager", sb.toString(), new Object[0]);
            ACCSManager.AccsRequest accsRequest = new ACCSManager.AccsRequest(null, "agooTokenReport", new JSONObject((Map) hashMap).toString().getBytes("UTF-8"), null, null, null, null);
            context5 = NotifManager.mContext;
            context6 = NotifManager.mContext;
            String b2 = Config.b(context6);
            context7 = NotifManager.mContext;
            IACCSManager accsInstance = ACCSManager.getAccsInstance(context5, b2, Config.c(context7));
            if (this.e) {
                context9 = NotifManager.mContext;
                sendPushResponse = accsInstance.sendData(context9, accsRequest);
            } else {
                context8 = NotifManager.mContext;
                sendPushResponse = accsInstance.sendPushResponse(context8, accsRequest, new TaoBaseService.ExtraInfo());
            }
            if (ALog.isPrintLog(ALog.Level.D)) {
                ALog.i("NotifManager", "reportThirdPushToken,dataId=" + sendPushResponse + ",regId=" + this.f49783c + ",type=" + this.f49782b, new Object[0]);
            }
        } catch (Throwable th) {
            UTMini uTMini = UTMini.getInstance();
            context = NotifManager.mContext;
            uTMini.commitEvent(AgooConstants.AGOO_EVENT_ID, "reportThirdPushToken", AdapterUtilityImpl.getDeviceId(context), th.toString());
            if (ALog.isPrintLog(ALog.Level.E)) {
                ALog.e("NotifManager", "[report] is error", th, new Object[0]);
            }
        }
    }
}
