package org.android.agoo.control;

import android.content.Context;
import android.text.TextUtils;
import com.taobao.accs.utl.ALog;
import com.taobao.accs.utl.AppMonitorAdapter;
import com.taobao.accs.utl.BaseMonitor;
import org.android.agoo.common.AgooConstants;
import org.android.agoo.common.Config;
import org.android.agoo.message.MessageService;
import org.json.JSONObject;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes7.dex */
public class d implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ byte[] f49762a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ boolean f49763b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ AgooFactory f49764c;

    public d(AgooFactory agooFactory, byte[] bArr, boolean z) {
        this.f49764c = agooFactory;
        this.f49762a = bArr;
        this.f49763b = z;
    }

    @Override // java.lang.Runnable
    public void run() {
        MessageService messageService;
        MessageService messageService2;
        Context context;
        try {
            String str = new String(this.f49762a, "utf-8");
            if (TextUtils.isEmpty(str)) {
                AppMonitorAdapter.commitCount("accs", BaseMonitor.COUNT_AGOO_FAIL_ACK, "msg==null", 0.0d);
                return;
            }
            ALog.i("AgooFactory", "message = " + str, new Object[0]);
            JSONObject jSONObject = new JSONObject(str);
            String str2 = null;
            String string = jSONObject.getString("api");
            String string2 = jSONObject.getString("id");
            if (TextUtils.equals(string, "agooReport")) {
                str2 = jSONObject.getString("status");
            }
            if (TextUtils.equals(string, AgooConstants.AGOO_SERVICE_AGOOACK)) {
                AppMonitorAdapter.commitCount("accs", BaseMonitor.COUNT_AGOO_SUCCESS_ACK, "handlerACKMessage", 0.0d);
            }
            if (!TextUtils.isEmpty(string) && !TextUtils.isEmpty(string2) && !TextUtils.isEmpty(str2)) {
                if (ALog.isPrintLog(ALog.Level.I)) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("updateMsg data begin,api=");
                    sb.append(string);
                    sb.append(",id=");
                    sb.append(string2);
                    sb.append(",status=");
                    sb.append(str2);
                    sb.append(",reportTimes=");
                    context = AgooFactory.mContext;
                    sb.append(Config.f(context));
                    ALog.i("AgooFactory", sb.toString(), new Object[0]);
                }
                if (TextUtils.equals(string, "agooReport")) {
                    if (TextUtils.equals(str2, "4") && this.f49763b) {
                        messageService2 = this.f49764c.messageService;
                        messageService2.a(string2, "1");
                    } else if ((TextUtils.equals(str2, "8") || TextUtils.equals(str2, "9")) && this.f49763b) {
                        messageService = this.f49764c.messageService;
                        messageService.a(string2, "100");
                    }
                    AppMonitorAdapter.commitCount("accs", BaseMonitor.COUNT_AGOO_SUCCESS_ACK, str2, 0.0d);
                    return;
                }
                return;
            }
            AppMonitorAdapter.commitCount("accs", BaseMonitor.COUNT_AGOO_FAIL_ACK, "json key null", 0.0d);
        } catch (Throwable th) {
            ALog.e("AgooFactory", "updateMsg get data error,e=" + th, new Object[0]);
            AppMonitorAdapter.commitCount("accs", BaseMonitor.COUNT_AGOO_FAIL_ACK, "json exception", 0.0d);
        }
    }
}
