package org.android.agoo.control;

import android.text.TextUtils;
import com.taobao.accs.utl.ALog;
import org.android.agoo.common.MsgDO;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes7.dex */
public class f implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ String f49768a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ String f49769b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ AgooFactory f49770c;

    public f(AgooFactory agooFactory, String str, String str2) {
        this.f49770c = agooFactory;
        this.f49768a = str;
        this.f49769b = str2;
    }

    @Override // java.lang.Runnable
    public void run() {
        NotifManager notifManager;
        NotifManager notifManager2;
        MsgDO msgDO = null;
        try {
            if (ALog.isPrintLog(ALog.Level.I)) {
                ALog.i("AgooFactory", "clickMessage", "msgid", this.f49768a, "extData", this.f49769b);
            }
            if (TextUtils.isEmpty(this.f49768a)) {
                ALog.d("AgooFactory", "messageId == null", new Object[0]);
                return;
            }
            MsgDO msgDO2 = new MsgDO();
            try {
                String str = this.f49768a;
                msgDO2.msgIds = str;
                msgDO2.extData = this.f49769b;
                msgDO2.messageSource = "accs";
                msgDO2.msgStatus = "8";
                this.f49770c.updateMsgStatus(str, "8");
                notifManager2 = this.f49770c.notifyManager;
                notifManager2.reportNotifyMessage(msgDO2);
            } catch (Throwable th) {
                th = th;
                msgDO = msgDO2;
                try {
                    ALog.e("AgooFactory", "clickMessage,error=" + th, new Object[0]);
                } finally {
                    if (msgDO != null) {
                        notifManager = this.f49770c.notifyManager;
                        notifManager.reportNotifyMessage(msgDO);
                    }
                }
            }
        } catch (Throwable th2) {
            th = th2;
        }
    }
}
