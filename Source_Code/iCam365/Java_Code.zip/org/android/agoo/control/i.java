package org.android.agoo.control;

import android.content.Intent;

/* loaded from: classes7.dex */
class i implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Intent f49775a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ h f49776b;

    public i(h hVar, Intent intent) {
        this.f49776b = hVar;
        this.f49775a = intent;
    }

    @Override // java.lang.Runnable
    public void run() {
        this.f49776b.f49774a.onHandleIntent(this.f49775a);
    }
}
