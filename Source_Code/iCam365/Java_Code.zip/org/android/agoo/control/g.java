package org.android.agoo.control;

import android.text.TextUtils;
import com.taobao.accs.utl.ALog;
import org.android.agoo.common.MsgDO;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes7.dex */
public class g implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ String f49771a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ String f49772b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ AgooFactory f49773c;

    public g(AgooFactory agooFactory, String str, String str2) {
        this.f49773c = agooFactory;
        this.f49771a = str;
        this.f49772b = str2;
    }

    @Override // java.lang.Runnable
    public void run() {
        NotifManager notifManager;
        NotifManager notifManager2;
        MsgDO msgDO = null;
        try {
            if (ALog.isPrintLog(ALog.Level.I)) {
                ALog.i("AgooFactory", "dismissMessage", "msgid", this.f49771a, "extData", this.f49772b);
            }
            if (TextUtils.isEmpty(this.f49771a)) {
                ALog.d("AgooFactory", "messageId == null", new Object[0]);
                return;
            }
            MsgDO msgDO2 = new MsgDO();
            try {
                String str = this.f49771a;
                msgDO2.msgIds = str;
                msgDO2.extData = this.f49772b;
                msgDO2.messageSource = "accs";
                msgDO2.msgStatus = "9";
                this.f49773c.updateMsgStatus(str, "9");
                notifManager2 = this.f49773c.notifyManager;
                notifManager2.reportNotifyMessage(msgDO2);
            } catch (Throwable th) {
                th = th;
                msgDO = msgDO2;
                try {
                    ALog.e("AgooFactory", "clickMessage,error=" + th, new Object[0]);
                } finally {
                    if (msgDO != null) {
                        notifManager = this.f49773c.notifyManager;
                        notifManager.reportNotifyMessage(msgDO);
                    }
                }
            }
        } catch (Throwable th2) {
            th = th2;
        }
    }
}
