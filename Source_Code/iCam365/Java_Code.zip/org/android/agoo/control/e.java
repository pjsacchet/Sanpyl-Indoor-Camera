package org.android.agoo.control;

/* loaded from: classes7.dex */
class e implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ String f49765a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ String f49766b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ AgooFactory f49767c;

    public e(AgooFactory agooFactory, String str, String str2) {
        this.f49767c = agooFactory;
        this.f49765a = str;
        this.f49766b = str2;
    }

    @Override // java.lang.Runnable
    public void run() {
        this.f49767c.updateMsgStatus(this.f49765a, this.f49766b);
    }
}
