package org.android.agoo.control;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Messenger;
import android.text.TextUtils;
import anet.channel.appmonitor.AppMonitor;
import com.huawei.hms.support.hianalytics.HiAnalyticsConstant;
import com.taobao.accs.base.TaoBaseService;
import com.taobao.accs.client.AdapterGlobalClientInfo;
import com.taobao.accs.common.Constants;
import com.taobao.accs.common.ThreadPoolExecutorFactory;
import com.taobao.accs.ut.monitor.NetPerformanceMonitor;
import com.taobao.accs.utl.ALog;
import com.taobao.accs.utl.AdapterUtilityImpl;
import com.taobao.accs.utl.AppMonitorAdapter;
import com.taobao.accs.utl.BaseMonitor;
import com.taobao.accs.utl.OrangeAdapter;
import com.taobao.accs.utl.UTMini;
import com.taobao.accs.utl.Utils;
import org.android.agoo.common.AgooConstants;
import org.android.agoo.common.Config;
import org.android.agoo.common.MsgDO;
import org.android.agoo.message.MessageService;

/* loaded from: classes7.dex */
public abstract class BaseIntentService extends Service {
    private static final String TAG = "BaseIntentService";
    private static final String msgStatus = "4";
    private AgooFactory agooFactory;
    private MessageService messageService;
    private NotifManager notifyManager;
    private Context mContext = null;
    private Messenger messenger = new Messenger(new h(this));

    private final String getTrace(Context context, long j) {
        String str;
        String str2 = null;
        if (TextUtils.isEmpty(null)) {
            str = "unknow";
        } else {
            str = null;
        }
        if (TextUtils.isEmpty(null)) {
            str2 = "unknow";
        }
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("appkey");
        stringBuffer.append(HiAnalyticsConstant.REPORT_VAL_SEPARATOR);
        stringBuffer.append(j);
        stringBuffer.append(HiAnalyticsConstant.REPORT_VAL_SEPARATOR);
        stringBuffer.append(System.currentTimeMillis());
        stringBuffer.append(HiAnalyticsConstant.REPORT_VAL_SEPARATOR);
        stringBuffer.append(str);
        stringBuffer.append(HiAnalyticsConstant.REPORT_VAL_SEPARATOR);
        stringBuffer.append(str2);
        return stringBuffer.toString();
    }

    /* JADX WARN: Removed duplicated region for block: B:121:0x0168 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:25:0x00c4 A[Catch: all -> 0x0347, TryCatch #8 {all -> 0x0347, blocks: (B:23:0x00b6, B:25:0x00c4, B:26:0x0101, B:28:0x012a, B:30:0x0134, B:32:0x0146, B:35:0x0150, B:42:0x0162, B:44:0x017a, B:123:0x0171, B:134:0x009a), top: B:133:0x009a }] */
    /* JADX WARN: Removed duplicated region for block: B:28:0x012a A[Catch: all -> 0x0347, TryCatch #8 {all -> 0x0347, blocks: (B:23:0x00b6, B:25:0x00c4, B:26:0x0101, B:28:0x012a, B:30:0x0134, B:32:0x0146, B:35:0x0150, B:42:0x0162, B:44:0x017a, B:123:0x0171, B:134:0x009a), top: B:133:0x009a }] */
    /* JADX WARN: Removed duplicated region for block: B:44:0x017a A[Catch: all -> 0x0347, TRY_LEAVE, TryCatch #8 {all -> 0x0347, blocks: (B:23:0x00b6, B:25:0x00c4, B:26:0x0101, B:28:0x012a, B:30:0x0134, B:32:0x0146, B:35:0x0150, B:42:0x0162, B:44:0x017a, B:123:0x0171, B:134:0x009a), top: B:133:0x009a }] */
    /* JADX WARN: Removed duplicated region for block: B:55:0x01f9 A[Catch: all -> 0x0345, TryCatch #4 {all -> 0x0345, blocks: (B:53:0x01f1, B:55:0x01f9, B:57:0x0201, B:58:0x0224, B:60:0x022c, B:62:0x0234, B:91:0x02e6, B:93:0x0337, B:94:0x0341, B:101:0x0288, B:103:0x0290, B:111:0x01d6), top: B:110:0x01d6 }] */
    /* JADX WARN: Removed duplicated region for block: B:60:0x022c A[Catch: all -> 0x0345, TryCatch #4 {all -> 0x0345, blocks: (B:53:0x01f1, B:55:0x01f9, B:57:0x0201, B:58:0x0224, B:60:0x022c, B:62:0x0234, B:91:0x02e6, B:93:0x0337, B:94:0x0341, B:101:0x0288, B:103:0x0290, B:111:0x01d6), top: B:110:0x01d6 }] */
    /* JADX WARN: Removed duplicated region for block: B:93:0x0337 A[Catch: all -> 0x0345, TryCatch #4 {all -> 0x0345, blocks: (B:53:0x01f1, B:55:0x01f9, B:57:0x0201, B:58:0x0224, B:60:0x022c, B:62:0x0234, B:91:0x02e6, B:93:0x0337, B:94:0x0341, B:101:0x0288, B:103:0x0290, B:111:0x01d6), top: B:110:0x01d6 }] */
    /* JADX WARN: Unreachable blocks removed: 2, instructions: 3 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private final void handleRemoteMessage(Context context, Intent intent) {
        String str;
        String str2;
        String str3;
        String str4;
        String str5;
        TaoBaseService.ExtraInfo extraInfo;
        String str6;
        String str7;
        CharSequence charSequence;
        int i;
        String str8;
        NetPerformanceMonitor netPerformanceMonitor;
        Bundle bundleExtra;
        try {
            String stringExtra = intent.getStringExtra("id");
            String stringExtra2 = intent.getStringExtra("body");
            String stringExtra3 = intent.getStringExtra("type");
            String stringExtra4 = intent.getStringExtra(AgooConstants.MESSAGE_SOURCE);
            String stringExtra5 = intent.getStringExtra("report");
            String stringExtra6 = intent.getStringExtra(AgooConstants.MESSAGE_ENCRYPTED);
            String stringExtra7 = intent.getStringExtra("extData");
            try {
                String stringExtra8 = intent.getStringExtra(AgooConstants.MESSAGE_ORI);
                try {
                    str3 = "messageId=";
                    try {
                        getTrace(context, Long.valueOf(intent.getLongExtra(AgooConstants.MESSAGE_TRACE, -1L)).longValue());
                        bundleExtra = intent.getBundleExtra(AgooConstants.MESSAGE_AGOO_BUNDLE);
                        str4 = intent.getStringExtra("source");
                        try {
                            if (TextUtils.isEmpty(str4)) {
                                str4 = "oldsdk";
                            }
                            str6 = intent.getStringExtra(AgooConstants.MESSAGE_FROM_APPKEY);
                        } catch (Throwable th) {
                            th = th;
                            try {
                                str5 = TAG;
                                ALog.e(str5, "_trace,t=" + th, new Object[0]);
                                extraInfo = null;
                                str6 = null;
                                if (ALog.isPrintLog(ALog.Level.I)) {
                                }
                                MsgDO msgDO = new MsgDO();
                                msgDO.msgIds = stringExtra;
                                msgDO.extData = stringExtra7;
                                msgDO.messageSource = stringExtra4;
                                msgDO.msgStatus = "4";
                                msgDO.reportStr = stringExtra5;
                                msgDO.fromPkg = str4;
                                msgDO.fromAppkey = str6;
                                msgDO.isStartProc = AdapterGlobalClientInfo.isFirstStartProc();
                                msgDO.notifyEnable = AdapterUtilityImpl.isNotificationEnabled(this.mContext);
                                if (!TextUtils.isEmpty(stringExtra2)) {
                                }
                                if (!TextUtils.isEmpty(stringExtra2)) {
                                }
                            } catch (Throwable th2) {
                                th = th2;
                                str = BaseMonitor.COUNT_AGOO_ARRIVE;
                                str2 = "accs";
                                AppMonitorAdapter.commitCount(str2, str, "arrive_exception" + th.toString(), 0.0d);
                                return;
                            }
                        }
                    } catch (Throwable th3) {
                        th = th3;
                        str4 = null;
                        str5 = TAG;
                        ALog.e(str5, "_trace,t=" + th, new Object[0]);
                        extraInfo = null;
                        str6 = null;
                        if (ALog.isPrintLog(ALog.Level.I)) {
                        }
                        MsgDO msgDO2 = new MsgDO();
                        msgDO2.msgIds = stringExtra;
                        msgDO2.extData = stringExtra7;
                        msgDO2.messageSource = stringExtra4;
                        msgDO2.msgStatus = "4";
                        msgDO2.reportStr = stringExtra5;
                        msgDO2.fromPkg = str4;
                        msgDO2.fromAppkey = str6;
                        msgDO2.isStartProc = AdapterGlobalClientInfo.isFirstStartProc();
                        msgDO2.notifyEnable = AdapterUtilityImpl.isNotificationEnabled(this.mContext);
                        if (!TextUtils.isEmpty(stringExtra2)) {
                        }
                        if (!TextUtils.isEmpty(stringExtra2)) {
                        }
                    }
                } catch (Throwable th4) {
                    th = th4;
                    str3 = "messageId=";
                }
                if (bundleExtra != null) {
                    try {
                        extraInfo = (TaoBaseService.ExtraInfo) bundleExtra.getSerializable(AgooConstants.MESSAGE_ACCS_EXTRA);
                    } catch (Throwable unused) {
                    }
                    str5 = TAG;
                    if (ALog.isPrintLog(ALog.Level.I)) {
                        ALog.i(str5, "handleRemoteMessage", "message", stringExtra2, "source", stringExtra4, "msgId", stringExtra, "utdid", AdapterUtilityImpl.getDeviceId(context), "fromPkg", str4, AgooConstants.MESSAGE_FROM_APPKEY, str6);
                    }
                    MsgDO msgDO22 = new MsgDO();
                    msgDO22.msgIds = stringExtra;
                    msgDO22.extData = stringExtra7;
                    msgDO22.messageSource = stringExtra4;
                    msgDO22.msgStatus = "4";
                    msgDO22.reportStr = stringExtra5;
                    msgDO22.fromPkg = str4;
                    msgDO22.fromAppkey = str6;
                    msgDO22.isStartProc = AdapterGlobalClientInfo.isFirstStartProc();
                    msgDO22.notifyEnable = AdapterUtilityImpl.isNotificationEnabled(this.mContext);
                    if (!TextUtils.isEmpty(stringExtra2)) {
                        if (Integer.toString(4).equals(stringExtra6)) {
                            ALog.i(str5, "message is encrypted, attemp to decrypt msg", new Object[0]);
                            stringExtra2 = AgooFactory.parseEncryptedMsg(stringExtra2);
                            if (TextUtils.isEmpty(stringExtra2)) {
                                msgDO22.errorCode = AgooConstants.REPORT_ENCRYPT_FAIL;
                                this.notifyManager.handlerACKMessage(msgDO22, extraInfo);
                                return;
                            }
                        } else {
                            ALog.e(str5, "msg encrypted flag not exist~~", new Object[0]);
                            try {
                                msgDO22.errorCode = AgooConstants.REPORT_NOT_ENCRYPT;
                                this.notifyManager.report(msgDO22, extraInfo);
                                return;
                            } catch (Throwable unused2) {
                                return;
                            }
                        }
                    }
                    if (!TextUtils.isEmpty(stringExtra2)) {
                        try {
                            msgDO22.errorCode = AgooConstants.REPORT_MESSAGE_NULL;
                            this.notifyManager.report(msgDO22, extraInfo);
                        } catch (Throwable unused3) {
                        }
                        ALog.e(str5, "handleMessage--->[null]", new Object[0]);
                        return;
                    }
                    intent.putExtra("body", stringExtra2);
                    try {
                        this.notifyManager.report(msgDO22, extraInfo);
                        this.messageService.a(stringExtra, stringExtra8, "0");
                        UTMini uTMini = UTMini.getInstance();
                        String[] strArr = new String[2];
                        strArr[0] = null;
                        StringBuilder sb = new StringBuilder();
                        str7 = str3;
                        try {
                            sb.append(str7);
                            sb.append(msgDO22.msgIds);
                            strArr[1] = sb.toString();
                            uTMini.commitEvent(UTMini.EVENTID_AGOO, UTMini.PAGE_AGOO, BaseMonitor.COUNT_AGOO_ARRIVE_ID, (Object) null, (Object) null, strArr);
                            str = BaseMonitor.COUNT_AGOO_ARRIVE;
                            str2 = "accs";
                            try {
                                AppMonitorAdapter.commitCount(str2, str, "arrive", 0.0d);
                            } catch (Throwable th5) {
                                th = th5;
                                try {
                                    ALog.e(str5, "report message Throwable--->t=" + th.toString(), new Object[0]);
                                    if (!this.messageService.a(stringExtra)) {
                                    }
                                } catch (Throwable th6) {
                                    th = th6;
                                    AppMonitorAdapter.commitCount(str2, str, "arrive_exception" + th.toString(), 0.0d);
                                    return;
                                }
                            }
                        } catch (Throwable th7) {
                            th = th7;
                            str = BaseMonitor.COUNT_AGOO_ARRIVE;
                            str2 = "accs";
                        }
                    } catch (Throwable th8) {
                        th = th8;
                        str = BaseMonitor.COUNT_AGOO_ARRIVE;
                        str2 = "accs";
                        str7 = str3;
                    }
                    if (!this.messageService.a(stringExtra)) {
                        if (ALog.isPrintLog(ALog.Level.I)) {
                            ALog.i(str5, "handleRemoteMessage hasMessageDuplicate,messageId=" + stringExtra + ",utdid=" + AdapterUtilityImpl.getDeviceId(context), new Object[0]);
                        }
                        AppMonitorAdapter.commitCount(str2, str, "arrive_dup", 0.0d);
                        return;
                    }
                    if (ALog.isPrintLog(ALog.Level.I)) {
                        ALog.i(str5, "handleMessage--->[" + stringExtra2 + "],[" + stringExtra4 + "]", new Object[0]);
                    }
                    try {
                        String stringExtra9 = intent.getStringExtra(AgooConstants.MESSAGE_DUPLICATE);
                        if (!TextUtils.isEmpty(stringExtra9)) {
                            charSequence = "1";
                            try {
                                if (TextUtils.equals(stringExtra9, charSequence) && this.messageService.a(stringExtra, stringExtra2.hashCode())) {
                                    AppMonitorAdapter.commitCount(str2, str, "arrive_dupbody", 0.0d);
                                    return;
                                }
                            } catch (Throwable th9) {
                                th = th9;
                                if (ALog.isPrintLog(ALog.Level.E)) {
                                    ALog.e(str5, "hasMessageDuplicate message,e=" + th.toString(), new Object[0]);
                                }
                                i = -1;
                                i = Integer.parseInt(intent.getStringExtra(AgooConstants.MESSAGE_NOTIFICATION));
                                String str9 = "";
                                str8 = intent.getStringExtra(AgooConstants.MESSAGE_HAS_TEST);
                                if (TextUtils.isEmpty(str8)) {
                                }
                                str8 = stringExtra3;
                                str9 = getClass().getName();
                                this.messageService.a(stringExtra, stringExtra2, str8, i);
                                UTMini.getInstance().commitEvent(UTMini.EVENTID_AGOO, UTMini.PAGE_AGOO, BaseMonitor.COUNT_AGOO_ARRIVE_REAL_ID, (Object) null, (Object) null, null, str7 + msgDO22.msgIds);
                                AppMonitorAdapter.commitCount(str2, str, "arrive_real_" + str9, 0.0d);
                                netPerformanceMonitor = (NetPerformanceMonitor) intent.getSerializableExtra(Constants.KEY_MONIROT);
                                if (netPerformanceMonitor != null) {
                                }
                                onMessage(context, intent);
                                return;
                            }
                        } else {
                            charSequence = "1";
                        }
                    } catch (Throwable th10) {
                        th = th10;
                        charSequence = "1";
                    }
                    i = -1;
                    try {
                        i = Integer.parseInt(intent.getStringExtra(AgooConstants.MESSAGE_NOTIFICATION));
                    } catch (Throwable unused4) {
                    }
                    String str92 = "";
                    try {
                        str8 = intent.getStringExtra(AgooConstants.MESSAGE_HAS_TEST);
                    } catch (Throwable unused5) {
                        str8 = stringExtra3;
                    }
                    if (TextUtils.isEmpty(str8) && TextUtils.equals(str8, charSequence)) {
                        this.messageService.a(stringExtra, stringExtra2, stringExtra3, i);
                        AppMonitorAdapter.commitCount(str2, str, "arrive_test", 0.0d);
                        return;
                    }
                    str8 = stringExtra3;
                    str92 = getClass().getName();
                    this.messageService.a(stringExtra, stringExtra2, str8, i);
                    UTMini.getInstance().commitEvent(UTMini.EVENTID_AGOO, UTMini.PAGE_AGOO, BaseMonitor.COUNT_AGOO_ARRIVE_REAL_ID, (Object) null, (Object) null, null, str7 + msgDO22.msgIds);
                    AppMonitorAdapter.commitCount(str2, str, "arrive_real_" + str92, 0.0d);
                    netPerformanceMonitor = (NetPerformanceMonitor) intent.getSerializableExtra(Constants.KEY_MONIROT);
                    if (netPerformanceMonitor != null) {
                        netPerformanceMonitor.onToAgooTime();
                        AppMonitor.getInstance().commitStat(netPerformanceMonitor);
                    }
                    onMessage(context, intent);
                    return;
                }
                extraInfo = null;
                str5 = TAG;
                if (ALog.isPrintLog(ALog.Level.I)) {
                }
                MsgDO msgDO222 = new MsgDO();
                msgDO222.msgIds = stringExtra;
                msgDO222.extData = stringExtra7;
                msgDO222.messageSource = stringExtra4;
                msgDO222.msgStatus = "4";
                msgDO222.reportStr = stringExtra5;
                msgDO222.fromPkg = str4;
                msgDO222.fromAppkey = str6;
                msgDO222.isStartProc = AdapterGlobalClientInfo.isFirstStartProc();
                msgDO222.notifyEnable = AdapterUtilityImpl.isNotificationEnabled(this.mContext);
                if (!TextUtils.isEmpty(stringExtra2)) {
                }
                if (!TextUtils.isEmpty(stringExtra2)) {
                }
            } catch (Throwable th11) {
                th = th11;
                str2 = "accs";
                str = BaseMonitor.COUNT_AGOO_ARRIVE;
            }
        } catch (Throwable th12) {
            th = th12;
            str = BaseMonitor.COUNT_AGOO_ARRIVE;
            str2 = "accs";
        }
    }

    private final void handleRemovePackage(Context context, Intent intent) {
        if (intent != null && context != null) {
            String str = null;
            Uri data = intent.getData();
            if (data != null) {
                str = data.getSchemeSpecificPart();
            }
            if (TextUtils.isEmpty(str)) {
                return;
            }
            boolean booleanExtra = intent.getBooleanExtra("android.intent.extra.REPLACING", false);
            if (ALog.isPrintLog(ALog.Level.D)) {
                ALog.d(TAG, "handleRemovePackage---->[replacing:" + booleanExtra + "],uninstallPack=" + str, new Object[0]);
            }
            if (!booleanExtra) {
                this.notifyManager.doUninstall(str, booleanExtra);
            }
        }
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        if (OrangeAdapter.isBindService(this) && Utils.isTarget26(this)) {
            getApplicationContext().bindService(new Intent(this, getClass()), new j(this), 1);
        }
        return this.messenger.getBinder();
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        ThreadPoolExecutorFactory.execute(new k(this));
    }

    @Deprecated
    public abstract void onError(Context context, String str);

    public void onHandleIntent(Intent intent) {
        this.mContext = getApplicationContext();
        if (intent == null) {
            return;
        }
        String action = intent.getAction();
        if (TextUtils.isEmpty(action)) {
            return;
        }
        ALog.i(TAG, "onHandleIntent,action=" + action, new Object[0]);
        try {
            if (action.equals("org.agoo.android.intent.action.RECEIVE")) {
                handleRemoteMessage(this.mContext, intent);
            } else if ("android.intent.action.PACKAGE_REMOVED".equals(action)) {
                handleRemovePackage(this.mContext, intent);
            } else if (TextUtils.equals(action, "org.agoo.android.intent.action.REPORT") || TextUtils.equals(action, "android.net.conn.CONNECTIVITY_CHANGE") || TextUtils.equals(action, "android.intent.action.BOOT_COMPLETED") || TextUtils.equals(action, "android.intent.action.PACKAGE_ADDED") || TextUtils.equals(action, "android.intent.action.PACKAGE_REPLACED") || TextUtils.equals(action, "android.intent.action.USER_PRESENT") || TextUtils.equals(action, "android.intent.action.ACTION_POWER_CONNECTED") || TextUtils.equals(action, "android.intent.action.ACTION_POWER_DISCONNECTED")) {
                try {
                    ALog.i(TAG, "is report cache msg,Config.isReportCacheMsg(mContext)=" + Config.d(this.mContext), new Object[0]);
                    if (Config.d(this.mContext) && AdapterUtilityImpl.isNetworkConnected(this.mContext)) {
                        Config.e(this.mContext);
                        this.agooFactory.reportCacheMsg();
                        this.messageService.a();
                    }
                    long currentTimeMillis = System.currentTimeMillis();
                    if (ALog.isPrintLog(ALog.Level.I)) {
                        ALog.i(TAG, "is clear all msg=" + Config.b(this.mContext, currentTimeMillis), new Object[0]);
                    }
                    if (Config.b(this.mContext, currentTimeMillis)) {
                        Config.a(this.mContext, currentTimeMillis);
                        this.messageService.a();
                    }
                } catch (Throwable th) {
                    ALog.e(TAG, "reportCacheMsg", th, new Object[0]);
                }
            }
        } finally {
            try {
            } finally {
            }
        }
    }

    public abstract void onMessage(Context context, Intent intent);

    @Deprecated
    public abstract void onRegistered(Context context, String str);

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        ThreadPoolExecutorFactory.execute(new l(this, intent));
        return 2;
    }
}
