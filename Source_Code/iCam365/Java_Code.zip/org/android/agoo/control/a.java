package org.android.agoo.control;

import android.content.Context;
import android.text.TextUtils;
import com.taobao.accs.utl.ALog;
import org.android.agoo.common.Config;
import org.android.agoo.message.MessageService;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes7.dex */
public class a implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ byte[] f49755a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ String f49756b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ AgooFactory f49757c;

    public a(AgooFactory agooFactory, byte[] bArr, String str) {
        this.f49757c = agooFactory;
        this.f49755a = bArr;
        this.f49756b = str;
    }

    @Override // java.lang.Runnable
    public void run() {
        Context context;
        MessageService messageService;
        MessageService messageService2;
        Context context2;
        try {
            String str = new String(this.f49755a, "utf-8");
            JSONArray jSONArray = new JSONArray(str);
            int length = jSONArray.length();
            if (length == 1) {
                String str2 = null;
                String str3 = null;
                for (int i = 0; i < length; i++) {
                    JSONObject jSONObject = jSONArray.getJSONObject(i);
                    if (jSONObject != null) {
                        str2 = jSONObject.getString("i");
                        str3 = jSONObject.getString("p");
                    }
                }
                if (ALog.isPrintLog(ALog.Level.I)) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("saveMsg msgId:");
                    sb.append(str2);
                    sb.append(",message=");
                    sb.append(str);
                    sb.append(",currentPack=");
                    sb.append(str3);
                    sb.append(",reportTimes=");
                    context2 = AgooFactory.mContext;
                    sb.append(Config.f(context2));
                    ALog.i("AgooFactory", sb.toString(), new Object[0]);
                }
                if (!TextUtils.isEmpty(str3)) {
                    context = AgooFactory.mContext;
                    if (TextUtils.equals(str3, context.getPackageName())) {
                        if (TextUtils.isEmpty(this.f49756b)) {
                            messageService2 = this.f49757c.messageService;
                            messageService2.a(str2, str, "0");
                        } else {
                            messageService = this.f49757c.messageService;
                            messageService.a(str2, str, this.f49756b);
                        }
                    }
                }
            }
        } catch (Throwable th) {
            ALog.e("AgooFactory", "saveMsg fail:" + th.toString(), new Object[0]);
        }
    }
}
