package org.android.agoo.control;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;

/* loaded from: classes7.dex */
class j implements ServiceConnection {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ BaseIntentService f49777a;

    public j(BaseIntentService baseIntentService) {
        this.f49777a = baseIntentService;
    }

    @Override // android.content.ServiceConnection
    public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
    }

    @Override // android.content.ServiceConnection
    public void onServiceDisconnected(ComponentName componentName) {
    }
}
