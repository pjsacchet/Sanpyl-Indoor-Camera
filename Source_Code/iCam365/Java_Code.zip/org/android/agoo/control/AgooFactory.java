package org.android.agoo.control;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import com.taobao.accs.base.TaoBaseService;
import com.taobao.accs.client.AdapterGlobalClientInfo;
import com.taobao.accs.common.Constants;
import com.taobao.accs.common.ThreadPoolExecutorFactory;
import com.taobao.accs.dispatch.IntentDispatch;
import com.taobao.accs.utl.ALog;
import com.taobao.accs.utl.AdapterUtilityImpl;
import com.taobao.accs.utl.UTMini;
import com.taobao.accs.utl.UtilityImpl;
import java.util.List;
import javax.crypto.spec.SecretKeySpec;
import org.android.agoo.common.AgooConstants;
import org.android.agoo.common.Config;
import org.android.agoo.common.MsgDO;
import org.android.agoo.message.MessageService;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes7.dex */
public class AgooFactory {
    private static final String DEAL_MESSAGE = "accs.msgRecevie";
    private static final String TAG = "AgooFactory";
    private static AgooFactory instance;
    private static Context mContext;
    private NotifManager notifyManager = null;
    private MessageService messageService = null;

    private AgooFactory(Context context) {
        init(context, null, null);
    }

    private static final boolean checkPackage(Context context, String str) {
        if (context.getPackageManager().getApplicationInfo(str, 0) == null) {
            return false;
        }
        return true;
    }

    private static Bundle getFlag(long j, MsgDO msgDO) {
        Bundle bundle = new Bundle();
        try {
            char[] charArray = Long.toBinaryString(j).toCharArray();
            if (charArray != null && 8 <= charArray.length) {
                if (8 <= charArray.length) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("");
                    sb.append(Integer.parseInt("" + charArray[1] + charArray[2] + charArray[3] + charArray[4], 2));
                    bundle.putString(AgooConstants.MESSAGE_ENCRYPTED, sb.toString());
                    if (charArray[6] == '1') {
                        bundle.putString("report", "1");
                        msgDO.reportStr = "1";
                    }
                    if (charArray[7] == '1') {
                        bundle.putString(AgooConstants.MESSAGE_NOTIFICATION, "1");
                    }
                }
                if (9 <= charArray.length && charArray[8] == '1') {
                    bundle.putString(AgooConstants.MESSAGE_HAS_TEST, "1");
                }
                if (10 <= charArray.length && charArray[9] == '1') {
                    bundle.putString(AgooConstants.MESSAGE_DUPLICATE, "1");
                }
                if (11 <= charArray.length && charArray[10] == '1') {
                    bundle.putInt(AgooConstants.MESSAGE_POPUP, 1);
                }
            }
        } catch (Throwable unused) {
        }
        return bundle;
    }

    public static AgooFactory getInstance(Context context) {
        if (instance == null) {
            synchronized (AgooFactory.class) {
                if (instance == null) {
                    instance = new AgooFactory(context.getApplicationContext());
                }
            }
        }
        return instance;
    }

    private void init(Context context, NotifManager notifManager, MessageService messageService) {
        mContext = context.getApplicationContext();
        this.notifyManager = notifManager;
        if (notifManager == null) {
            this.notifyManager = new NotifManager();
        }
        this.notifyManager.init(mContext);
        this.messageService = messageService;
        if (messageService == null) {
            this.messageService = new MessageService();
        }
        this.messageService.a(mContext);
    }

    public static Bundle msgReceiverPreHandlerOnly(Context context, byte[] bArr, String str, String str2) {
        JSONArray jSONArray;
        if (bArr != null) {
            try {
                if (bArr.length > 0) {
                    String str3 = new String(bArr, "utf-8");
                    if (ALog.isPrintLog(ALog.Level.I)) {
                        ALog.i(TAG, "msgRecevieOnly,message--->[" + str3 + "],utdid=" + AdapterUtilityImpl.getDeviceId(context), new Object[0]);
                    }
                    if (TextUtils.isEmpty(str3)) {
                        ALog.i(TAG, "handleMessage message==null,utdid=" + AdapterUtilityImpl.getDeviceId(context), new Object[0]);
                        return null;
                    }
                    JSONArray jSONArray2 = new JSONArray(str3);
                    int length = jSONArray2.length();
                    Bundle bundle = null;
                    String str4 = null;
                    int i = 0;
                    while (i < length) {
                        bundle = new Bundle();
                        JSONObject jSONObject = jSONArray2.getJSONObject(i);
                        if (jSONObject == null) {
                            jSONArray = jSONArray2;
                        } else {
                            MsgDO msgDO = new MsgDO();
                            String string = jSONObject.getString("p");
                            String string2 = jSONObject.getString("i");
                            String string3 = jSONObject.getString("b");
                            String str5 = str3;
                            long j = jSONObject.getLong("f");
                            if (!jSONObject.isNull("ext")) {
                                str4 = jSONObject.getString("ext");
                            }
                            int i2 = length - 1;
                            msgDO.msgIds = string2;
                            msgDO.extData = str4;
                            msgDO.removePacks = string;
                            msgDO.messageSource = str;
                            if (TextUtils.isEmpty(string3)) {
                                msgDO.errorCode = AgooConstants.ACK_BODY_NULL;
                            } else if (TextUtils.isEmpty(string)) {
                                msgDO.errorCode = AgooConstants.ACK_PACK_NULL;
                            } else if (j == -1) {
                                msgDO.errorCode = AgooConstants.ACK_FLAG_NULL;
                            } else if (!checkPackage(context, string)) {
                                ALog.d(TAG, "msgRecevie checkpackage is del,pack=" + string, new Object[0]);
                                jSONArray = jSONArray2;
                                str3 = str5;
                            } else {
                                Bundle flag = getFlag(j, msgDO);
                                String string4 = flag.getString(AgooConstants.MESSAGE_ENCRYPTED);
                                jSONArray = jSONArray2;
                                if (context.getPackageName().equals(string) && !TextUtils.equals(string4, Integer.toString(4))) {
                                    ALog.e(TAG, "msgRecevie msg encrypted flag not exist, cannot prase!!!", new Object[0]);
                                    msgDO.errorCode = AgooConstants.REPORT_NOT_ENCRYPT;
                                    str3 = str5;
                                }
                                bundle.putAll(flag);
                                try {
                                    String string5 = jSONObject.getString("t");
                                    if (!TextUtils.isEmpty(string5)) {
                                        bundle.putString("time", string5);
                                    }
                                } catch (Throwable unused) {
                                    if (ALog.isPrintLog(ALog.Level.I)) {
                                        ALog.i(TAG, "agoo msg has no time", new Object[0]);
                                    }
                                }
                                bundle.putLong(AgooConstants.MESSAGE_TRACE, System.currentTimeMillis());
                                bundle.putString("id", string2);
                                bundle.putString("body", string3);
                                bundle.putString("source", string);
                                bundle.putString(AgooConstants.MESSAGE_FROM_APPKEY, str2);
                                bundle.putString("extData", str4);
                                str3 = str5;
                                bundle.putString(AgooConstants.MESSAGE_ORI, str3);
                                bundle.putString("type", "common-push");
                                bundle.putString(AgooConstants.MESSAGE_SOURCE, str);
                            }
                            jSONArray = jSONArray2;
                            str3 = str5;
                        }
                        i++;
                        jSONArray2 = jSONArray;
                    }
                    return bundle;
                }
            } catch (Throwable th) {
                if (!ALog.isPrintLog(ALog.Level.E)) {
                    return null;
                }
                ALog.e(TAG, "msgRecevie is error,e=" + th, new Object[0]);
                return null;
            }
        }
        ALog.i(TAG, "handleMessage data==null,utdid=" + AdapterUtilityImpl.getDeviceId(context), new Object[0]);
        return null;
    }

    public static String parseEncryptedMsg(String str) {
        String b2;
        String str2;
        try {
            b2 = Config.b(mContext);
            str2 = AdapterUtilityImpl.mAgooAppSecret;
        } catch (Throwable th) {
            ALog.e(TAG, "parseEncryptedMsg failure: ", th, new Object[0]);
        }
        if (TextUtils.isEmpty(str2)) {
            ALog.e(TAG, "getAppsign secret null", new Object[0]);
            return null;
        }
        List<String> utdids = UtilityImpl.getUtdids(Constants.SP_FILE_NAME, mContext);
        for (int i = 0; i < utdids.size(); i++) {
            String parseEncryptedMsgWithoutAgoo = parseEncryptedMsgWithoutAgoo(str, b2, str2, utdids.get(i));
            if (parseEncryptedMsgWithoutAgoo != null) {
                UtilityImpl.hitUtdid(Constants.SP_FILE_NAME, mContext, utdids.get(i));
                return parseEncryptedMsgWithoutAgoo;
            }
        }
        return null;
    }

    public static String parseEncryptedMsgWithoutAgoo(String str, String str2, String str3, String str4) {
        String str5 = null;
        try {
            byte[] a2 = org.android.agoo.common.a.a(str3.getBytes("utf-8"), (str2 + str4).getBytes("utf-8"));
            if (a2 != null && a2.length > 0) {
                str5 = new String(org.android.agoo.common.a.a(Base64.decode(str, 8), new SecretKeySpec(org.android.agoo.common.a.a(a2), "AES"), org.android.agoo.common.a.a(str2.getBytes("utf-8"))), "utf-8");
            } else {
                ALog.w(TAG, "aesDecrypt key is null!", new Object[0]);
            }
        } catch (Throwable th) {
            ALog.w(TAG, "parseEncryptedMsg body: ", str);
            ALog.w(TAG, "parseEncryptedMsg appKey: ", str2);
            ALog.w(TAG, "parseEncryptedMsg utdid: ", str4);
            ALog.w(TAG, "parseEncryptedMsg failure: ", th, new Object[0]);
        }
        return str5;
    }

    private void sendMsgToBussiness(Context context, String str, Bundle bundle, boolean z, String str2, TaoBaseService.ExtraInfo extraInfo) {
        Intent intent = new Intent();
        intent.setAction("org.agoo.android.intent.action.RECEIVE");
        intent.setPackage(str);
        intent.putExtras(bundle);
        intent.putExtra("type", "common-push");
        intent.putExtra(AgooConstants.MESSAGE_SOURCE, str2);
        intent.addFlags(32);
        try {
            Bundle bundle2 = new Bundle();
            bundle2.putSerializable(AgooConstants.MESSAGE_ACCS_EXTRA, extraInfo);
            intent.putExtra(AgooConstants.MESSAGE_AGOO_BUNDLE, bundle2);
        } catch (Throwable th) {
            ALog.e(TAG, "sendMsgToBussiness", th, new Object[0]);
        }
        if (ALog.isPrintLog(ALog.Level.I)) {
            ALog.i(TAG, "sendMsgToBussiness intent:" + bundle.toString() + ",utdid=" + AdapterUtilityImpl.getDeviceId(context) + ",pack=" + str + ",agooFlag=" + z, new Object[0]);
        }
        if (!z) {
            String agooCustomServiceName = AdapterGlobalClientInfo.getAgooCustomServiceName(context);
            if (TextUtils.isEmpty(agooCustomServiceName)) {
                ALog.e(TAG, "sendMsgToBussiness failed, can not find custom service", new Object[0]);
            } else {
                intent.setClassName(str, agooCustomServiceName);
                IntentDispatch.dispatchIntent(context, intent, agooCustomServiceName);
            }
        }
    }

    public void clickMessage(Context context, String str, String str2) {
        ThreadPoolExecutorFactory.execute(new f(this, str, str2));
    }

    public void dismissMessage(Context context, String str, String str2) {
        ThreadPoolExecutorFactory.execute(new g(this, str, str2));
    }

    public MessageService getMessageService() {
        return this.messageService;
    }

    public NotifManager getNotifyManager() {
        return this.notifyManager;
    }

    public Bundle msgReceiverPreHandler(byte[] bArr, String str, TaoBaseService.ExtraInfo extraInfo, boolean z) {
        JSONArray jSONArray;
        String str2;
        StringBuilder sb;
        boolean z2;
        String str3;
        String str4;
        Bundle bundle;
        StringBuilder sb2;
        String str5;
        int i;
        int i2;
        String str6 = ",";
        String str7 = "ext";
        if (bArr != null) {
            try {
                if (bArr.length > 0) {
                    String str8 = new String(bArr, "utf-8");
                    if (ALog.isPrintLog(ALog.Level.I)) {
                        ALog.i(TAG, "msgRecevie,message--->[" + str8 + "],utdid=" + AdapterUtilityImpl.getDeviceId(mContext), new Object[0]);
                    }
                    if (TextUtils.isEmpty(str8)) {
                        UTMini.getInstance().commitEvent(AgooConstants.AGOO_EVENT_ID, DEAL_MESSAGE, AdapterUtilityImpl.getDeviceId(mContext), "message==null");
                        ALog.i(TAG, "handleMessage message==null,utdid=" + AdapterUtilityImpl.getDeviceId(mContext), new Object[0]);
                        return null;
                    }
                    JSONArray jSONArray2 = new JSONArray(str8);
                    int length = jSONArray2.length();
                    StringBuilder sb3 = new StringBuilder();
                    StringBuilder sb4 = new StringBuilder();
                    Bundle bundle2 = null;
                    String str9 = null;
                    int i3 = 0;
                    while (i3 < length) {
                        Bundle bundle3 = new Bundle();
                        JSONObject jSONObject = jSONArray2.getJSONObject(i3);
                        if (jSONObject == null) {
                            jSONArray = jSONArray2;
                            i = i3;
                            sb2 = sb4;
                            i2 = length;
                            str5 = str8;
                            str3 = str6;
                            str2 = str7;
                            bundle = bundle3;
                            sb = sb3;
                        } else {
                            MsgDO msgDO = new MsgDO();
                            jSONArray = jSONArray2;
                            String string = jSONObject.getString("p");
                            String str10 = str9;
                            String string2 = jSONObject.getString("i");
                            String str11 = str8;
                            String string3 = jSONObject.getString("b");
                            StringBuilder sb5 = sb4;
                            StringBuilder sb6 = sb3;
                            long j = jSONObject.getLong("f");
                            String string4 = !jSONObject.isNull(str7) ? jSONObject.getString(str7) : str10;
                            str2 = str7;
                            int i4 = length - 1;
                            msgDO.msgIds = string2;
                            msgDO.extData = string4;
                            msgDO.removePacks = string;
                            msgDO.messageSource = str;
                            if (TextUtils.isEmpty(string3)) {
                                msgDO.errorCode = AgooConstants.ACK_BODY_NULL;
                                this.notifyManager.handlerACKMessage(msgDO, extraInfo);
                            } else if (TextUtils.isEmpty(string)) {
                                msgDO.errorCode = AgooConstants.ACK_PACK_NULL;
                                this.notifyManager.handlerACKMessage(msgDO, extraInfo);
                            } else if (j == -1) {
                                msgDO.errorCode = AgooConstants.ACK_FLAG_NULL;
                                this.notifyManager.handlerACKMessage(msgDO, extraInfo);
                            } else {
                                int i5 = length;
                                if (!checkPackage(mContext, string)) {
                                    ALog.d(TAG, "msgRecevie checkpackage is del,pack=" + string, new Object[0]);
                                    UTMini.getInstance().commitEvent(AgooConstants.AGOO_EVENT_ID, DEAL_MESSAGE, AdapterUtilityImpl.getDeviceId(mContext), "deletePack", string);
                                    sb5.append(string);
                                    sb6.append(string2);
                                    if (i3 < i4) {
                                        sb5.append(str6);
                                        sb6.append(str6);
                                    }
                                    sb = sb6;
                                    str4 = string4;
                                    i = i3;
                                    sb2 = sb5;
                                    str3 = str6;
                                } else {
                                    sb = sb6;
                                    Bundle flag = getFlag(j, msgDO);
                                    String string5 = flag.getString(AgooConstants.MESSAGE_ENCRYPTED);
                                    int i6 = i3;
                                    if (!mContext.getPackageName().equals(string)) {
                                        z2 = true;
                                    } else if (TextUtils.equals(string5, Integer.toString(4))) {
                                        z2 = false;
                                    } else {
                                        ALog.e(TAG, "msgRecevie msg encrypted flag not exist, cannot prase!!!", new Object[0]);
                                        UTMini.getInstance().commitEvent(AgooConstants.AGOO_EVENT_ID, DEAL_MESSAGE, AdapterUtilityImpl.getDeviceId(mContext), "encrypted!=4", "15");
                                        msgDO.errorCode = AgooConstants.REPORT_NOT_ENCRYPT;
                                        this.notifyManager.handlerACKMessage(msgDO, extraInfo);
                                        str4 = string4;
                                        sb2 = sb5;
                                        str3 = str6;
                                        i = i6;
                                    }
                                    bundle3.putAll(flag);
                                    try {
                                        String string6 = jSONObject.getString("t");
                                        if (!TextUtils.isEmpty(string6)) {
                                            bundle3.putString("time", string6);
                                        }
                                    } catch (Throwable unused) {
                                        if (ALog.isPrintLog(ALog.Level.I)) {
                                            ALog.i(TAG, "agoo msg has no time", new Object[0]);
                                        }
                                    }
                                    str3 = str6;
                                    bundle3.putLong(AgooConstants.MESSAGE_TRACE, System.currentTimeMillis());
                                    bundle3.putString("id", string2);
                                    bundle3.putString("body", string3);
                                    bundle3.putString("source", string);
                                    bundle3.putString(AgooConstants.MESSAGE_FROM_APPKEY, Config.b(mContext));
                                    bundle3.putString("extData", string4);
                                    bundle3.putString(AgooConstants.MESSAGE_ORI, str11);
                                    if (z) {
                                        str4 = string4;
                                        bundle = bundle3;
                                        i = i6;
                                        sb2 = sb5;
                                        sb = sb;
                                        i2 = i5;
                                        str5 = str11;
                                        sendMsgToBussiness(mContext, string, bundle, z2, str, extraInfo);
                                    } else {
                                        str4 = string4;
                                        bundle = bundle3;
                                        sb2 = sb5;
                                        str5 = str11;
                                        i = i6;
                                        sb = sb;
                                        i2 = i5;
                                        bundle.putString("type", "common-push");
                                        bundle.putString(AgooConstants.MESSAGE_SOURCE, str);
                                    }
                                    str9 = str4;
                                }
                                str5 = str11;
                                bundle = bundle3;
                                i2 = i5;
                                str9 = str4;
                            }
                            str4 = string4;
                            i = i3;
                            i2 = length;
                            str3 = str6;
                            str5 = str11;
                            bundle = bundle3;
                            sb = sb6;
                            sb2 = sb5;
                            str9 = str4;
                        }
                        i3 = i + 1;
                        sb4 = sb2;
                        bundle2 = bundle;
                        sb3 = sb;
                        str6 = str3;
                        length = i2;
                        str8 = str5;
                        str7 = str2;
                        jSONArray2 = jSONArray;
                    }
                    StringBuilder sb7 = sb4;
                    StringBuilder sb8 = sb3;
                    if (sb7.length() > 0) {
                        MsgDO msgDO2 = new MsgDO();
                        msgDO2.msgIds = sb8.toString();
                        msgDO2.removePacks = sb7.toString();
                        msgDO2.errorCode = "10";
                        msgDO2.messageSource = str;
                        this.notifyManager.handlerACKMessage(msgDO2, extraInfo);
                    }
                    return bundle2;
                }
            } catch (Throwable th) {
                if (!ALog.isPrintLog(ALog.Level.E)) {
                    return null;
                }
                ALog.e(TAG, "msgRecevie is error,e=" + th, new Object[0]);
                return null;
            }
        }
        UTMini.getInstance().commitEvent(AgooConstants.AGOO_EVENT_ID, DEAL_MESSAGE, AdapterUtilityImpl.getDeviceId(mContext), "data==null");
        ALog.i(TAG, "handleMessage data==null,utdid=" + AdapterUtilityImpl.getDeviceId(mContext), new Object[0]);
        return null;
    }

    public void msgRecevie(byte[] bArr, String str) {
        msgRecevie(bArr, str, null);
    }

    public void reportCacheMsg() {
        try {
            ThreadPoolExecutorFactory.execute(new c(this));
        } catch (Throwable th) {
            ALog.e(TAG, "reportCacheMsg fail:" + th.toString(), new Object[0]);
        }
    }

    public void saveMsg(byte[] bArr) {
        saveMsg(bArr, "0");
    }

    public void updateMsg(byte[] bArr, boolean z) {
        ThreadPoolExecutorFactory.execute(new d(this, bArr, z));
    }

    public void updateMsgStatus(String str, String str2) {
        try {
            if (!TextUtils.isEmpty(str) && !TextUtils.isEmpty(str2)) {
                if (ALog.isPrintLog(ALog.Level.I)) {
                    ALog.i(TAG, "updateNotifyMsg begin,messageId=" + str + ",status=" + str2 + ",reportTimes=" + Config.f(mContext), new Object[0]);
                }
                if (TextUtils.equals(str2, "8")) {
                    this.messageService.a(str, "2");
                } else if (TextUtils.equals(str2, "9")) {
                    this.messageService.a(str, "3");
                }
            }
        } catch (Throwable th) {
            ALog.e(TAG, "updateNotifyMsg e=" + th.toString(), new Object[0]);
        }
    }

    public void updateNotifyMsg(String str, String str2) {
        ThreadPoolExecutorFactory.execute(new e(this, str, str2));
    }

    public void msgRecevie(byte[] bArr, String str, TaoBaseService.ExtraInfo extraInfo) {
        try {
            if (ALog.isPrintLog(ALog.Level.I)) {
                ALog.i(TAG, "into--[AgooFactory,msgRecevie]:messageSource=" + str, new Object[0]);
            }
            ThreadPoolExecutorFactory.execute(new b(this, bArr, str, extraInfo));
        } catch (Throwable th) {
            ALog.e(TAG, "serviceImpl init task fail:" + th.toString(), new Object[0]);
        }
    }

    public void saveMsg(byte[] bArr, String str) {
        if (bArr == null || bArr.length <= 0) {
            return;
        }
        ThreadPoolExecutorFactory.execute(new a(this, bArr, str));
    }
}
