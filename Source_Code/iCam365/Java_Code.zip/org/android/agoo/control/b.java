package org.android.agoo.control;

import com.taobao.accs.base.TaoBaseService;

/* loaded from: classes7.dex */
class b implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ byte[] f49758a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ String f49759b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ TaoBaseService.ExtraInfo f49760c;
    public final /* synthetic */ AgooFactory d;

    public b(AgooFactory agooFactory, byte[] bArr, String str, TaoBaseService.ExtraInfo extraInfo) {
        this.d = agooFactory;
        this.f49758a = bArr;
        this.f49759b = str;
        this.f49760c = extraInfo;
    }

    @Override // java.lang.Runnable
    public void run() {
        this.d.msgReceiverPreHandler(this.f49758a, this.f49759b, this.f49760c, true);
    }
}
