package org.android.agoo.control;

import android.content.Intent;

/* loaded from: classes7.dex */
class l implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Intent f49779a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ BaseIntentService f49780b;

    public l(BaseIntentService baseIntentService, Intent intent) {
        this.f49780b = baseIntentService;
        this.f49779a = intent;
    }

    @Override // java.lang.Runnable
    public void run() {
        this.f49780b.onHandleIntent(this.f49779a);
    }
}
