package org.android.agoo.control;

import com.taobao.accs.client.AdapterGlobalClientInfo;

/* loaded from: classes7.dex */
class k implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ BaseIntentService f49778a;

    public k(BaseIntentService baseIntentService) {
        this.f49778a = baseIntentService;
    }

    @Override // java.lang.Runnable
    public void run() {
        AgooFactory agooFactory;
        AgooFactory agooFactory2;
        AdapterGlobalClientInfo.mStartServiceTimes.incrementAndGet();
        BaseIntentService baseIntentService = this.f49778a;
        baseIntentService.agooFactory = AgooFactory.getInstance(baseIntentService.getApplicationContext());
        BaseIntentService baseIntentService2 = this.f49778a;
        agooFactory = baseIntentService2.agooFactory;
        baseIntentService2.notifyManager = agooFactory.getNotifyManager();
        BaseIntentService baseIntentService3 = this.f49778a;
        agooFactory2 = baseIntentService3.agooFactory;
        baseIntentService3.messageService = agooFactory2.getMessageService();
    }
}
