package org.android.agoo.control;

import com.taobao.accs.utl.ALog;
import java.util.ArrayList;
import java.util.Iterator;
import org.android.agoo.common.MsgDO;
import org.android.agoo.message.MessageService;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes7.dex */
public class c implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ AgooFactory f49761a;

    public c(AgooFactory agooFactory) {
        this.f49761a = agooFactory;
    }

    @Override // java.lang.Runnable
    public void run() {
        MessageService messageService;
        NotifManager notifManager;
        messageService = this.f49761a.messageService;
        ArrayList<MsgDO> b2 = messageService.b();
        if (b2 != null && b2.size() > 0) {
            ALog.e("AgooFactory", "reportCacheMsg", "size", Integer.valueOf(b2.size()));
            Iterator<MsgDO> it = b2.iterator();
            while (it.hasNext()) {
                MsgDO next = it.next();
                if (next != null) {
                    next.isFromCache = true;
                    notifManager = this.f49761a.notifyManager;
                    notifManager.report(next, null);
                }
            }
        }
    }
}
