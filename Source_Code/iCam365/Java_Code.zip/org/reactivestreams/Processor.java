package org.reactivestreams;

/* loaded from: classes7.dex */
public interface Processor<T, R> extends Subscriber<T>, Publisher<R> {
}
