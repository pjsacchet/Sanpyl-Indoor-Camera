package org.intellij.lang.annotations;

/* loaded from: classes7.dex */
public @interface Subst {
    String value();
}
