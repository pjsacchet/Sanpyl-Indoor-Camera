package org.intellij.lang.annotations;

/* loaded from: classes7.dex */
public class JdkConstants {

    /* loaded from: classes7.dex */
    public @interface AdjustableOrientation {
    }

    /* loaded from: classes7.dex */
    public @interface BoxLayoutAxis {
    }

    /* loaded from: classes7.dex */
    public @interface CalendarMonth {
    }

    /* loaded from: classes7.dex */
    public @interface CursorType {
    }

    /* loaded from: classes7.dex */
    public @interface FlowLayoutAlignment {
    }

    /* loaded from: classes7.dex */
    public @interface FontStyle {
    }

    /* loaded from: classes7.dex */
    public @interface HorizontalAlignment {
    }

    /* loaded from: classes7.dex */
    public @interface InputEventMask {
    }

    /* loaded from: classes7.dex */
    public @interface ListSelectionMode {
    }

    /* loaded from: classes7.dex */
    public @interface PatternFlags {
    }

    /* loaded from: classes7.dex */
    public @interface TabLayoutPolicy {
    }

    /* loaded from: classes7.dex */
    public @interface TabPlacement {
    }

    /* loaded from: classes7.dex */
    public @interface TitledBorderJustification {
    }

    /* loaded from: classes7.dex */
    public @interface TitledBorderTitlePosition {
    }

    /* loaded from: classes7.dex */
    public @interface TreeSelectionMode {
    }
}
