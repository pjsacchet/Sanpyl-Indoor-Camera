package org.intellij.lang.annotations;

import p152.C6734;

@Pattern(C6734.f25225)
/* loaded from: classes7.dex */
public @interface PrintFormat {
}
