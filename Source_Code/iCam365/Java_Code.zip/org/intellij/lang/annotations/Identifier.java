package org.intellij.lang.annotations;

@Pattern("\\p{javaJavaIdentifierStart}\\p{javaJavaIdentifierPart}*")
/* loaded from: classes7.dex */
public @interface Identifier {
}
