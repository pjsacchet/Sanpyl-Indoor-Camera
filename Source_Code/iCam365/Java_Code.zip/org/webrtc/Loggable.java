package org.webrtc;

import org.webrtc.Logging;

/* loaded from: classes7.dex */
public interface Loggable {
    void onLogMessage(String str, Logging.Severity severity, String str2);
}
