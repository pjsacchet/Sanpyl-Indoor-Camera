package org.webrtc;

/* loaded from: classes7.dex */
public interface NetEqFactoryFactory {
    long createNativeNetEqFactory();
}
