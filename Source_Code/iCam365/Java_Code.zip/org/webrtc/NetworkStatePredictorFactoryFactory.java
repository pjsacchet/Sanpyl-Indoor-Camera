package org.webrtc;

/* loaded from: classes7.dex */
public interface NetworkStatePredictorFactoryFactory {
    long createNativeNetworkStatePredictorFactory();
}
