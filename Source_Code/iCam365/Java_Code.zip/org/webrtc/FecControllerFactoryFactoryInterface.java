package org.webrtc;

/* loaded from: classes7.dex */
public interface FecControllerFactoryFactoryInterface {
    long createNative();
}
