package org.webrtc;

/* loaded from: classes7.dex */
public interface FrameDecryptor {
    long getNativeFrameDecryptor();
}
