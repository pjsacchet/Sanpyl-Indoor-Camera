package org.webrtc.audio;

/* renamed from: org.webrtc.audio.㫿, reason: contains not printable characters */
/* loaded from: classes7.dex */
public final /* synthetic */ class C5306 {
}
