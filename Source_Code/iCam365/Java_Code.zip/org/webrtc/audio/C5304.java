package org.webrtc.audio;

/* renamed from: org.webrtc.audio.ᇰ, reason: contains not printable characters */
/* loaded from: classes7.dex */
public final /* synthetic */ class C5304 {
}
