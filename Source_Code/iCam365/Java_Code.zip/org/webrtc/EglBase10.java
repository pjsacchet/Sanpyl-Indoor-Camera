package org.webrtc;

import javax.microedition.khronos.egl.EGLContext;
import org.webrtc.EglBase;

/* loaded from: classes7.dex */
public interface EglBase10 extends EglBase {

    /* loaded from: classes7.dex */
    public interface Context extends EglBase.Context {
        EGLContext getRawContext();
    }
}
