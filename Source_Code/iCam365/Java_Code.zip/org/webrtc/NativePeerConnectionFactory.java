package org.webrtc;

/* loaded from: classes7.dex */
public interface NativePeerConnectionFactory {
    long createNativePeerConnection();
}
