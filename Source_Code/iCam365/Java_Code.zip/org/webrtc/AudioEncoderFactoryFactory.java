package org.webrtc;

/* loaded from: classes7.dex */
public interface AudioEncoderFactoryFactory {
    long createNativeAudioEncoderFactory();
}
