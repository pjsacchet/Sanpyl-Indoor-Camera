package org.webrtc;

/* loaded from: classes7.dex */
public interface AudioProcessingFactory {
    long createNative();
}
