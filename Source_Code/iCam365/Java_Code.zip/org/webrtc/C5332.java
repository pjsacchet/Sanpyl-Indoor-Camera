package org.webrtc;

/* renamed from: org.webrtc.㛸, reason: contains not printable characters */
/* loaded from: classes7.dex */
public final /* synthetic */ class C5332 {
}
