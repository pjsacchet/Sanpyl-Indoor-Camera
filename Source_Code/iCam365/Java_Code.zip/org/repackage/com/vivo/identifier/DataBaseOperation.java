package org.repackage.com.vivo.identifier;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;

/* loaded from: classes7.dex */
public class DataBaseOperation {

    /* renamed from: થ, reason: contains not printable characters */
    public static final String f22292 = "OAIDSTATUS";

    /* renamed from: ᇰ, reason: contains not printable characters */
    public static final String f22293 = "VMS_SDK_DB";

    /* renamed from: ᕾ, reason: contains not printable characters */
    public static final int f22294 = 2;

    /* renamed from: ᖁ, reason: contains not printable characters */
    public static final int f22295 = 7;

    /* renamed from: ᝠ, reason: contains not printable characters */
    public static final String f22296 = "OAIDBLACK";

    /* renamed from: ᦜ, reason: contains not printable characters */
    public static final String f22297 = "value";

    /* renamed from: ᵻ, reason: contains not printable characters */
    public static final String f22298 = "STATISTICS";

    /* renamed from: Ⲵ, reason: contains not printable characters */
    public static final int f22299 = 4;

    /* renamed from: ⴄ, reason: contains not printable characters */
    public static final String f22300 = "AAID";

    /* renamed from: ⶂ, reason: contains not printable characters */
    public static final int f22301 = 3;

    /* renamed from: ㄶ, reason: contains not printable characters */
    public static final int f22302 = 6;

    /* renamed from: 㑥, reason: contains not printable characters */
    public static final String f22303 = "UDID";

    /* renamed from: 㛧, reason: contains not printable characters */
    public static final String f22304 = "VAID";

    /* renamed from: 㛸, reason: contains not printable characters */
    public static final int f22305 = 5;

    /* renamed from: 㡷, reason: contains not printable characters */
    public static final String f22306 = "OAID";

    /* renamed from: 㫿, reason: contains not printable characters */
    public static final String f22307 = "content://com.vivo.vms.IdProvider/IdentifierId";

    /* renamed from: 㯿, reason: contains not printable characters */
    public static final String f22308 = "content://com.vivo.abe.exidentifier/guid";

    /* renamed from: 㳏, reason: contains not printable characters */
    public static final int f22309 = 1;

    /* renamed from: 㼬, reason: contains not printable characters */
    public static final int f22310 = 0;

    /* renamed from: 㫞, reason: contains not printable characters */
    public Context f22311;

    public DataBaseOperation(Context context) {
        this.f22311 = context;
    }

    public boolean a(int i, String str, ContentValues[] contentValuesArr) {
        Uri parse;
        int bulkInsert;
        if (i == 6) {
            parse = Uri.parse("content://com.vivo.vms.IdProvider/IdentifierId/OAIDBLACK_" + str);
        } else if (i != 7) {
            parse = null;
        } else {
            parse = Uri.parse("content://com.vivo.vms.IdProvider/IdentifierId/STATISTICS_" + str);
        }
        if (parse == null) {
            return false;
        }
        try {
            bulkInsert = this.f22311.getContentResolver().bulkInsert(parse, contentValuesArr);
            Log.d(f22293, "insert:" + bulkInsert);
        } catch (Exception unused) {
            Log.e(f22293, "return insert is error");
        }
        return bulkInsert != 0;
    }

    /* JADX WARN: Code restructure failed: missing block: B:25:0x0097, code lost:
    
        if (r9 != 0) goto L31;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0099, code lost:
    
        r9.close();
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x00a8, code lost:
    
        return r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x00a5, code lost:
    
        if (r9 == 0) goto L38;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:16:0x006f A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0070 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r9v10, types: [android.database.Cursor] */
    /* JADX WARN: Type inference failed for: r9v24 */
    /* JADX WARN: Type inference failed for: r9v25 */
    /* JADX WARN: Type inference failed for: r9v4 */
    /* JADX WARN: Type inference failed for: r9v5 */
    /* JADX WARN: Type inference failed for: r9v6 */
    /* JADX WARN: Type inference failed for: r9v7 */
    /* JADX WARN: Type inference failed for: r9v8, types: [android.database.Cursor] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public String a(int i, String str) {
        Uri uri;
        Uri uri2;
        ?? r9;
        Cursor cursor = null;
        r1 = null;
        r1 = null;
        r1 = null;
        String str2 = null;
        try {
            if (i == 0) {
                uri = Uri.parse("content://com.vivo.vms.IdProvider/IdentifierId/OAID");
            } else if (i == 1) {
                uri = Uri.parse("content://com.vivo.vms.IdProvider/IdentifierId/VAID_" + str);
            } else if (i == 2) {
                uri = Uri.parse("content://com.vivo.vms.IdProvider/IdentifierId/AAID_" + str);
            } else if (i == 3) {
                uri = Uri.parse("content://com.vivo.vms.IdProvider/IdentifierId/UDID");
            } else if (i == 4) {
                uri = Uri.parse("content://com.vivo.vms.IdProvider/IdentifierId/OAIDSTATUS_" + str);
            } else if (i != 5) {
                uri2 = null;
                r9 = i;
                if (uri2 != null) {
                    return null;
                }
                try {
                    r9 = this.f22311.getContentResolver().query(uri2, null, null, null, null);
                    try {
                        if (r9 != 0) {
                            if (r9.moveToNext()) {
                                str2 = r9.getString(r9.getColumnIndex("value"));
                            }
                        } else {
                            Log.d(f22293, "return cursor is null,return");
                        }
                    } catch (Exception unused) {
                        Log.e(f22293, "return cursor is error");
                    }
                } catch (Exception unused2) {
                    r9 = 0;
                } catch (Throwable th) {
                    th = th;
                    if (cursor != null) {
                        cursor.close();
                    }
                    throw th;
                }
            } else {
                uri = Uri.parse(f22308);
            }
            if (uri2 != null) {
            }
        } catch (Throwable th2) {
            th = th2;
            cursor = r9;
        }
        uri2 = uri;
        r9 = uri;
    }

    public boolean a(int i, String str, String str2, String str3) {
        Uri parse;
        int delete;
        if (i != 6) {
            parse = null;
        } else {
            parse = Uri.parse("content://com.vivo.vms.IdProvider/IdentifierId/OAIDBLACK_" + str);
        }
        if (parse == null) {
            return false;
        }
        try {
            delete = this.f22311.getContentResolver().delete(parse, "packageName=? and uid=?", new String[]{str2, str3});
            Log.d(f22293, "delete:" + delete);
        } catch (Exception unused) {
            Log.e(f22293, "return delete is error");
        }
        return delete != 0;
    }
}
