package org.repackage.com.vivo.identifier;

import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.util.Log;
import com.tange.base.toolkit.DateUtil;
import com.ubixnow.ooooo.o0O0o;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/* loaded from: classes7.dex */
public class IdentifierIdClient {

    /* renamed from: a, reason: collision with root package name */
    public static final String f49807a = "persist.sys.identifierid";

    /* renamed from: થ, reason: contains not printable characters */
    public static final String f22312 = "OAIDSTATUS";

    /* renamed from: ก, reason: contains not printable characters */
    public static final int f22313 = 11;

    /* renamed from: ᄫ, reason: contains not printable characters */
    public static String f22314 = null;

    /* renamed from: ᇰ, reason: contains not printable characters */
    public static final String f22315 = "VMS_SDK_Client";

    /* renamed from: ኦ, reason: contains not printable characters */
    public static String f22316 = null;

    /* renamed from: ᎀ, reason: contains not printable characters */
    public static String f22317 = null;

    /* renamed from: ᒤ, reason: contains not printable characters */
    public static volatile IdentifierIdClient f22318 = null;

    /* renamed from: ᓰ, reason: contains not printable characters */
    public static String f22319 = null;

    /* renamed from: ᕾ, reason: contains not printable characters */
    public static final int f22320 = 2;

    /* renamed from: ᖁ, reason: contains not printable characters */
    public static final int f22321 = 7;

    /* renamed from: ᘣ, reason: contains not printable characters */
    public static int f22322 = 0;

    /* renamed from: ᝠ, reason: contains not printable characters */
    public static final String f22323 = "VAID";

    /* renamed from: ᦜ, reason: contains not printable characters */
    public static final String f22324 = "com.vivo.vms";

    /* renamed from: ᦣ, reason: contains not printable characters */
    public static IdentifierIdObserver f22325 = null;

    /* renamed from: ᨕ, reason: contains not printable characters */
    public static int f22326 = 0;

    /* renamed from: ᴞ, reason: contains not printable characters */
    public static HandlerThread f22327 = null;

    /* renamed from: ᵻ, reason: contains not printable characters */
    public static Object f22328 = new Object();

    /* renamed from: ṭ, reason: contains not printable characters */
    public static Context f22329 = null;

    /* renamed from: ẞ, reason: contains not printable characters */
    public static final int f22330 = 9;

    /* renamed from: ᾈ, reason: contains not printable characters */
    public static int f22331 = 0;

    /* renamed from: ᾮ, reason: contains not printable characters */
    public static int f22332 = 0;

    /* renamed from: ⅹ, reason: contains not printable characters */
    public static int f22333 = 0;

    /* renamed from: Ⱗ, reason: contains not printable characters */
    public static int f22334 = 0;

    /* renamed from: Ⲵ, reason: contains not printable characters */
    public static final int f22335 = 4;

    /* renamed from: ⴄ, reason: contains not printable characters */
    public static final String f22336 = "type";

    /* renamed from: ⴙ, reason: contains not printable characters */
    public static int f22337 = 0;

    /* renamed from: ⶂ, reason: contains not printable characters */
    public static final int f22338 = 3;

    /* renamed from: ㄶ, reason: contains not printable characters */
    public static final int f22339 = 6;

    /* renamed from: ㅇ, reason: contains not printable characters */
    public static int f22340 = 0;

    /* renamed from: ㅒ, reason: contains not printable characters */
    public static IdentifierIdObserver f22341 = null;

    /* renamed from: ㆪ, reason: contains not printable characters */
    public static Handler f22342 = null;

    /* renamed from: 㑥, reason: contains not printable characters */
    public static final int f22343 = 8;

    /* renamed from: 㒡, reason: contains not printable characters */
    public static boolean f22344 = false;

    /* renamed from: 㕊, reason: contains not printable characters */
    public static String f22345 = null;

    /* renamed from: 㘆, reason: contains not printable characters */
    public static final int f22346 = 2000;

    /* renamed from: 㙃, reason: contains not printable characters */
    public static int f22347 = 0;

    /* renamed from: 㛧, reason: contains not printable characters */
    public static final String f22348 = "OAID";

    /* renamed from: 㛸, reason: contains not printable characters */
    public static final int f22349 = 5;

    /* renamed from: 㡡, reason: contains not printable characters */
    public static int f22350 = 13;

    /* renamed from: 㡷, reason: contains not printable characters */
    public static final String f22351 = "appid";

    /* renamed from: 㫿, reason: contains not printable characters */
    public static final String f22352 = "content://com.vivo.vms.IdProvider/IdentifierId";

    /* renamed from: 㯿, reason: contains not printable characters */
    public static final String f22353 = "persist.sys.identifierid.supported";

    /* renamed from: 㰭, reason: contains not printable characters */
    public static IdentifierIdObserver f22354 = null;

    /* renamed from: 㳏, reason: contains not printable characters */
    public static final int f22355 = 1;

    /* renamed from: 㳫, reason: contains not printable characters */
    public static int f22356 = 0;

    /* renamed from: 㴕, reason: contains not printable characters */
    public static String f22357 = null;

    /* renamed from: 㶧, reason: contains not printable characters */
    public static int f22358 = 0;

    /* renamed from: 㻭, reason: contains not printable characters */
    public static IdentifierIdObserver f22359 = null;

    /* renamed from: 㼓, reason: contains not printable characters */
    public static final int f22360 = 10;

    /* renamed from: 㼬, reason: contains not printable characters */
    public static final int f22361 = 0;

    /* renamed from: 䂒, reason: contains not printable characters */
    public static int f22362;

    /* renamed from: 䃔, reason: contains not printable characters */
    public static volatile DataBaseOperation f22363;

    /* renamed from: 䃹, reason: contains not printable characters */
    public static String f22364;

    /* renamed from: 㫞, reason: contains not printable characters */
    public final int f22365;

    /* renamed from: org.repackage.com.vivo.identifier.IdentifierIdClient$ᇰ, reason: contains not printable characters */
    /* loaded from: classes7.dex */
    public class HandlerC5301 extends Handler {
        public HandlerC5301(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            if (message.what == 11) {
                int i = message.getData().getInt("type");
                try {
                    String a2 = IdentifierIdClient.f22363.a(i, message.getData().getString("appid"));
                    if (i == 0) {
                        String unused = IdentifierIdClient.f22357 = a2;
                        IdentifierIdClient.m17619(8, IdentifierIdClient.f22357);
                    } else if (i != 1) {
                        if (i != 2) {
                            if (i != 3) {
                                if (i == 4) {
                                    String unused2 = IdentifierIdClient.f22314 = a2;
                                } else if (i == 5) {
                                    if (a2 != null) {
                                        String unused3 = IdentifierIdClient.f22316 = a2;
                                    } else {
                                        Log.e(IdentifierIdClient.f22315, "get guid failed");
                                    }
                                }
                            } else if (a2 != null) {
                                String unused4 = IdentifierIdClient.f22317 = a2;
                            } else {
                                Log.e(IdentifierIdClient.f22315, "get udid failed");
                            }
                        } else {
                            if (a2 != null) {
                                String unused5 = IdentifierIdClient.f22364 = a2;
                            } else {
                                Log.e(IdentifierIdClient.f22315, "get aaid failed");
                            }
                            IdentifierIdClient.m17619(10, IdentifierIdClient.f22364);
                        }
                    } else {
                        if (a2 != null) {
                            String unused6 = IdentifierIdClient.f22345 = a2;
                        } else {
                            Log.e(IdentifierIdClient.f22315, "get vaid failed");
                        }
                        IdentifierIdClient.m17619(9, IdentifierIdClient.f22345);
                    }
                } catch (Exception e) {
                    Log.e(IdentifierIdClient.f22315, "readException:" + e.toString());
                }
                synchronized (IdentifierIdClient.f22328) {
                    IdentifierIdClient.f22328.notify();
                }
                return;
            }
            Log.e(IdentifierIdClient.f22315, "message type valid");
        }
    }

    /* renamed from: org.repackage.com.vivo.identifier.IdentifierIdClient$㫞, reason: contains not printable characters */
    /* loaded from: classes7.dex */
    public class RunnableC5302 implements Runnable {
        public RunnableC5302() {
        }

        @Override // java.lang.Runnable
        public void run() {
            if (IdentifierIdClient.f22333 + IdentifierIdClient.f22332 + IdentifierIdClient.f22356 + IdentifierIdClient.f22337 + IdentifierIdClient.f22326 + IdentifierIdClient.f22334 + IdentifierIdClient.f22322 + IdentifierIdClient.f22337 + IdentifierIdClient.f22340 + IdentifierIdClient.f22331 + IdentifierIdClient.f22358 + IdentifierIdClient.f22362 > 0) {
                ContentValues contentValues = new ContentValues();
                contentValues.put("oaid", IdentifierIdClient.this.m17625(IdentifierIdClient.f22333, IdentifierIdClient.f22332, IdentifierIdClient.f22356, IdentifierIdClient.f22347));
                contentValues.put("vaid", IdentifierIdClient.this.m17625(IdentifierIdClient.f22326, IdentifierIdClient.f22334, IdentifierIdClient.f22322, IdentifierIdClient.f22337));
                contentValues.put("aaid", IdentifierIdClient.this.m17625(IdentifierIdClient.f22340, IdentifierIdClient.f22331, IdentifierIdClient.f22358, IdentifierIdClient.f22362));
                IdentifierIdClient.f22363.a(7, "vivo", new ContentValues[]{contentValues});
                int unused = IdentifierIdClient.f22333 = IdentifierIdClient.f22332 = IdentifierIdClient.f22326 = IdentifierIdClient.f22334 = IdentifierIdClient.f22340 = IdentifierIdClient.f22331 = 0;
                int unused2 = IdentifierIdClient.f22356 = IdentifierIdClient.f22347 = IdentifierIdClient.f22322 = IdentifierIdClient.f22337 = IdentifierIdClient.f22358 = IdentifierIdClient.f22362 = 0;
            }
        }
    }

    public IdentifierIdClient() {
        m17616();
        f22363 = new DataBaseOperation(f22329);
        this.f22365 = m17618(f22329);
    }

    /* renamed from: ᇰ, reason: contains not printable characters */
    public static void m17616() {
        HandlerThread handlerThread = new HandlerThread("SqlWorkThread");
        f22327 = handlerThread;
        handlerThread.start();
        f22342 = new HandlerC5301(f22327.getLooper());
    }

    /* renamed from: ᦜ, reason: contains not printable characters */
    public static String m17617(String str, String str2) {
        try {
            try {
                Class<?> cls = Class.forName("android.os.SystemProperties");
                return (String) cls.getMethod("get", String.class, String.class).invoke(cls, str, "0");
            } catch (Exception e) {
                Log.e(f22315, "getProperty: invoke is error" + e.getMessage());
                return str2;
            }
        } catch (Throwable unused) {
            return str2;
        }
    }

    /* renamed from: ⴄ, reason: contains not printable characters */
    public static int m17618(Context context) {
        try {
            return context.getPackageManager().getPackageInfo(f22324, 0).versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return 0;
        }
    }

    /* renamed from: 㛧, reason: contains not printable characters */
    public static void m17619(int i, String str) {
        if (i != 0) {
            if (i != 1) {
                if (i != 2) {
                    switch (i) {
                        case 8:
                            if (str == null) {
                                f22347++;
                                return;
                            } else {
                                f22356++;
                                return;
                            }
                        case 9:
                            if (str == null) {
                                f22337++;
                                return;
                            } else {
                                f22322++;
                                return;
                            }
                        case 10:
                            if (str == null) {
                                f22362++;
                                return;
                            } else {
                                f22358++;
                                return;
                            }
                        default:
                            return;
                    }
                }
                if (str == null) {
                    f22331++;
                    return;
                } else {
                    f22340++;
                    return;
                }
            }
            if (str == null) {
                f22334++;
                return;
            } else {
                f22326++;
                return;
            }
        }
        if (str == null) {
            f22332++;
        } else {
            f22333++;
        }
    }

    /* renamed from: 㡷, reason: contains not printable characters */
    public static synchronized void m17620(Context context, int i, String str) {
        synchronized (IdentifierIdClient.class) {
            if (i != 0) {
                if (i != 1) {
                    if (i == 2) {
                        if (f22359 == null) {
                            f22359 = new IdentifierIdObserver(f22318, 2, str);
                            context.getContentResolver().registerContentObserver(Uri.parse("content://com.vivo.vms.IdProvider/IdentifierId/" + context.getPackageName()), false, f22359);
                        }
                    }
                } else if (f22325 == null) {
                    f22325 = new IdentifierIdObserver(f22318, 1, str);
                    context.getContentResolver().registerContentObserver(Uri.parse("content://com.vivo.vms.IdProvider/IdentifierId/VAID_" + str), false, f22325);
                }
            } else if (f22341 == null) {
                f22341 = new IdentifierIdObserver(f22318, 0, null);
                context.getContentResolver().registerContentObserver(Uri.parse("content://com.vivo.vms.IdProvider/IdentifierId/OAID"), true, f22341);
            }
        }
    }

    /* renamed from: 㫿, reason: contains not printable characters */
    public static void m17621() {
        f22344 = "1".equals(m17617("persist.sys.identifierid.supported", "0")) || "1".equals(m17617(f49807a, "0"));
    }

    /* renamed from: થ, reason: contains not printable characters */
    public final void m17622(int i, String str) {
        synchronized (f22328) {
            a(i, str);
            long uptimeMillis = SystemClock.uptimeMillis();
            try {
                f22328.wait(2000L);
            } catch (InterruptedException unused) {
                Log.e(f22315, "queryId: lock error");
            }
            if (SystemClock.uptimeMillis() - uptimeMillis >= 2000) {
                Log.d(f22315, "query timeout");
            }
        }
    }

    /* renamed from: ᝠ, reason: contains not printable characters */
    public final void m17623(int i, String str) {
        a(i, str);
    }

    /* renamed from: 㫞, reason: contains not printable characters */
    public final void m17624() {
        Executors.newScheduledThreadPool(1).scheduleWithFixedDelay(new RunnableC5302(), 600L, 600L, TimeUnit.SECONDS);
    }

    /* renamed from: 㯿, reason: contains not printable characters */
    public final String m17625(int i, int i2, int i3, int i4) {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append(i);
        stringBuffer.append(",");
        stringBuffer.append(i2);
        stringBuffer.append(";");
        stringBuffer.append(i3);
        stringBuffer.append(",");
        stringBuffer.append(i4);
        return stringBuffer.toString();
    }

    public String g() {
        String str = f22364;
        if (str != null) {
            m17619(2, str);
            return f22364;
        }
        m17622(2, "vivo");
        if (f22359 == null) {
            m17620(f22329, 2, "vivo");
        }
        m17619(2, f22364);
        return f22364;
    }

    public String h() {
        String str = f22364;
        if (str != null) {
            m17619(2, str);
            return f22364;
        }
        m17623(2, "vivo");
        if (f22359 == null) {
            m17620(f22329, 2, "vivo");
        }
        m17619(2, f22364);
        return f22364;
    }

    public String i() {
        m17622(4, null);
        return f22314;
    }

    public String j() {
        String str = f22316;
        if (str != null) {
            return str;
        }
        m17622(5, "vivo");
        return f22316;
    }

    public String k() {
        String str = f22316;
        if (str != null) {
            return str;
        }
        m17623(5, "vivo");
        return f22316;
    }

    public String c() {
        String str = f22357;
        if (str != null) {
            m17619(0, str);
            return f22357;
        }
        m17622(0, null);
        if (f22341 == null) {
            m17620(f22329, 0, null);
        }
        m17619(0, f22357);
        return f22357;
    }

    public String d() {
        String str = f22357;
        if (str != null) {
            m17619(0, str);
            return f22357;
        }
        m17623(0, null);
        if (f22341 == null) {
            m17620(f22329, 0, null);
        }
        m17619(0, f22357);
        return f22357;
    }

    public String e() {
        String str = f22345;
        if (str != null) {
            m17619(1, str);
            return f22345;
        }
        m17622(1, "vivo");
        if (f22325 == null) {
            m17620(f22329, 1, "vivo");
        }
        m17619(1, f22345);
        return f22345;
    }

    public String f() {
        String str = f22345;
        if (str != null) {
            m17619(1, str);
            return f22345;
        }
        m17623(1, "vivo");
        if (f22325 == null) {
            m17620(f22329, 1, "vivo");
        }
        m17619(1, f22345);
        return f22345;
    }

    public static IdentifierIdClient a(Context context) {
        if (f22329 == null) {
            if (context == null) {
                return null;
            }
            Context applicationContext = context.getApplicationContext();
            if (applicationContext != null) {
                context = applicationContext;
            }
            f22329 = context;
        }
        if (f22318 == null) {
            synchronized (IdentifierIdClient.class) {
                if (f22318 == null) {
                    f22318 = new IdentifierIdClient();
                    f22318.m17624();
                }
            }
        }
        return f22318;
    }

    public static IdentifierIdClient b(Context context) {
        if (a()) {
            return a(context);
        }
        return null;
    }

    public String b() {
        String str = f22317;
        if (str != null) {
            return str;
        }
        m17622(3, null);
        return f22317;
    }

    public List b(List<String> list) {
        if (this.f22365 < f22350) {
            return null;
        }
        if (list != null && list.size() != 0) {
            try {
                ArrayList arrayList = new ArrayList();
                for (int i = 0; i < list.size(); i++) {
                    String[] split = list.get(i).split(":");
                    if (split.length == 2) {
                        arrayList.add(Boolean.valueOf(f22363.a(6, "vivo", split[0], split[1])));
                    }
                }
                return arrayList;
            } catch (Exception unused) {
                Log.e(f22315, "delete OAIDBLACK failure");
                return null;
            }
        }
        Log.e(f22315, "List is null when delete OAIDBLACK");
        return null;
    }

    public static boolean a() {
        if (!f22344) {
            m17621();
        }
        return f22344;
    }

    public boolean a(List<String> list) {
        if (this.f22365 < f22350) {
            return false;
        }
        if (list != null && list.size() != 0) {
            try {
                ContentValues[] contentValuesArr = new ContentValues[list.size()];
                String format = new SimpleDateFormat(DateUtil.formatYMdHms).format(new Date(System.currentTimeMillis()));
                for (int i = 0; i < list.size(); i++) {
                    ContentValues contentValues = new ContentValues();
                    String[] split = list.get(i).split(":");
                    if (split.length != 2) {
                        return false;
                    }
                    String str = split[0];
                    String str2 = split[1];
                    contentValues.put("packageName", str);
                    contentValues.put(o0O0o.o00O0000, str2);
                    contentValues.put("value", format);
                    contentValuesArr[i] = contentValues;
                }
                return f22363.a(6, "vivo", contentValuesArr);
            } catch (Exception unused) {
                Log.e(f22315, "insert OAIDBLACK failure");
                return false;
            }
        }
        Log.e(f22315, "List is null when insert OAIDBLACK");
        return false;
    }

    public void a(int i, String str) {
        Message obtainMessage = f22342.obtainMessage();
        obtainMessage.what = 11;
        Bundle bundle = new Bundle();
        bundle.putInt("type", i);
        if (i == 1 || i == 2 || i == 6) {
            bundle.putString("appid", str);
        }
        obtainMessage.setData(bundle);
        f22342.sendMessage(obtainMessage);
    }
}
