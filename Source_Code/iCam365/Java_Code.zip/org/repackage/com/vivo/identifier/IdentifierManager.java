package org.repackage.com.vivo.identifier;

import android.content.Context;
import java.util.List;

/* loaded from: classes7.dex */
public class IdentifierManager {
    public static boolean a(Context context) {
        if (IdentifierIdClient.b(context) == null) {
            return false;
        }
        return IdentifierIdClient.a();
    }

    public static String b(Context context) {
        IdentifierIdClient b2 = IdentifierIdClient.b(context);
        if (b2 == null) {
            return null;
        }
        return b2.c();
    }

    public static String c(Context context) {
        IdentifierIdClient b2 = IdentifierIdClient.b(context);
        if (b2 == null) {
            return null;
        }
        return b2.d();
    }

    public static String d(Context context) {
        IdentifierIdClient b2 = IdentifierIdClient.b(context);
        if (b2 == null) {
            return null;
        }
        return b2.e();
    }

    public static String e(Context context) {
        IdentifierIdClient b2 = IdentifierIdClient.b(context);
        if (b2 == null) {
            return null;
        }
        return b2.f();
    }

    public static String f(Context context) {
        IdentifierIdClient b2 = IdentifierIdClient.b(context);
        if (b2 == null) {
            return null;
        }
        return b2.g();
    }

    public static String g(Context context) {
        IdentifierIdClient b2 = IdentifierIdClient.b(context);
        if (b2 == null) {
            return null;
        }
        return b2.h();
    }

    public static String h(Context context) {
        IdentifierIdClient b2 = IdentifierIdClient.b(context);
        if (b2 == null) {
            return null;
        }
        return b2.b();
    }

    public static String i(Context context) {
        IdentifierIdClient b2 = IdentifierIdClient.b(context);
        if (b2 == null) {
            return null;
        }
        return b2.i();
    }

    public static String j(Context context) {
        IdentifierIdClient a2 = IdentifierIdClient.a(context);
        if (a2 == null) {
            return null;
        }
        return a2.j();
    }

    public static String k(Context context) {
        IdentifierIdClient a2 = IdentifierIdClient.a(context);
        if (a2 == null) {
            return null;
        }
        return a2.k();
    }

    public static boolean a(Context context, List<String> list) {
        IdentifierIdClient b2 = IdentifierIdClient.b(context);
        if (b2 == null) {
            return false;
        }
        return b2.a(list);
    }

    public static List b(Context context, List<String> list) {
        IdentifierIdClient b2 = IdentifierIdClient.b(context);
        if (b2 == null) {
            return null;
        }
        return b2.b(list);
    }
}
