package org.repackage.com.vivo.identifier;

/* loaded from: classes7.dex */
public final class BuildConfig {

    /* renamed from: a, reason: collision with root package name */
    public static final boolean f49804a = false;

    /* renamed from: b, reason: collision with root package name */
    public static final String f49805b = "com.vivo.identifier";

    /* renamed from: c, reason: collision with root package name */
    public static final String f49806c = "release";
    public static final String d = "";
    public static final int e = 13;
    public static final String f = "1.0.0.12.jar";
}
