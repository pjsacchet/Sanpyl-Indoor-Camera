package org.repackage.com.vivo.identifier;

import android.database.ContentObserver;
import android.util.Log;

/* loaded from: classes7.dex */
public class IdentifierIdObserver extends ContentObserver {

    /* renamed from: 㯿, reason: contains not printable characters */
    public static final String f22367 = "VMS_SDK_Observer";

    /* renamed from: ᇰ, reason: contains not printable characters */
    public int f22368;

    /* renamed from: 㫞, reason: contains not printable characters */
    public String f22369;

    /* renamed from: 㫿, reason: contains not printable characters */
    public IdentifierIdClient f22370;

    public IdentifierIdObserver(IdentifierIdClient identifierIdClient, int i, String str) {
        super(null);
        this.f22370 = identifierIdClient;
        this.f22368 = i;
        this.f22369 = str;
    }

    @Override // android.database.ContentObserver
    public void onChange(boolean z) {
        IdentifierIdClient identifierIdClient = this.f22370;
        if (identifierIdClient != null) {
            identifierIdClient.a(this.f22368, this.f22369);
        } else {
            Log.e(f22367, "mIdentifierIdClient is null");
        }
    }
}
