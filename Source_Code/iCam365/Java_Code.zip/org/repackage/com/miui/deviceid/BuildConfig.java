package org.repackage.com.miui.deviceid;

/* loaded from: classes7.dex */
public final class BuildConfig {

    /* renamed from: a, reason: collision with root package name */
    public static final boolean f49801a = false;

    /* renamed from: b, reason: collision with root package name */
    public static final String f49802b = "com.miui.deviceid";

    /* renamed from: c, reason: collision with root package name */
    public static final String f49803c = "release";
    public static final String d = "";
    public static final int e = 1;
    public static final String f = "1.0";
}
