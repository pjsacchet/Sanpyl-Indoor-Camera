package org.repackage.com.miui.deviceid;

import android.content.Context;
import android.util.Log;
import java.lang.reflect.Method;

/* loaded from: classes7.dex */
public class IdentifierManager {

    /* renamed from: ᇰ, reason: contains not printable characters */
    public static Object f22285 = null;

    /* renamed from: ᦜ, reason: contains not printable characters */
    public static Method f22286 = null;

    /* renamed from: ⴄ, reason: contains not printable characters */
    public static Method f22287 = null;

    /* renamed from: 㡷, reason: contains not printable characters */
    public static Method f22288 = null;

    /* renamed from: 㫞, reason: contains not printable characters */
    public static final String f22289 = "IdentifierManager";

    /* renamed from: 㫿, reason: contains not printable characters */
    public static Class<?> f22290;

    /* renamed from: 㯿, reason: contains not printable characters */
    public static Method f22291;

    static {
        try {
            Class<?> cls = Class.forName("com.android.id.impl.IdProviderImpl");
            f22290 = cls;
            f22285 = cls.newInstance();
            f22291 = f22290.getMethod("getUDID", Context.class);
            f22286 = f22290.getMethod("getOAID", Context.class);
            f22288 = f22290.getMethod("getVAID", Context.class);
            f22287 = f22290.getMethod("getAAID", Context.class);
        } catch (Exception e) {
            Log.e("IdentifierManager", "reflect exception!", e);
        }
    }

    public static boolean a() {
        return (f22290 == null || f22285 == null) ? false : true;
    }

    public static String b(Context context) {
        return m17615(context, f22286);
    }

    public static String c(Context context) {
        return m17615(context, f22288);
    }

    public static String d(Context context) {
        return m17615(context, f22287);
    }

    /* renamed from: 㫞, reason: contains not printable characters */
    public static String m17615(Context context, Method method) {
        Object obj = f22285;
        if (obj != null && method != null) {
            try {
                Object invoke = method.invoke(obj, context);
                if (invoke != null) {
                    return (String) invoke;
                }
                return null;
            } catch (Exception e) {
                Log.e("IdentifierManager", "invoke exception!", e);
                return null;
            }
        }
        return null;
    }

    public static String a(Context context) {
        return m17615(context, f22291);
    }
}
