package org.repackage.com.zui.opendeviceidlibrary;

/* loaded from: classes7.dex */
public final class BuildConfig {

    /* renamed from: a, reason: collision with root package name */
    public static final boolean f49811a = false;

    /* renamed from: b, reason: collision with root package name */
    public static final String f49812b = "com.zui.opendeviceidlibrary";

    /* renamed from: c, reason: collision with root package name */
    public static final String f49813c = "release";
    public static final String d = "";
    public static final int e = 1;
    public static final String f = "1.0";
}
