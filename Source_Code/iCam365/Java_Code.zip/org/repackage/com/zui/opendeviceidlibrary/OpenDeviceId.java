package org.repackage.com.zui.opendeviceidlibrary;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import org.repackage.com.zui.deviceidservice.IDeviceidInterface;

/* loaded from: classes7.dex */
public class OpenDeviceId {

    /* renamed from: ᦜ, reason: contains not printable characters */
    public static String f22372 = "OpenDeviceId library";

    /* renamed from: 㡷, reason: contains not printable characters */
    public static boolean f22373 = false;

    /* renamed from: ᇰ, reason: contains not printable characters */
    public IDeviceidInterface f22374;

    /* renamed from: 㫿, reason: contains not printable characters */
    public ServiceConnection f22376;

    /* renamed from: 㫞, reason: contains not printable characters */
    public Context f22375 = null;

    /* renamed from: 㯿, reason: contains not printable characters */
    public CallBack f22377 = null;

    /* loaded from: classes7.dex */
    public interface CallBack<T> {
        void a(T t, OpenDeviceId openDeviceId);
    }

    /* renamed from: org.repackage.com.zui.opendeviceidlibrary.OpenDeviceId$㫞, reason: contains not printable characters */
    /* loaded from: classes7.dex */
    public class ServiceConnectionC5303 implements ServiceConnection {
        public ServiceConnectionC5303() {
        }

        @Override // android.content.ServiceConnection
        public synchronized void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            OpenDeviceId.this.f22374 = IDeviceidInterface.Stub.a(iBinder);
            if (OpenDeviceId.this.f22377 != null) {
                OpenDeviceId.this.f22377.a("Deviceid Service Connected", OpenDeviceId.this);
            }
            OpenDeviceId.this.m17627("Service onServiceConnected");
        }

        @Override // android.content.ServiceConnection
        public void onServiceDisconnected(ComponentName componentName) {
            OpenDeviceId.this.f22374 = null;
            OpenDeviceId.this.m17627("Service onServiceDisconnected");
        }
    }

    public String b() {
        if (this.f22375 != null) {
            try {
                IDeviceidInterface iDeviceidInterface = this.f22374;
                if (iDeviceidInterface != null) {
                    return iDeviceidInterface.b();
                }
                return null;
            } catch (RemoteException e) {
                m17626("getUDID error, RemoteException!");
                e.printStackTrace();
                return null;
            } catch (Exception e2) {
                m17626("getUDID error, Exception!");
                e2.printStackTrace();
                return null;
            }
        }
        m17626("Context is null.");
        throw new IllegalArgumentException("Context is null, must be new OpenDeviceId first");
    }

    public boolean c() {
        try {
            if (this.f22374 == null) {
                return false;
            }
            m17627("Device support opendeviceid");
            return this.f22374.c();
        } catch (RemoteException unused) {
            m17626("isSupport error, RemoteException!");
            return false;
        }
    }

    public String d() {
        Context context = this.f22375;
        if (context != null) {
            String packageName = context.getPackageName();
            m17627("liufeng, getVAID package：" + packageName);
            if (packageName != null && !packageName.equals("")) {
                try {
                    IDeviceidInterface iDeviceidInterface = this.f22374;
                    if (iDeviceidInterface != null) {
                        return iDeviceidInterface.a(packageName);
                    }
                    return null;
                } catch (RemoteException e) {
                    m17626("getVAID error, RemoteException!");
                    e.printStackTrace();
                    return null;
                }
            }
            m17627("input package is null!");
            return null;
        }
        m17627("Context is null.");
        throw new IllegalArgumentException("Context is null, must be new OpenDeviceId first");
    }

    public String e() {
        Context context = this.f22375;
        if (context != null) {
            String packageName = context.getPackageName();
            m17627("liufeng, getAAID package：" + packageName);
            String str = null;
            if (packageName != null && !packageName.equals("")) {
                try {
                    IDeviceidInterface iDeviceidInterface = this.f22374;
                    if (iDeviceidInterface == null) {
                        return null;
                    }
                    str = iDeviceidInterface.b(packageName);
                    if ((str == null || "".equals(str)) && this.f22374.c(packageName)) {
                        return this.f22374.b(packageName);
                    }
                    return str;
                } catch (RemoteException unused) {
                    m17626("getAAID error, RemoteException!");
                    return str;
                }
            }
            m17627("input package is null!");
            return null;
        }
        m17627("Context is null.");
        throw new IllegalArgumentException("Context is null, must be new OpenDeviceId first");
    }

    public void f() {
        try {
            this.f22375.unbindService(this.f22376);
            m17627("unBind Service successful");
        } catch (IllegalArgumentException unused) {
            m17626("unBind Service exception");
        }
        this.f22374 = null;
    }

    /* renamed from: ᇰ, reason: contains not printable characters */
    public final void m17626(String str) {
        if (f22373) {
            Log.e(f22372, str);
        }
    }

    /* renamed from: 㫞, reason: contains not printable characters */
    public final void m17627(String str) {
        if (f22373) {
            Log.i(f22372, str);
        }
    }

    public int a(Context context, CallBack<String> callBack) {
        if (context != null) {
            this.f22375 = context;
            this.f22377 = callBack;
            this.f22376 = new ServiceConnectionC5303();
            Intent intent = new Intent();
            intent.setClassName("org.repackage.com.zui.deviceidservice", "org.repackage.com.zui.deviceidservice.DeviceidService");
            if (this.f22375.bindService(intent, this.f22376, 1)) {
                m17627("bindService Successful!");
                return 1;
            }
            m17627("bindService Failed!");
            return -1;
        }
        throw new NullPointerException("Context can not be null.");
    }

    public String a() {
        if (this.f22375 != null) {
            try {
                IDeviceidInterface iDeviceidInterface = this.f22374;
                if (iDeviceidInterface != null) {
                    return iDeviceidInterface.a();
                }
                return null;
            } catch (RemoteException e) {
                m17626("getOAID error, RemoteException!");
                e.printStackTrace();
                return null;
            }
        }
        m17626("Context is null.");
        throw new IllegalArgumentException("Context is null, must be new OpenDeviceId first");
    }

    public void a(boolean z) {
        f22373 = z;
    }
}
