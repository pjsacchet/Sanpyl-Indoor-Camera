package org.repackage.com.meizu.flyme.openidsdk;

import android.content.Context;
import android.util.Log;
import java.lang.reflect.Method;
import p194.C7164;

/* loaded from: classes7.dex */
public class OpenIdHelper {

    /* renamed from: ᇰ, reason: contains not printable characters */
    public static Method f22283 = null;

    /* renamed from: 㫞, reason: contains not printable characters */
    public static final String f22284 = "OpenIdHelper";

    public static String a(Context context) {
        C7164 m18706 = C7164.m18706();
        return m18706.m18710(context.getApplicationContext(), m18706.f25746);
    }

    public static void a(boolean z) {
        C7164.m18706();
        C7164.m18704(z);
    }

    public static final boolean a() {
        Context context = null;
        try {
            if (f22283 == null) {
                Method method = Class.forName("android.app.ActivityThread").getMethod("currentApplication", new Class[0]);
                f22283 = method;
                method.setAccessible(true);
            }
            context = (Context) f22283.invoke(null, new Object[0]);
        } catch (Exception e) {
            Log.e("OpenIdHelper", "ActivityThread:currentApplication --> " + e.toString());
        }
        if (context == null) {
            return false;
        }
        return C7164.m18706().m18709(context, false);
    }

    public static String b(Context context) {
        C7164 m18706 = C7164.m18706();
        return m18706.m18710(context.getApplicationContext(), m18706.f25743);
    }

    public static String c(Context context) {
        C7164 m18706 = C7164.m18706();
        return m18706.m18710(context.getApplicationContext(), m18706.f25748);
    }

    public static String d(Context context) {
        C7164 m18706 = C7164.m18706();
        return m18706.m18710(context.getApplicationContext(), m18706.f25747);
    }
}
