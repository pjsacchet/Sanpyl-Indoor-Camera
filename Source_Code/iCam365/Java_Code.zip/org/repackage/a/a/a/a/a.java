package org.repackage.a.a.a.a;

/* loaded from: classes7.dex */
public class a {

    /* renamed from: a, reason: collision with root package name */
    public static boolean f49793a = false;

    /* renamed from: b, reason: collision with root package name */
    public static boolean f49794b = false;
}
