package org.repackage.a.a.a;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import com.qy.sdk.heytap.openid.IOpenID;

/* loaded from: classes7.dex */
public interface a extends IInterface {

    /* renamed from: org.repackage.a.a.a.a$a, reason: collision with other inner class name */
    /* loaded from: classes7.dex */
    public static abstract class AbstractBinderC5299a extends Binder implements a {

        /* renamed from: org.repackage.a.a.a.a$a$a, reason: collision with other inner class name */
        /* loaded from: classes7.dex */
        public static class C5300a implements a {

            /* renamed from: a, reason: collision with root package name */
            public IBinder f49795a;

            public C5300a(IBinder iBinder) {
                this.f49795a = iBinder;
            }

            public String a(String str, String str2, String str3) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IOpenID.Stub.DESCRIPTOR);
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeString(str3);
                    this.f49795a.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readString();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.f49795a;
            }
        }

        public static a a(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface(IOpenID.Stub.DESCRIPTOR);
            if (queryLocalInterface != null && (queryLocalInterface instanceof a)) {
                return (a) queryLocalInterface;
            }
            return new C5300a(iBinder);
        }
    }
}
