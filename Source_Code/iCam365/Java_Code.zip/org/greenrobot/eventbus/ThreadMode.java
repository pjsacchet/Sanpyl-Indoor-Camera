package org.greenrobot.eventbus;

/* loaded from: classes7.dex */
public enum ThreadMode {
    POSTING,
    MAIN,
    BACKGROUND,
    ASYNC
}
