package org.greenrobot.eventbus;

import java.lang.reflect.Method;

/* loaded from: classes7.dex */
public class SubscriberMethod {
    public final Class<?> eventType;
    public final Method method;
    public String methodString;
    public final int priority;
    public final boolean sticky;
    public final ThreadMode threadMode;

    public SubscriberMethod(Method method, Class<?> cls, ThreadMode threadMode, int i, boolean z) {
        this.method = method;
        this.threadMode = threadMode;
        this.eventType = cls;
        this.priority = i;
        this.sticky = z;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof SubscriberMethod) {
            m17610();
            SubscriberMethod subscriberMethod = (SubscriberMethod) obj;
            subscriberMethod.m17610();
            return this.methodString.equals(subscriberMethod.methodString);
        }
        return false;
    }

    public int hashCode() {
        return this.method.hashCode();
    }

    /* renamed from: 㫞, reason: contains not printable characters */
    public final synchronized void m17610() {
        if (this.methodString == null) {
            StringBuilder sb = new StringBuilder(64);
            sb.append(this.method.getDeclaringClass().getName());
            sb.append('#');
            sb.append(this.method.getName());
            sb.append('(');
            sb.append(this.eventType.getName());
            this.methodString = sb.toString();
        }
    }
}
