package org.greenrobot.eventbus.util;

/* loaded from: classes7.dex */
public class ThrowableFailureEvent implements HasExecutionScope {
    public final boolean suppressErrorUi;
    public final Throwable throwable;

    /* renamed from: 㫞, reason: contains not printable characters */
    public Object f22119;

    public ThrowableFailureEvent(Throwable th) {
        this.throwable = th;
        this.suppressErrorUi = false;
    }

    @Override // org.greenrobot.eventbus.util.HasExecutionScope
    public Object getExecutionScope() {
        return this.f22119;
    }

    public Throwable getThrowable() {
        return this.throwable;
    }

    public boolean isSuppressErrorUi() {
        return this.suppressErrorUi;
    }

    @Override // org.greenrobot.eventbus.util.HasExecutionScope
    public void setExecutionScope(Object obj) {
        this.f22119 = obj;
    }

    public ThrowableFailureEvent(Throwable th, boolean z) {
        this.throwable = th;
        this.suppressErrorUi = z;
    }
}
