package org.greenrobot.eventbus.util;

import android.app.Activity;
import android.util.Log;
import java.lang.reflect.Constructor;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import org.greenrobot.eventbus.EventBus;

/* loaded from: classes7.dex */
public class AsyncExecutor {

    /* renamed from: ᇰ, reason: contains not printable characters */
    public final Constructor<?> f22105;

    /* renamed from: 㫞, reason: contains not printable characters */
    public final Executor f22106;

    /* renamed from: 㫿, reason: contains not printable characters */
    public final EventBus f22107;

    /* renamed from: 㯿, reason: contains not printable characters */
    public final Object f22108;

    /* loaded from: classes7.dex */
    public static class Builder {

        /* renamed from: ᇰ, reason: contains not printable characters */
        public Class<?> f22109;

        /* renamed from: 㫞, reason: contains not printable characters */
        public Executor f22110;

        /* renamed from: 㫿, reason: contains not printable characters */
        public EventBus f22111;

        public /* synthetic */ Builder(RunnableC5297 runnableC5297) {
            this();
        }

        public AsyncExecutor build() {
            return buildForScope(null);
        }

        public AsyncExecutor buildForActivityScope(Activity activity) {
            return buildForScope(activity.getClass());
        }

        public AsyncExecutor buildForScope(Object obj) {
            if (this.f22111 == null) {
                this.f22111 = EventBus.getDefault();
            }
            if (this.f22110 == null) {
                this.f22110 = Executors.newCachedThreadPool();
            }
            if (this.f22109 == null) {
                this.f22109 = ThrowableFailureEvent.class;
            }
            return new AsyncExecutor(this.f22110, this.f22111, this.f22109, obj, null);
        }

        public Builder eventBus(EventBus eventBus) {
            this.f22111 = eventBus;
            return this;
        }

        public Builder failureEventType(Class<?> cls) {
            this.f22109 = cls;
            return this;
        }

        public Builder threadPool(Executor executor) {
            this.f22110 = executor;
            return this;
        }

        public Builder() {
        }
    }

    /* loaded from: classes7.dex */
    public interface RunnableEx {
        void run() throws Exception;
    }

    /* renamed from: org.greenrobot.eventbus.util.AsyncExecutor$㫞, reason: contains not printable characters */
    /* loaded from: classes7.dex */
    public class RunnableC5297 implements Runnable {

        /* renamed from: 㫞, reason: contains not printable characters */
        public final /* synthetic */ RunnableEx f22113;

        public RunnableC5297(RunnableEx runnableEx) {
            this.f22113 = runnableEx;
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                this.f22113.run();
            } catch (Exception e) {
                try {
                    Object newInstance = AsyncExecutor.this.f22105.newInstance(e);
                    if (newInstance instanceof HasExecutionScope) {
                        ((HasExecutionScope) newInstance).setExecutionScope(AsyncExecutor.this.f22108);
                    }
                    AsyncExecutor.this.f22107.post(newInstance);
                } catch (Exception e2) {
                    Log.e(EventBus.TAG, "Original exception:", e);
                    throw new RuntimeException("Could not create failure event", e2);
                }
            }
        }
    }

    public /* synthetic */ AsyncExecutor(Executor executor, EventBus eventBus, Class cls, Object obj, RunnableC5297 runnableC5297) {
        this(executor, eventBus, cls, obj);
    }

    public static Builder builder() {
        return new Builder(null);
    }

    public static AsyncExecutor create() {
        return new Builder(null).build();
    }

    public void execute(RunnableEx runnableEx) {
        this.f22106.execute(new RunnableC5297(runnableEx));
    }

    public AsyncExecutor(Executor executor, EventBus eventBus, Class<?> cls, Object obj) {
        this.f22106 = executor;
        this.f22107 = eventBus;
        this.f22108 = obj;
        try {
            this.f22105 = cls.getConstructor(Throwable.class);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException("Failure event class must have a constructor with one parameter of type Throwable", e);
        }
    }
}
