package org.greenrobot.eventbus.util;

/* loaded from: classes7.dex */
public interface HasExecutionScope {
    Object getExecutionScope();

    void setExecutionScope(Object obj);
}
