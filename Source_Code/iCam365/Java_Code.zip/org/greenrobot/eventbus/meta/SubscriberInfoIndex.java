package org.greenrobot.eventbus.meta;

/* loaded from: classes7.dex */
public interface SubscriberInfoIndex {
    SubscriberInfo getSubscriberInfo(Class<?> cls);
}
