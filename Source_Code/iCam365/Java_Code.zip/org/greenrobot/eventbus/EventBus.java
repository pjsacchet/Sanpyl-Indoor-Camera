package org.greenrobot.eventbus;

import android.os.Looper;
import android.util.Log;
import j$.util.concurrent.ConcurrentHashMap;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import org.greenrobot.eventbus.meta.SubscriberInfoIndex;
import p110.C6542;
import p110.C6543;
import p110.C6547;
import p110.HandlerC6546;
import p110.RunnableC6540;
import p110.RunnableC6545;

/* loaded from: classes7.dex */
public class EventBus {
    public static String TAG = "EventBus";
    public static volatile EventBus defaultInstance;

    /* renamed from: થ, reason: contains not printable characters */
    public final boolean f22076;

    /* renamed from: ᇰ, reason: contains not printable characters */
    public final Map<Object, List<Class<?>>> f22077;

    /* renamed from: ᕾ, reason: contains not printable characters */
    public final boolean f22078;

    /* renamed from: ᝠ, reason: contains not printable characters */
    public final ExecutorService f22079;

    /* renamed from: ᦜ, reason: contains not printable characters */
    public final HandlerC6546 f22080;

    /* renamed from: ᵻ, reason: contains not printable characters */
    public final boolean f22081;

    /* renamed from: Ⲵ, reason: contains not printable characters */
    public final int f22082;

    /* renamed from: ⴄ, reason: contains not printable characters */
    public final RunnableC6545 f22083;

    /* renamed from: ⶂ, reason: contains not printable characters */
    public final boolean f22084;

    /* renamed from: 㛧, reason: contains not printable characters */
    public final C6543 f22085;

    /* renamed from: 㡷, reason: contains not printable characters */
    public final RunnableC6540 f22086;

    /* renamed from: 㫞, reason: contains not printable characters */
    public final Map<Class<?>, CopyOnWriteArrayList<C6542>> f22087;

    /* renamed from: 㫿, reason: contains not printable characters */
    public final Map<Class<?>, Object> f22088;

    /* renamed from: 㯿, reason: contains not printable characters */
    public final ThreadLocal<C5296> f22089;

    /* renamed from: 㳏, reason: contains not printable characters */
    public final boolean f22090;

    /* renamed from: 㼬, reason: contains not printable characters */
    public final boolean f22091;

    /* renamed from: 㛸, reason: contains not printable characters */
    public static final EventBusBuilder f22075 = new EventBusBuilder();

    /* renamed from: ㄶ, reason: contains not printable characters */
    public static final Map<Class<?>, List<Class<?>>> f22074 = new HashMap();

    /* renamed from: org.greenrobot.eventbus.EventBus$ᇰ, reason: contains not printable characters */
    /* loaded from: classes7.dex */
    public static /* synthetic */ class C5293 {

        /* renamed from: 㫞, reason: contains not printable characters */
        public static final /* synthetic */ int[] f22092;

        static {
            int[] iArr = new int[ThreadMode.values().length];
            f22092 = iArr;
            try {
                iArr[ThreadMode.POSTING.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f22092[ThreadMode.MAIN.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f22092[ThreadMode.BACKGROUND.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f22092[ThreadMode.ASYNC.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
        }
    }

    /* renamed from: org.greenrobot.eventbus.EventBus$㫞, reason: contains not printable characters */
    /* loaded from: classes7.dex */
    public class C5294 extends ThreadLocal<C5296> {
        public C5294() {
        }

        @Override // java.lang.ThreadLocal
        /* renamed from: 㫞, reason: contains not printable characters and merged with bridge method [inline-methods] */
        public C5296 initialValue() {
            return new C5296();
        }
    }

    /* renamed from: org.greenrobot.eventbus.EventBus$㫿, reason: contains not printable characters */
    /* loaded from: classes7.dex */
    public interface InterfaceC5295 {
        /* renamed from: 㫞, reason: contains not printable characters */
        void m17609(List<SubscriberExceptionEvent> list);
    }

    /* renamed from: org.greenrobot.eventbus.EventBus$㯿, reason: contains not printable characters */
    /* loaded from: classes7.dex */
    public static final class C5296 {

        /* renamed from: ᇰ, reason: contains not printable characters */
        public boolean f22094;

        /* renamed from: ᦜ, reason: contains not printable characters */
        public Object f22095;

        /* renamed from: 㡷, reason: contains not printable characters */
        public boolean f22096;

        /* renamed from: 㫞, reason: contains not printable characters */
        public final List<Object> f22097 = new ArrayList();

        /* renamed from: 㫿, reason: contains not printable characters */
        public boolean f22098;

        /* renamed from: 㯿, reason: contains not printable characters */
        public C6542 f22099;
    }

    public EventBus() {
        this(f22075);
    }

    public static void addInterfaces(List<Class<?>> list, Class<?>[] clsArr) {
        for (Class<?> cls : clsArr) {
            if (!list.contains(cls)) {
                list.add(cls);
                addInterfaces(list, cls.getInterfaces());
            }
        }
    }

    public static EventBusBuilder builder() {
        return new EventBusBuilder();
    }

    public static void clearCaches() {
        C6543.m18628();
        f22074.clear();
    }

    public static EventBus getDefault() {
        if (defaultInstance == null) {
            synchronized (EventBus.class) {
                if (defaultInstance == null) {
                    defaultInstance = new EventBus();
                }
            }
        }
        return defaultInstance;
    }

    /* renamed from: 㫿, reason: contains not printable characters */
    public static List<Class<?>> m17600(Class<?> cls) {
        List<Class<?>> list;
        Map<Class<?>, List<Class<?>>> map = f22074;
        synchronized (map) {
            list = map.get(cls);
            if (list == null) {
                list = new ArrayList<>();
                for (Class<?> cls2 = cls; cls2 != null; cls2 = cls2.getSuperclass()) {
                    list.add(cls2);
                    addInterfaces(list, cls2.getInterfaces());
                }
                f22074.put(cls, list);
            }
        }
        return list;
    }

    public void cancelEventDelivery(Object obj) {
        C5296 c5296 = this.f22089.get();
        if (c5296.f22094) {
            if (obj != null) {
                if (c5296.f22095 == obj) {
                    if (c5296.f22099.f24963.threadMode == ThreadMode.POSTING) {
                        c5296.f22096 = true;
                        return;
                    }
                    throw new EventBusException(" event handlers may only abort the incoming event");
                }
                throw new EventBusException("Only the currently handled event may be aborted");
            }
            throw new EventBusException("Event may not be null");
        }
        throw new EventBusException("This method may only be called from inside event handling methods on the posting thread");
    }

    public ExecutorService getExecutorService() {
        return this.f22079;
    }

    public <T> T getStickyEvent(Class<T> cls) {
        T cast;
        synchronized (this.f22088) {
            cast = cls.cast(this.f22088.get(cls));
        }
        return cast;
    }

    public boolean hasSubscriberForEvent(Class<?> cls) {
        CopyOnWriteArrayList<C6542> copyOnWriteArrayList;
        List<Class<?>> m17600 = m17600(cls);
        if (m17600 != null) {
            int size = m17600.size();
            for (int i = 0; i < size; i++) {
                Class<?> cls2 = m17600.get(i);
                synchronized (this) {
                    copyOnWriteArrayList = this.f22087.get(cls2);
                }
                if (copyOnWriteArrayList != null && !copyOnWriteArrayList.isEmpty()) {
                    return true;
                }
            }
        }
        return false;
    }

    public void invokeSubscriber(C6547 c6547) {
        Object obj = c6547.f24991;
        C6542 c6542 = c6547.f24990;
        C6547.m18643(c6547);
        if (c6542.f24965) {
            invokeSubscriber(c6542, obj);
        }
    }

    public synchronized boolean isRegistered(Object obj) {
        return this.f22077.containsKey(obj);
    }

    public void post(Object obj) {
        boolean z;
        C5296 c5296 = this.f22089.get();
        List<Object> list = c5296.f22097;
        list.add(obj);
        if (!c5296.f22094) {
            if (Looper.getMainLooper() == Looper.myLooper()) {
                z = true;
            } else {
                z = false;
            }
            c5296.f22098 = z;
            c5296.f22094 = true;
            if (!c5296.f22096) {
                while (!list.isEmpty()) {
                    try {
                        m17607(list.remove(0), c5296);
                    } finally {
                        c5296.f22094 = false;
                        c5296.f22098 = false;
                    }
                }
                return;
            }
            throw new EventBusException("Internal error. Abort state was not reset");
        }
    }

    public void postSticky(Object obj) {
        synchronized (this.f22088) {
            this.f22088.put(obj.getClass(), obj);
        }
        post(obj);
    }

    public void register(Object obj) {
        List<SubscriberMethod> m18629 = this.f22085.m18629(obj.getClass());
        synchronized (this) {
            Iterator<SubscriberMethod> it = m18629.iterator();
            while (it.hasNext()) {
                m17603(obj, it.next());
            }
        }
    }

    public void removeAllStickyEvents() {
        synchronized (this.f22088) {
            this.f22088.clear();
        }
    }

    public <T> T removeStickyEvent(Class<T> cls) {
        T cast;
        synchronized (this.f22088) {
            cast = cls.cast(this.f22088.remove(cls));
        }
        return cast;
    }

    public String toString() {
        return "EventBus[indexCount=" + this.f22082 + ", eventInheritance=" + this.f22084 + "]";
    }

    public synchronized void unregister(Object obj) {
        List<Class<?>> list = this.f22077.get(obj);
        if (list != null) {
            Iterator<Class<?>> it = list.iterator();
            while (it.hasNext()) {
                m17604(obj, it.next());
            }
            this.f22077.remove(obj);
        } else {
            Log.w(TAG, "Subscriber to unregister was not registered before: " + obj.getClass());
        }
    }

    /* renamed from: ᇰ, reason: contains not printable characters */
    public final void m17601(C6542 c6542, Object obj, Throwable th) {
        if (obj instanceof SubscriberExceptionEvent) {
            if (this.f22081) {
                Log.e(TAG, "SubscriberExceptionEvent subscriber " + c6542.f24964.getClass() + " threw an exception", th);
                SubscriberExceptionEvent subscriberExceptionEvent = (SubscriberExceptionEvent) obj;
                Log.e(TAG, "Initial event " + subscriberExceptionEvent.causingEvent + " caused exception in " + subscriberExceptionEvent.causingSubscriber, subscriberExceptionEvent.throwable);
                return;
            }
            return;
        }
        if (!this.f22076) {
            if (this.f22081) {
                Log.e(TAG, "Could not dispatch event: " + obj.getClass() + " to subscribing class " + c6542.f24964.getClass(), th);
            }
            if (this.f22090) {
                post(new SubscriberExceptionEvent(this, th, obj, c6542.f24964));
                return;
            }
            return;
        }
        throw new EventBusException("Invoking subscriber failed", th);
    }

    /* renamed from: ᦜ, reason: contains not printable characters */
    public final boolean m17602(Object obj, C5296 c5296, Class<?> cls) {
        CopyOnWriteArrayList<C6542> copyOnWriteArrayList;
        synchronized (this) {
            copyOnWriteArrayList = this.f22087.get(cls);
        }
        if (copyOnWriteArrayList == null || copyOnWriteArrayList.isEmpty()) {
            return false;
        }
        Iterator<C6542> it = copyOnWriteArrayList.iterator();
        while (it.hasNext()) {
            C6542 next = it.next();
            c5296.f22095 = obj;
            c5296.f22099 = next;
            try {
                m17605(next, obj, c5296.f22098);
                if (c5296.f22096) {
                    return true;
                }
            } finally {
                c5296.f22095 = null;
                c5296.f22099 = null;
                c5296.f22096 = false;
            }
        }
        return true;
    }

    /* renamed from: ⴄ, reason: contains not printable characters */
    public final void m17603(Object obj, SubscriberMethod subscriberMethod) {
        Class<?> cls = subscriberMethod.eventType;
        C6542 c6542 = new C6542(obj, subscriberMethod);
        CopyOnWriteArrayList<C6542> copyOnWriteArrayList = this.f22087.get(cls);
        if (copyOnWriteArrayList == null) {
            copyOnWriteArrayList = new CopyOnWriteArrayList<>();
            this.f22087.put(cls, copyOnWriteArrayList);
        } else if (copyOnWriteArrayList.contains(c6542)) {
            throw new EventBusException("Subscriber " + obj.getClass() + " already registered to event " + cls);
        }
        int size = copyOnWriteArrayList.size();
        for (int i = 0; i <= size; i++) {
            if (i == size || subscriberMethod.priority > copyOnWriteArrayList.get(i).f24963.priority) {
                copyOnWriteArrayList.add(i, c6542);
                break;
            }
        }
        List<Class<?>> list = this.f22077.get(obj);
        if (list == null) {
            list = new ArrayList<>();
            this.f22077.put(obj, list);
        }
        list.add(cls);
        if (subscriberMethod.sticky) {
            if (this.f22084) {
                for (Map.Entry<Class<?>, Object> entry : this.f22088.entrySet()) {
                    if (cls.isAssignableFrom(entry.getKey())) {
                        m17606(c6542, entry.getValue());
                    }
                }
                return;
            }
            m17606(c6542, this.f22088.get(cls));
        }
    }

    /* renamed from: 㛧, reason: contains not printable characters */
    public final void m17604(Object obj, Class<?> cls) {
        CopyOnWriteArrayList<C6542> copyOnWriteArrayList = this.f22087.get(cls);
        if (copyOnWriteArrayList != null) {
            int size = copyOnWriteArrayList.size();
            int i = 0;
            while (i < size) {
                C6542 c6542 = copyOnWriteArrayList.get(i);
                if (c6542.f24964 == obj) {
                    c6542.f24965 = false;
                    copyOnWriteArrayList.remove(i);
                    i--;
                    size--;
                }
                i++;
            }
        }
    }

    /* renamed from: 㡷, reason: contains not printable characters */
    public final void m17605(C6542 c6542, Object obj, boolean z) {
        int i = C5293.f22092[c6542.f24963.threadMode.ordinal()];
        if (i != 1) {
            if (i != 2) {
                if (i != 3) {
                    if (i == 4) {
                        this.f22083.m18641(c6542, obj);
                        return;
                    }
                    throw new IllegalStateException("Unknown thread mode: " + c6542.f24963.threadMode);
                }
                if (z) {
                    this.f22086.m18624(c6542, obj);
                    return;
                } else {
                    invokeSubscriber(c6542, obj);
                    return;
                }
            }
            if (z) {
                invokeSubscriber(c6542, obj);
                return;
            } else {
                this.f22080.m18642(c6542, obj);
                return;
            }
        }
        invokeSubscriber(c6542, obj);
    }

    /* renamed from: 㫞, reason: contains not printable characters */
    public final void m17606(C6542 c6542, Object obj) {
        if (obj != null) {
            m17605(c6542, obj, Looper.getMainLooper() == Looper.myLooper());
        }
    }

    /* renamed from: 㯿, reason: contains not printable characters */
    public final void m17607(Object obj, C5296 c5296) throws Error {
        boolean m17602;
        Class<?> cls = obj.getClass();
        if (this.f22084) {
            List<Class<?>> m17600 = m17600(cls);
            int size = m17600.size();
            m17602 = false;
            for (int i = 0; i < size; i++) {
                m17602 |= m17602(obj, c5296, m17600.get(i));
            }
        } else {
            m17602 = m17602(obj, c5296, cls);
        }
        if (!m17602) {
            if (this.f22091) {
                Log.d(TAG, "No subscribers registered for event " + cls);
            }
            if (this.f22078 && cls != NoSubscriberEvent.class && cls != SubscriberExceptionEvent.class) {
                post(new NoSubscriberEvent(this, obj));
            }
        }
    }

    public EventBus(EventBusBuilder eventBusBuilder) {
        this.f22089 = new C5294();
        this.f22087 = new HashMap();
        this.f22077 = new HashMap();
        this.f22088 = new ConcurrentHashMap();
        this.f22080 = new HandlerC6546(this, Looper.getMainLooper(), 10);
        this.f22086 = new RunnableC6540(this);
        this.f22083 = new RunnableC6545(this);
        List<SubscriberInfoIndex> list = eventBusBuilder.subscriberInfoIndexes;
        this.f22082 = list != null ? list.size() : 0;
        this.f22085 = new C6543(eventBusBuilder.subscriberInfoIndexes, eventBusBuilder.strictMethodVerification, eventBusBuilder.ignoreGeneratedIndex);
        this.f22081 = eventBusBuilder.logSubscriberExceptions;
        this.f22091 = eventBusBuilder.logNoSubscriberMessages;
        this.f22090 = eventBusBuilder.sendSubscriberExceptionEvent;
        this.f22078 = eventBusBuilder.sendNoSubscriberEvent;
        this.f22076 = eventBusBuilder.throwSubscriberException;
        this.f22084 = eventBusBuilder.eventInheritance;
        this.f22079 = eventBusBuilder.executorService;
    }

    public boolean removeStickyEvent(Object obj) {
        synchronized (this.f22088) {
            Class<?> cls = obj.getClass();
            if (!obj.equals(this.f22088.get(cls))) {
                return false;
            }
            this.f22088.remove(cls);
            return true;
        }
    }

    public void invokeSubscriber(C6542 c6542, Object obj) {
        try {
            c6542.f24963.method.invoke(c6542.f24964, obj);
        } catch (IllegalAccessException e) {
            throw new IllegalStateException("Unexpected exception", e);
        } catch (InvocationTargetException e2) {
            m17601(c6542, obj, e2.getCause());
        }
    }
}
