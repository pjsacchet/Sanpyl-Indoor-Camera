package org.greenrobot.essentials.collections;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/* loaded from: classes7.dex */
public abstract class AbstractMultimap<K, V, C extends Collection<V>> implements Map<K, C> {
    public Map<K, C> map;

    public AbstractMultimap(Map<K, C> map) {
        this.map = map;
    }

    @Override // java.util.Map
    public synchronized void clear() {
        this.map.clear();
    }

    public synchronized boolean containsElement(K k, V v) {
        C c2 = this.map.get(k);
        if (c2 == null) {
            return false;
        }
        return c2.contains(v);
    }

    @Override // java.util.Map
    public synchronized boolean containsKey(Object obj) {
        return this.map.containsKey(obj);
    }

    @Override // java.util.Map
    public synchronized boolean containsValue(Object obj) {
        return this.map.containsValue(obj);
    }

    public synchronized int countElements(K k) {
        C c2 = this.map.get(k);
        if (c2 == null) {
            return 0;
        }
        return c2.size();
    }

    public abstract C createNewCollection();

    @Override // java.util.Map
    public synchronized Set<Map.Entry<K, C>> entrySet() {
        return this.map.entrySet();
    }

    @Override // java.util.Map
    public synchronized boolean equals(Object obj) {
        return this.map.equals(obj);
    }

    @Override // java.util.Map
    public synchronized int hashCode() {
        return this.map.hashCode();
    }

    @Override // java.util.Map
    public synchronized boolean isEmpty() {
        return this.map.isEmpty();
    }

    @Override // java.util.Map
    public synchronized Set<K> keySet() {
        return this.map.keySet();
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // java.util.Map
    public /* bridge */ /* synthetic */ Object put(Object obj, Object obj2) {
        return put((AbstractMultimap<K, V, C>) obj, obj2);
    }

    @Override // java.util.Map
    public void putAll(Map<? extends K, ? extends C> map) {
        this.map.putAll(map);
    }

    public synchronized int putElement(K k, V v) {
        C c2;
        c2 = this.map.get(k);
        if (c2 == null) {
            c2 = createNewCollection();
            this.map.put(k, c2);
        }
        c2.add(v);
        return c2.size();
    }

    public synchronized boolean putElements(K k, Collection<V> collection) {
        C c2;
        c2 = this.map.get(k);
        if (c2 == null) {
            c2 = createNewCollection();
            this.map.put(k, c2);
        }
        return c2.addAll(collection);
    }

    public synchronized boolean removeElement(K k, V v) {
        C c2 = this.map.get(k);
        if (c2 == null) {
            return false;
        }
        boolean remove = c2.remove(v);
        if (c2.isEmpty()) {
            this.map.remove(k);
        }
        return remove;
    }

    @Override // java.util.Map
    public synchronized int size() {
        return this.map.size();
    }

    @Override // java.util.Map
    public synchronized Collection<C> values() {
        return this.map.values();
    }

    public synchronized C valuesElements() {
        C createNewCollection;
        createNewCollection = createNewCollection();
        Iterator<C> it = this.map.values().iterator();
        while (it.hasNext()) {
            createNewCollection.addAll(it.next());
        }
        return createNewCollection;
    }

    @Override // java.util.Map
    public synchronized C get(Object obj) {
        return this.map.get(obj);
    }

    public synchronized C put(K k, C c2) {
        return this.map.put(k, c2);
    }

    @Override // java.util.Map
    public synchronized C remove(Object obj) {
        return this.map.remove(obj);
    }

    public synchronized boolean containsElement(V v) {
        Iterator<C> it = this.map.values().iterator();
        while (it.hasNext()) {
            if (it.next().contains(v)) {
                return true;
            }
        }
        return false;
    }

    public synchronized int countElements() {
        int i;
        i = 0;
        Iterator<C> it = this.map.values().iterator();
        while (it.hasNext()) {
            i += it.next().size();
        }
        return i;
    }
}
