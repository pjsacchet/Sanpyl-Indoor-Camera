package org.greenrobot.essentials.collections;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/* loaded from: classes7.dex */
public class Multimap<K, V> extends AbstractMultimap<K, V, List<V>> {

    /* renamed from: 㫞, reason: contains not printable characters */
    public final ListType f22032;

    /* loaded from: classes7.dex */
    public enum ListType {
        REGULAR,
        THREAD_SAFE,
        LINKED
    }

    /* renamed from: org.greenrobot.essentials.collections.Multimap$㫞, reason: contains not printable characters */
    /* loaded from: classes7.dex */
    public static /* synthetic */ class C5291 {

        /* renamed from: 㫞, reason: contains not printable characters */
        public static final /* synthetic */ int[] f22033;

        static {
            int[] iArr = new int[ListType.values().length];
            f22033 = iArr;
            try {
                iArr[ListType.REGULAR.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f22033[ListType.THREAD_SAFE.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f22033[ListType.LINKED.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
        }
    }

    public Multimap(Map<K, List<V>> map, ListType listType) {
        super(map);
        this.f22032 = listType;
        if (listType != null) {
        } else {
            throw new IllegalArgumentException("List type may not be null");
        }
    }

    public static <K, V> Multimap<K, V> create() {
        return create(ListType.REGULAR);
    }

    public static <K, V> Multimap<K, V> create(ListType listType) {
        return new Multimap<>(new HashMap(), listType);
    }

    @Override // org.greenrobot.essentials.collections.AbstractMultimap
    public List<V> createNewCollection() {
        int i = C5291.f22033[this.f22032.ordinal()];
        if (i == 1) {
            return new ArrayList();
        }
        if (i == 2) {
            return new CopyOnWriteArrayList();
        }
        if (i == 3) {
            return new LinkedList();
        }
        throw new IllegalStateException("Unknown list type: " + this.f22032);
    }
}
