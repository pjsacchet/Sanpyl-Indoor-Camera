package org.greenrobot.essentials.collections;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

/* loaded from: classes7.dex */
public class MultimapSet<K, V> extends AbstractMultimap<K, V, Set<V>> {

    /* renamed from: 㫞, reason: contains not printable characters */
    public final SetType f22034;

    /* loaded from: classes7.dex */
    public enum SetType {
        REGULAR,
        THREAD_SAFE
    }

    /* renamed from: org.greenrobot.essentials.collections.MultimapSet$㫞, reason: contains not printable characters */
    /* loaded from: classes7.dex */
    public static /* synthetic */ class C5292 {

        /* renamed from: 㫞, reason: contains not printable characters */
        public static final /* synthetic */ int[] f22035;

        static {
            int[] iArr = new int[SetType.values().length];
            f22035 = iArr;
            try {
                iArr[SetType.REGULAR.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f22035[SetType.THREAD_SAFE.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
        }
    }

    public MultimapSet(Map<K, Set<V>> map, SetType setType) {
        super(map);
        this.f22034 = setType;
    }

    public static <K, V> MultimapSet<K, V> create() {
        return create(SetType.REGULAR);
    }

    public static <K, V> MultimapSet<K, V> create(SetType setType) {
        return new MultimapSet<>(new HashMap(), setType);
    }

    @Override // org.greenrobot.essentials.collections.AbstractMultimap
    public Set<V> createNewCollection() {
        int i = C5292.f22035[this.f22034.ordinal()];
        if (i == 1) {
            return new HashSet();
        }
        if (i == 2) {
            return new CopyOnWriteArraySet();
        }
        throw new IllegalStateException("Unknown set type: " + this.f22034);
    }
}
