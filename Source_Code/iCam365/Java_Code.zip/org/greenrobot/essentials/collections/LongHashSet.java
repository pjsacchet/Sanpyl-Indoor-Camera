package org.greenrobot.essentials.collections;

import java.util.Arrays;

/* loaded from: classes7.dex */
public class LongHashSet {
    public static final int DEFAULT_CAPACITY = 16;

    /* renamed from: ᇰ, reason: contains not printable characters */
    public int f22025;

    /* renamed from: ᦜ, reason: contains not printable characters */
    public volatile float f22026;

    /* renamed from: 㫞, reason: contains not printable characters */
    public C5290[] f22027;

    /* renamed from: 㫿, reason: contains not printable characters */
    public int f22028;

    /* renamed from: 㯿, reason: contains not printable characters */
    public volatile int f22029;

    /* loaded from: classes7.dex */
    public static class Synchronized extends LongHashSet {
        public Synchronized(int i) {
            super(i);
        }

        @Override // org.greenrobot.essentials.collections.LongHashSet
        public synchronized boolean add(long j) {
            return super.add(j);
        }

        @Override // org.greenrobot.essentials.collections.LongHashSet
        public synchronized void clear() {
            super.clear();
        }

        @Override // org.greenrobot.essentials.collections.LongHashSet
        public synchronized boolean contains(long j) {
            return super.contains(j);
        }

        @Override // org.greenrobot.essentials.collections.LongHashSet
        public synchronized long[] keys() {
            return super.keys();
        }

        @Override // org.greenrobot.essentials.collections.LongHashSet
        public synchronized boolean remove(long j) {
            return super.remove(j);
        }

        @Override // org.greenrobot.essentials.collections.LongHashSet
        public synchronized void reserveRoom(int i) {
            super.reserveRoom(i);
        }

        @Override // org.greenrobot.essentials.collections.LongHashSet
        public synchronized void setCapacity(int i) {
            super.setCapacity(i);
        }
    }

    /* renamed from: org.greenrobot.essentials.collections.LongHashSet$㫞, reason: contains not printable characters */
    /* loaded from: classes7.dex */
    public static final class C5290 {

        /* renamed from: ᇰ, reason: contains not printable characters */
        public C5290 f22030;

        /* renamed from: 㫞, reason: contains not printable characters */
        public final long f22031;

        public C5290(long j, C5290 c5290) {
            this.f22031 = j;
            this.f22030 = c5290;
        }
    }

    public LongHashSet() {
        this(16);
    }

    public static LongHashSet createSynchronized() {
        return new Synchronized(16);
    }

    public boolean add(long j) {
        int i = ((((int) (j >>> 32)) ^ ((int) j)) & Integer.MAX_VALUE) % this.f22025;
        C5290 c5290 = this.f22027[i];
        for (C5290 c52902 = c5290; c52902 != null; c52902 = c52902.f22030) {
            if (c52902.f22031 == j) {
                return false;
            }
        }
        this.f22027[i] = new C5290(j, c5290);
        this.f22029++;
        if (this.f22029 > this.f22028) {
            setCapacity(this.f22025 * 2);
        }
        return true;
    }

    public void clear() {
        this.f22029 = 0;
        Arrays.fill(this.f22027, (Object) null);
    }

    public boolean contains(long j) {
        for (C5290 c5290 = this.f22027[((((int) (j >>> 32)) ^ ((int) j)) & Integer.MAX_VALUE) % this.f22025]; c5290 != null; c5290 = c5290.f22030) {
            if (c5290.f22031 == j) {
                return true;
            }
        }
        return false;
    }

    public long[] keys() {
        long[] jArr = new long[this.f22029];
        int i = 0;
        for (C5290 c5290 : this.f22027) {
            while (c5290 != null) {
                jArr[i] = c5290.f22031;
                c5290 = c5290.f22030;
                i++;
            }
        }
        return jArr;
    }

    public boolean remove(long j) {
        int i = ((((int) (j >>> 32)) ^ ((int) j)) & Integer.MAX_VALUE) % this.f22025;
        C5290 c5290 = this.f22027[i];
        C5290 c52902 = null;
        while (c5290 != null) {
            C5290 c52903 = c5290.f22030;
            if (c5290.f22031 == j) {
                if (c52902 == null) {
                    this.f22027[i] = c52903;
                } else {
                    c52902.f22030 = c52903;
                }
                this.f22029--;
                return true;
            }
            c52902 = c5290;
            c5290 = c52903;
        }
        return false;
    }

    public void reserveRoom(int i) {
        setCapacity((int) ((i * this.f22026 * 1.3f) + 0.5f));
    }

    public void setCapacity(int i) {
        C5290[] c5290Arr = new C5290[i];
        for (C5290 c5290 : this.f22027) {
            while (c5290 != null) {
                long j = c5290.f22031;
                int i2 = ((((int) j) ^ ((int) (j >>> 32))) & Integer.MAX_VALUE) % i;
                C5290 c52902 = c5290.f22030;
                c5290.f22030 = c5290Arr[i2];
                c5290Arr[i2] = c5290;
                c5290 = c52902;
            }
        }
        this.f22027 = c5290Arr;
        this.f22025 = i;
        this.f22028 = (int) ((i * this.f22026) + 0.5f);
    }

    public void setLoadFactor(float f) {
        this.f22026 = f;
    }

    public int size() {
        return this.f22029;
    }

    public LongHashSet(int i) {
        this.f22026 = 1.3f;
        this.f22025 = i;
        this.f22028 = (int) ((i * this.f22026) + 0.5f);
        this.f22027 = new C5290[i];
    }

    public static LongHashSet createSynchronized(int i) {
        return new Synchronized(i);
    }
}
