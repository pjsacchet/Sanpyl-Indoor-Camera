package org.greenrobot.essentials.collections;

import java.util.Arrays;

/* loaded from: classes7.dex */
public class LongHashMap<T> {
    public static final int DEFAULT_CAPACITY = 16;

    /* renamed from: ᇰ, reason: contains not printable characters */
    public int f22021;

    /* renamed from: 㫞, reason: contains not printable characters */
    public Entry<T>[] f22022;

    /* renamed from: 㫿, reason: contains not printable characters */
    public int f22023;

    /* renamed from: 㯿, reason: contains not printable characters */
    public volatile int f22024;

    /* loaded from: classes7.dex */
    public static final class Entry<T> {
        public final long key;
        public Entry<T> next;
        public T value;

        public Entry(long j, T t, Entry<T> entry) {
            this.key = j;
            this.value = t;
            this.next = entry;
        }
    }

    /* loaded from: classes7.dex */
    public static class Synchronized<T> extends LongHashMap<T> {
        public Synchronized(int i) {
            super(i);
        }

        @Override // org.greenrobot.essentials.collections.LongHashMap
        public synchronized void clear() {
            super.clear();
        }

        @Override // org.greenrobot.essentials.collections.LongHashMap
        public synchronized boolean containsKey(long j) {
            return super.containsKey(j);
        }

        @Override // org.greenrobot.essentials.collections.LongHashMap
        public synchronized Entry<T>[] entries() {
            return super.entries();
        }

        @Override // org.greenrobot.essentials.collections.LongHashMap
        public synchronized T get(long j) {
            return (T) super.get(j);
        }

        @Override // org.greenrobot.essentials.collections.LongHashMap
        public synchronized long[] keys() {
            return super.keys();
        }

        @Override // org.greenrobot.essentials.collections.LongHashMap
        public synchronized T put(long j, T t) {
            return (T) super.put(j, t);
        }

        @Override // org.greenrobot.essentials.collections.LongHashMap
        public synchronized T remove(long j) {
            return (T) super.remove(j);
        }

        @Override // org.greenrobot.essentials.collections.LongHashMap
        public synchronized void reserveRoom(int i) {
            super.reserveRoom(i);
        }

        @Override // org.greenrobot.essentials.collections.LongHashMap
        public synchronized void setCapacity(int i) {
            super.setCapacity(i);
        }
    }

    public LongHashMap() {
        this(16);
    }

    public static <T> LongHashMap<T> createSynchronized() {
        return new Synchronized(16);
    }

    public void clear() {
        this.f22024 = 0;
        Arrays.fill(this.f22022, (Object) null);
    }

    public boolean containsKey(long j) {
        for (Entry<T> entry = this.f22022[((((int) (j >>> 32)) ^ ((int) j)) & Integer.MAX_VALUE) % this.f22021]; entry != null; entry = entry.next) {
            if (entry.key == j) {
                return true;
            }
        }
        return false;
    }

    public Entry<T>[] entries() {
        Entry<T>[] entryArr = new Entry[this.f22024];
        int i = 0;
        for (Entry<T> entry : this.f22022) {
            while (entry != null) {
                entryArr[i] = entry;
                entry = entry.next;
                i++;
            }
        }
        return entryArr;
    }

    public T get(long j) {
        for (Entry<T> entry = this.f22022[((((int) (j >>> 32)) ^ ((int) j)) & Integer.MAX_VALUE) % this.f22021]; entry != null; entry = entry.next) {
            if (entry.key == j) {
                return entry.value;
            }
        }
        return null;
    }

    public long[] keys() {
        long[] jArr = new long[this.f22024];
        int i = 0;
        for (Entry<T> entry : this.f22022) {
            while (entry != null) {
                jArr[i] = entry.key;
                entry = entry.next;
                i++;
            }
        }
        return jArr;
    }

    public T put(long j, T t) {
        int i = ((((int) (j >>> 32)) ^ ((int) j)) & Integer.MAX_VALUE) % this.f22021;
        Entry<T> entry = this.f22022[i];
        for (Entry<T> entry2 = entry; entry2 != null; entry2 = entry2.next) {
            if (entry2.key == j) {
                T t2 = entry2.value;
                entry2.value = t;
                return t2;
            }
        }
        this.f22022[i] = new Entry<>(j, t, entry);
        this.f22024++;
        if (this.f22024 > this.f22023) {
            setCapacity(this.f22021 * 2);
            return null;
        }
        return null;
    }

    public T remove(long j) {
        int i = ((((int) (j >>> 32)) ^ ((int) j)) & Integer.MAX_VALUE) % this.f22021;
        Entry<T> entry = this.f22022[i];
        Entry<T> entry2 = null;
        while (entry != null) {
            Entry<T> entry3 = entry.next;
            if (entry.key == j) {
                if (entry2 == null) {
                    this.f22022[i] = entry3;
                } else {
                    entry2.next = entry3;
                }
                this.f22024--;
                return entry.value;
            }
            entry2 = entry;
            entry = entry3;
        }
        return null;
    }

    public void reserveRoom(int i) {
        setCapacity((i * 5) / 3);
    }

    public void setCapacity(int i) {
        Entry<T>[] entryArr = new Entry[i];
        for (Entry<T> entry : this.f22022) {
            while (entry != null) {
                long j = entry.key;
                int i2 = ((((int) j) ^ ((int) (j >>> 32))) & Integer.MAX_VALUE) % i;
                Entry<T> entry2 = entry.next;
                entry.next = entryArr[i2];
                entryArr[i2] = entry;
                entry = entry2;
            }
        }
        this.f22022 = entryArr;
        this.f22021 = i;
        this.f22023 = (i * 4) / 3;
    }

    public int size() {
        return this.f22024;
    }

    public LongHashMap(int i) {
        this.f22021 = i;
        this.f22023 = (i * 4) / 3;
        this.f22022 = new Entry[i];
    }

    public static <T> LongHashMap<T> createSynchronized(int i) {
        return new Synchronized(i);
    }
}
