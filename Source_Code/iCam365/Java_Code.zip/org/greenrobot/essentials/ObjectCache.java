package org.greenrobot.essentials;

import java.lang.ref.Reference;
import java.lang.ref.SoftReference;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/* loaded from: classes7.dex */
public class ObjectCache<KEY, VALUE> {

    /* renamed from: થ, reason: contains not printable characters */
    public volatile int f21996;

    /* renamed from: ᇰ, reason: contains not printable characters */
    public final ReferenceType f21997;

    /* renamed from: ᕾ, reason: contains not printable characters */
    public volatile int f21998;

    /* renamed from: ᝠ, reason: contains not printable characters */
    public volatile int f21999;

    /* renamed from: ᦜ, reason: contains not printable characters */
    public final long f22000;

    /* renamed from: ᵻ, reason: contains not printable characters */
    public volatile int f22001;

    /* renamed from: ⴄ, reason: contains not printable characters */
    public volatile long f22002;

    /* renamed from: 㛧, reason: contains not printable characters */
    public volatile int f22003;

    /* renamed from: 㡷, reason: contains not printable characters */
    public final boolean f22004;

    /* renamed from: 㫞, reason: contains not printable characters */
    public final Map<KEY, C5286<VALUE>> f22005;

    /* renamed from: 㫿, reason: contains not printable characters */
    public final boolean f22006;

    /* renamed from: 㯿, reason: contains not printable characters */
    public final int f22007;

    /* renamed from: 㳏, reason: contains not printable characters */
    public volatile int f22008;

    /* renamed from: 㼬, reason: contains not printable characters */
    public volatile int f22009;

    /* loaded from: classes7.dex */
    public enum ReferenceType {
        SOFT,
        WEAK,
        STRONG
    }

    /* renamed from: org.greenrobot.essentials.ObjectCache$㫞, reason: contains not printable characters */
    /* loaded from: classes7.dex */
    public static class C5286<V> {

        /* renamed from: ᇰ, reason: contains not printable characters */
        public final V f22010;

        /* renamed from: 㫞, reason: contains not printable characters */
        public final Reference<V> f22011;

        /* renamed from: 㫿, reason: contains not printable characters */
        public final long f22012 = System.currentTimeMillis();

        public C5286(Reference<V> reference, V v) {
            this.f22011 = reference;
            this.f22010 = v;
        }
    }

    public ObjectCache(ReferenceType referenceType, int i, long j) {
        boolean z;
        this.f21997 = referenceType;
        if (referenceType == ReferenceType.STRONG) {
            z = true;
        } else {
            z = false;
        }
        this.f22006 = z;
        this.f22007 = i;
        this.f22000 = j;
        this.f22004 = j > 0;
        this.f22005 = new LinkedHashMap();
    }

    public void checkCleanUpObsoleteEntries() {
        if (!this.f22006 || this.f22004) {
            if ((this.f22004 && this.f22002 != 0 && System.currentTimeMillis() > this.f22002) || this.f22003 > this.f22007 / 2) {
                cleanUpObsoleteEntries();
            }
        }
    }

    public synchronized int cleanUpObsoleteEntries() {
        int i;
        i = 0;
        this.f22003 = 0;
        long j = 0;
        this.f22002 = 0L;
        if (this.f22004) {
            j = System.currentTimeMillis() - this.f22000;
        }
        Iterator<C5286<VALUE>> it = this.f22005.values().iterator();
        while (it.hasNext()) {
            C5286<VALUE> next = it.next();
            if (!this.f22006 && next.f22011 == null) {
                this.f22008++;
                i++;
                it.remove();
            } else if (next.f22012 < j) {
                this.f22009++;
                i++;
                it.remove();
            }
        }
        return i;
    }

    public synchronized void clear() {
        this.f22005.clear();
    }

    public synchronized boolean containsKey(KEY key) {
        return this.f22005.containsKey(key);
    }

    public boolean containsKeyWithValue(KEY key) {
        return get(key) != null;
    }

    public synchronized void evictToTargetSize(int i) {
        if (i <= 0) {
            this.f22005.clear();
        } else {
            checkCleanUpObsoleteEntries();
            Iterator<KEY> it = this.f22005.keySet().iterator();
            while (it.hasNext() && this.f22005.size() > i) {
                this.f21998++;
                it.next();
                it.remove();
            }
        }
    }

    public VALUE get(KEY key) {
        C5286<VALUE> c5286;
        synchronized (this) {
            c5286 = this.f22005.get(key);
        }
        VALUE value = null;
        if (c5286 != null) {
            if (this.f22004) {
                if (System.currentTimeMillis() - c5286.f22012 < this.f22000) {
                    value = m17588(key, c5286);
                } else {
                    this.f22009++;
                    synchronized (this) {
                        this.f22005.remove(key);
                    }
                }
            } else {
                value = m17588(key, c5286);
            }
        }
        if (value != null) {
            this.f21996++;
        } else {
            this.f22001++;
        }
        return value;
    }

    public int getCountEvicted() {
        return this.f21998;
    }

    public int getCountExpired() {
        return this.f22009;
    }

    public int getCountHit() {
        return this.f21996;
    }

    public int getCountMiss() {
        return this.f22001;
    }

    public int getCountPut() {
        return this.f21999;
    }

    public int getCountRefCleared() {
        return this.f22008;
    }

    public int getMaxSize() {
        return this.f22007;
    }

    public String getStatsStringRemoved() {
        return "ObjectCache-Removed[expired=" + this.f22009 + ", refCleared=" + this.f22008 + ", evicted=" + this.f21998;
    }

    public synchronized Set<KEY> keySet() {
        return this.f22005.keySet();
    }

    public VALUE put(KEY key, VALUE value) {
        C5286<VALUE> c5286;
        C5286<VALUE> put;
        ReferenceType referenceType = this.f21997;
        if (referenceType == ReferenceType.WEAK) {
            c5286 = new C5286<>(new WeakReference(value), null);
        } else if (referenceType == ReferenceType.SOFT) {
            c5286 = new C5286<>(new SoftReference(value), null);
        } else {
            c5286 = new C5286<>(null, value);
        }
        this.f22003++;
        this.f21999++;
        if (this.f22004 && this.f22002 == 0) {
            this.f22002 = System.currentTimeMillis() + this.f22000 + 1;
        }
        synchronized (this) {
            int size = this.f22005.size();
            int i = this.f22007;
            if (size >= i) {
                evictToTargetSize(i - 1);
            }
            put = this.f22005.put(key, c5286);
        }
        return m17587(put);
    }

    public void putAll(Map<KEY, VALUE> map) {
        int size = this.f22007 - map.size();
        if (this.f22007 > 0 && this.f22005.size() > size) {
            evictToTargetSize(size);
        }
        for (Map.Entry<KEY, VALUE> entry : map.entrySet()) {
            put(entry.getKey(), entry.getValue());
        }
    }

    public VALUE remove(KEY key) {
        return m17587(this.f22005.remove(key));
    }

    public synchronized int size() {
        return this.f22005.size();
    }

    public String toString() {
        return "ObjectCache[maxSize=" + this.f22007 + ", hits=" + this.f21996 + ", misses=" + this.f22001 + "]";
    }

    /* renamed from: ᇰ, reason: contains not printable characters */
    public final VALUE m17587(C5286<VALUE> c5286) {
        if (c5286 != null) {
            return this.f22006 ? c5286.f22010 : c5286.f22011.get();
        }
        return null;
    }

    /* renamed from: 㫞, reason: contains not printable characters */
    public final VALUE m17588(KEY key, C5286<VALUE> c5286) {
        if (c5286 != null) {
            if (this.f22006) {
                return c5286.f22010;
            }
            VALUE value = c5286.f22011.get();
            if (value == null) {
                this.f22008++;
                if (key != null) {
                    synchronized (this) {
                        this.f22005.remove(key);
                    }
                }
            }
            return value;
        }
        return null;
    }
}
