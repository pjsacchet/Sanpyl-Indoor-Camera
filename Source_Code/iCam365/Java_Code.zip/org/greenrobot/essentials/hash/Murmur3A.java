package org.greenrobot.essentials.hash;

import java.util.zip.Checksum;
import kotlin.UShort;
import okhttp3.internal.ws.WebSocketProtocol;
import org.greenrobot.essentials.PrimitiveArrayUtils;

/* loaded from: classes7.dex */
public class Murmur3A implements Checksum {

    /* renamed from: ⴄ, reason: contains not printable characters */
    public static final int f22042 = -862048943;

    /* renamed from: 㛧, reason: contains not printable characters */
    public static final int f22043 = 461845907;

    /* renamed from: 㡷, reason: contains not printable characters */
    public static PrimitiveArrayUtils f22044 = PrimitiveArrayUtils.getInstance();

    /* renamed from: ᇰ, reason: contains not printable characters */
    public int f22045;

    /* renamed from: ᦜ, reason: contains not printable characters */
    public int f22046;

    /* renamed from: 㫞, reason: contains not printable characters */
    public final int f22047;

    /* renamed from: 㫿, reason: contains not printable characters */
    public int f22048;

    /* renamed from: 㯿, reason: contains not printable characters */
    public int f22049;

    public Murmur3A() {
        this.f22047 = 0;
    }

    @Override // java.util.zip.Checksum
    public long getValue() {
        int i = this.f22045;
        if (this.f22046 > 0) {
            int i2 = this.f22049 * f22042;
            i ^= ((i2 >>> 17) | (i2 << 15)) * f22043;
        }
        int i3 = i ^ this.f22048;
        int i4 = (i3 ^ (i3 >>> 16)) * (-2048144789);
        int i5 = (i4 ^ (i4 >>> 13)) * (-1028477387);
        return (i5 ^ (i5 >>> 16)) & 4294967295L;
    }

    @Override // java.util.zip.Checksum
    public void reset() {
        this.f22045 = this.f22047;
        this.f22048 = 0;
        this.f22046 = 0;
    }

    @Override // java.util.zip.Checksum
    public void update(int i) {
        int i2 = this.f22046;
        if (i2 == 0) {
            this.f22049 = i & 255;
            this.f22046 = 1;
        } else if (i2 == 1) {
            this.f22049 = ((i & 255) << 8) | this.f22049;
            this.f22046 = 2;
        } else if (i2 == 2) {
            this.f22049 = ((i & 255) << 16) | this.f22049;
            this.f22046 = 3;
        } else if (i2 == 3) {
            int i3 = ((i & 255) << 24) | this.f22049;
            this.f22049 = i3;
            m17593(i3);
            this.f22046 = 0;
        }
        this.f22048++;
    }

    public void updateBoolean(boolean z) {
        update(z ? 1 : 0);
    }

    public void updateDouble(double d) {
        updateLong(Double.doubleToLongBits(d));
    }

    public void updateFloat(float f) {
        updateInt(Float.floatToIntBits(f));
    }

    public void updateInt(int i) {
        int i2 = this.f22046;
        if (i2 == 0) {
            m17593(i);
        } else if (i2 == 1) {
            int i3 = this.f22049 | ((16777215 & i) << 8);
            this.f22049 = i3;
            m17593(i3);
            this.f22049 = i >>> 24;
        } else if (i2 == 2) {
            int i4 = this.f22049 | ((65535 & i) << 16);
            this.f22049 = i4;
            m17593(i4);
            this.f22049 = i >>> 16;
        } else if (i2 == 3) {
            int i5 = this.f22049 | ((i & 255) << 24);
            this.f22049 = i5;
            m17593(i5);
            this.f22049 = i >>> 8;
        }
        this.f22048 += 4;
    }

    public void updateLong(long j) {
        int i = this.f22046;
        if (i == 0) {
            m17593((int) ((-1) & j));
            m17593((int) (j >>> 32));
        } else if (i == 1) {
            int i2 = (int) (this.f22049 | ((16777215 & j) << 8));
            this.f22049 = i2;
            m17593(i2);
            m17593((int) ((-1) & (j >>> 24)));
            this.f22049 = (int) (j >>> 56);
        } else if (i == 2) {
            int i3 = (int) (this.f22049 | ((WebSocketProtocol.PAYLOAD_SHORT_MAX & j) << 16));
            this.f22049 = i3;
            m17593(i3);
            m17593((int) ((-1) & (j >>> 16)));
            this.f22049 = (int) (j >>> 48);
        } else if (i == 3) {
            int i4 = (int) (((255 & j) << 24) | this.f22049);
            this.f22049 = i4;
            m17593(i4);
            m17593((int) ((-1) & (j >>> 8)));
            this.f22049 = (int) (j >>> 40);
        }
        this.f22048 += 8;
    }

    public void updateShort(short s) {
        int i = this.f22046;
        if (i == 0) {
            this.f22049 = s & UShort.MAX_VALUE;
            this.f22046 = 2;
        } else if (i == 1) {
            this.f22049 = ((s & UShort.MAX_VALUE) << 8) | this.f22049;
            this.f22046 = 3;
        } else if (i == 2) {
            int i2 = ((s & UShort.MAX_VALUE) << 16) | this.f22049;
            this.f22049 = i2;
            m17593(i2);
            this.f22046 = 0;
        } else if (i == 3) {
            int i3 = this.f22049 | ((s & 255) << 24);
            this.f22049 = i3;
            m17593(i3);
            this.f22049 = (s >> 8) & 255;
            this.f22046 = 1;
        }
        this.f22048 += 2;
    }

    /* renamed from: 㫞, reason: contains not printable characters */
    public final void m17593(int i) {
        int i2 = i * f22042;
        int i3 = (((i2 >>> 17) | (i2 << 15)) * f22043) ^ this.f22045;
        this.f22045 = (((i3 >>> 19) | (i3 << 13)) * 5) - 430675100;
    }

    public Murmur3A(int i) {
        this.f22047 = i;
        this.f22045 = i;
    }

    @Override // java.util.zip.Checksum
    public void update(byte[] bArr, int i, int i2) {
        while (this.f22046 != 0 && i2 > 0) {
            update(bArr[i]);
            i++;
            i2--;
        }
        int i3 = i2 & 3;
        int i4 = (i2 + i) - i3;
        for (int i5 = i; i5 < i4; i5 += 4) {
            m17593(f22044.getIntLE(bArr, i5));
        }
        this.f22048 += i4 - i;
        for (int i6 = 0; i6 < i3; i6++) {
            update(bArr[i4 + i6]);
        }
    }

    public void updateInt(int... iArr) {
        int i = 0;
        if (this.f22046 == 0) {
            int length = iArr.length;
            while (i < length) {
                m17593(iArr[i]);
                i++;
            }
            this.f22048 += iArr.length * 4;
            return;
        }
        int length2 = iArr.length;
        while (i < length2) {
            updateInt(iArr[i]);
            i++;
        }
    }

    public void updateShort(short... sArr) {
        int i;
        int length = sArr.length;
        int i2 = 0;
        if (length > 0 && ((i = this.f22046) == 0 || i == 2)) {
            if (i == 2) {
                int i3 = this.f22049 | ((sArr[0] & UShort.MAX_VALUE) << 16);
                this.f22049 = i3;
                m17593(i3);
                this.f22046 = 0;
                length--;
                i2 = 1;
            }
            int i4 = (length & (-2)) + i2;
            while (i2 < i4) {
                m17593((sArr[i2] & UShort.MAX_VALUE) | ((sArr[i2 + 1] & UShort.MAX_VALUE) << 16));
                i2 += 2;
            }
            if (i4 < sArr.length) {
                this.f22049 = sArr[i4] & UShort.MAX_VALUE;
                this.f22046 = 2;
            }
            this.f22048 += sArr.length * 2;
            return;
        }
        int length2 = sArr.length;
        while (i2 < length2) {
            updateShort(sArr[i2]);
            i2++;
        }
    }

    public void updateLong(long... jArr) {
        int i = 0;
        if (this.f22046 == 0) {
            int length = jArr.length;
            while (i < length) {
                long j = jArr[i];
                m17593((int) ((-1) & j));
                m17593((int) (j >>> 32));
                i++;
            }
            this.f22048 += jArr.length * 8;
            return;
        }
        int length2 = jArr.length;
        while (i < length2) {
            updateLong(jArr[i]);
            i++;
        }
    }

    @Override // java.util.zip.Checksum
    public void update(byte[] bArr) {
        update(bArr, 0, bArr.length);
    }
}
