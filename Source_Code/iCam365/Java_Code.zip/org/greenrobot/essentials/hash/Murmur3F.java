package org.greenrobot.essentials.hash;

import java.math.BigInteger;
import org.greenrobot.essentials.PrimitiveArrayUtils;

/* loaded from: classes7.dex */
public class Murmur3F implements Checksum128 {

    /* renamed from: ᵻ, reason: contains not printable characters */
    public static PrimitiveArrayUtils f22050 = PrimitiveArrayUtils.getInstance();

    /* renamed from: 㳏, reason: contains not printable characters */
    public static final long f22051 = 5545529020109919103L;

    /* renamed from: 㼬, reason: contains not printable characters */
    public static final long f22052 = -8663945395140668459L;

    /* renamed from: થ, reason: contains not printable characters */
    public long f22053;

    /* renamed from: ᇰ, reason: contains not printable characters */
    public long f22054;

    /* renamed from: ᝠ, reason: contains not printable characters */
    public long f22055;

    /* renamed from: ᦜ, reason: contains not printable characters */
    public int f22056;

    /* renamed from: ⴄ, reason: contains not printable characters */
    public long f22057;

    /* renamed from: 㛧, reason: contains not printable characters */
    public boolean f22058;

    /* renamed from: 㡷, reason: contains not printable characters */
    public long f22059;

    /* renamed from: 㫞, reason: contains not printable characters */
    public final long f22060;

    /* renamed from: 㫿, reason: contains not printable characters */
    public long f22061;

    /* renamed from: 㯿, reason: contains not printable characters */
    public int f22062;

    public Murmur3F() {
        this.f22060 = 0L;
    }

    @Override // java.util.zip.Checksum
    public long getValue() {
        m17594();
        return this.f22055;
    }

    @Override // org.greenrobot.essentials.hash.Checksum128
    public BigInteger getValueBigInteger() {
        return new BigInteger(1, getValueBytesBigEndian());
    }

    @Override // org.greenrobot.essentials.hash.Checksum128
    public byte[] getValueBytesBigEndian() {
        m17594();
        byte[] bArr = new byte[16];
        for (int i = 0; i < 8; i++) {
            bArr[i] = (byte) (255 & (this.f22053 >>> (56 - (i * 8))));
        }
        for (int i2 = 0; i2 < 8; i2++) {
            bArr[i2 + 8] = (byte) ((this.f22055 >>> (56 - (i2 * 8))) & 255);
        }
        return bArr;
    }

    @Override // org.greenrobot.essentials.hash.Checksum128
    public byte[] getValueBytesLittleEndian() {
        m17594();
        byte[] bArr = new byte[16];
        for (int i = 0; i < 8; i++) {
            bArr[i] = (byte) (255 & (this.f22055 >>> (i * 8)));
        }
        for (int i2 = 0; i2 < 8; i2++) {
            bArr[i2 + 8] = (byte) ((this.f22053 >>> (i2 * 8)) & 255);
        }
        return bArr;
    }

    @Override // org.greenrobot.essentials.hash.Checksum128
    public String getValueHexString() {
        m17594();
        return m17597(this.f22053) + m17597(this.f22055);
    }

    @Override // org.greenrobot.essentials.hash.Checksum128
    public long getValueHigh() {
        m17594();
        return this.f22053;
    }

    @Override // java.util.zip.Checksum
    public void reset() {
        long j = this.f22060;
        this.f22061 = j;
        this.f22054 = j;
        this.f22062 = 0;
        this.f22056 = 0;
        this.f22058 = false;
        this.f22057 = 0L;
        this.f22059 = 0L;
        this.f22053 = 0L;
        this.f22055 = 0L;
    }

    @Override // java.util.zip.Checksum
    public void update(int i) {
        this.f22058 = false;
        int i2 = this.f22056;
        switch (i2) {
            case 0:
                this.f22059 = i & 255;
                break;
            case 1:
                this.f22059 |= (i & 255) << 8;
                break;
            case 2:
                this.f22059 |= (i & 255) << 16;
                break;
            case 3:
                this.f22059 |= (i & 255) << 24;
                break;
            case 4:
                this.f22059 |= (255 & i) << 32;
                break;
            case 5:
                this.f22059 |= (i & 255) << 40;
                break;
            case 6:
                this.f22059 = ((255 & i) << 48) | this.f22059;
                break;
            case 7:
                this.f22059 |= (i & 255) << 56;
                break;
            case 8:
                this.f22057 = i & 255;
                break;
            case 9:
                this.f22057 |= (i & 255) << 8;
                break;
            case 10:
                this.f22057 |= (i & 255) << 16;
                break;
            case 11:
                this.f22057 |= (i & 255) << 24;
                break;
            case 12:
                this.f22057 |= (255 & i) << 32;
                break;
            case 13:
                this.f22057 |= (i & 255) << 40;
                break;
            case 14:
                this.f22057 = ((255 & i) << 48) | this.f22057;
                break;
            case 15:
                this.f22057 |= (i & 255) << 56;
                break;
        }
        int i3 = i2 + 1;
        this.f22056 = i3;
        if (i3 == 16) {
            m17595(this.f22059, this.f22057);
            this.f22056 = 0;
        }
        this.f22062++;
    }

    public void updateLongBE(long j) {
        updateLongLE(Long.reverseBytes(j));
    }

    public void updateLongLE(long j) {
        this.f22058 = false;
        int i = this.f22056;
        if (i != 0) {
            if (i == 8) {
                this.f22057 = j;
            } else {
                throw new IllegalStateException("Cannot mix long with other alignments than 8: " + this.f22056);
            }
        } else {
            this.f22059 = j;
        }
        int i2 = i + 8;
        this.f22056 = i2;
        if (i2 == 16) {
            m17595(this.f22059, this.f22057);
            this.f22056 = 0;
        }
        this.f22062 += 8;
    }

    /* renamed from: ᇰ, reason: contains not printable characters */
    public final void m17594() {
        if (!this.f22058) {
            this.f22058 = true;
            this.f22055 = this.f22054;
            this.f22053 = this.f22061;
            int i = this.f22056;
            if (i > 0) {
                if (i > 8) {
                    this.f22053 = (Long.rotateLeft(this.f22057 * f22051, 33) * f22052) ^ this.f22053;
                }
                this.f22055 = (Long.rotateLeft(this.f22059 * f22052, 31) * f22051) ^ this.f22055;
            }
            long j = this.f22055;
            int i2 = this.f22062;
            long j2 = j ^ i2;
            long j3 = this.f22053 ^ i2;
            long j4 = j2 + j3;
            this.f22055 = j4;
            this.f22053 = j3 + j4;
            this.f22055 = m17596(j4);
            long m17596 = m17596(this.f22053);
            long j5 = this.f22055 + m17596;
            this.f22055 = j5;
            this.f22053 = m17596 + j5;
        }
    }

    /* renamed from: 㫞, reason: contains not printable characters */
    public final void m17595(long j, long j2) {
        long rotateLeft = (Long.rotateLeft(j * f22052, 31) * f22051) ^ this.f22054;
        this.f22054 = rotateLeft;
        this.f22054 = ((Long.rotateLeft(rotateLeft, 27) + this.f22061) * 5) + 1390208809;
        long rotateLeft2 = (Long.rotateLeft(j2 * f22051, 33) * f22052) ^ this.f22061;
        this.f22061 = rotateLeft2;
        this.f22061 = ((Long.rotateLeft(rotateLeft2, 31) + this.f22054) * 5) + 944331445;
    }

    /* renamed from: 㫿, reason: contains not printable characters */
    public final long m17596(long j) {
        long j2 = (j ^ (j >>> 33)) * (-49064778989728563L);
        long j3 = (j2 ^ (j2 >>> 33)) * (-4265267296055464877L);
        return j3 ^ (j3 >>> 33);
    }

    /* renamed from: 㯿, reason: contains not printable characters */
    public final String m17597(long j) {
        String hexString = Long.toHexString(j);
        while (hexString.length() < 16) {
            hexString = '0' + hexString;
        }
        return hexString;
    }

    public Murmur3F(int i) {
        long j = i & 4294967295L;
        this.f22060 = j;
        this.f22061 = j;
        this.f22054 = j;
    }

    @Override // java.util.zip.Checksum
    public void update(byte[] bArr) {
        update(bArr, 0, bArr.length);
    }

    @Override // java.util.zip.Checksum
    public void update(byte[] bArr, int i, int i2) {
        this.f22058 = false;
        while (this.f22056 != 0 && i2 > 0) {
            update(bArr[i]);
            i++;
            i2--;
        }
        int i3 = i2 & 15;
        int i4 = (i2 + i) - i3;
        for (int i5 = i; i5 < i4; i5 += 16) {
            m17595(f22050.getLongLE(bArr, i5), f22050.getLongLE(bArr, i5 + 8));
        }
        this.f22062 += i4 - i;
        for (int i6 = 0; i6 < i3; i6++) {
            update(bArr[i4 + i6]);
        }
    }
}
