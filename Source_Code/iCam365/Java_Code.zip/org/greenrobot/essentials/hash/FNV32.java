package org.greenrobot.essentials.hash;

import java.util.zip.Checksum;

/* loaded from: classes7.dex */
public class FNV32 implements Checksum {

    /* renamed from: ᇰ, reason: contains not printable characters */
    public static final int f22036 = -2128831035;

    /* renamed from: 㫿, reason: contains not printable characters */
    public static final int f22037 = 16777619;

    /* renamed from: 㫞, reason: contains not printable characters */
    public int f22038 = f22036;

    @Override // java.util.zip.Checksum
    public long getValue() {
        return this.f22038 & 4294967295L;
    }

    @Override // java.util.zip.Checksum
    public void reset() {
        this.f22038 = f22036;
    }

    @Override // java.util.zip.Checksum
    public void update(int i) {
        this.f22038 = ((i & 255) ^ this.f22038) * f22037;
    }

    @Override // java.util.zip.Checksum
    public void update(byte[] bArr, int i, int i2) {
        int i3 = i2 + i;
        while (i < i3) {
            this.f22038 = (this.f22038 ^ (bArr[i] & 255)) * f22037;
            i++;
        }
    }
}
