package org.greenrobot.essentials.hash;

import java.util.zip.Checksum;

/* loaded from: classes7.dex */
public class FNV64 implements Checksum {

    /* renamed from: ᇰ, reason: contains not printable characters */
    public static final long f22039 = -3750763034362895579L;

    /* renamed from: 㫿, reason: contains not printable characters */
    public static final long f22040 = 1099511628211L;

    /* renamed from: 㫞, reason: contains not printable characters */
    public long f22041 = f22039;

    @Override // java.util.zip.Checksum
    public long getValue() {
        return this.f22041;
    }

    @Override // java.util.zip.Checksum
    public void reset() {
        this.f22041 = f22039;
    }

    @Override // java.util.zip.Checksum
    public void update(int i) {
        this.f22041 = (this.f22041 ^ (i & 255)) * f22040;
    }

    @Override // java.util.zip.Checksum
    public void update(byte[] bArr, int i, int i2) {
        int i3 = i2 + i;
        while (i < i3) {
            this.f22041 = (this.f22041 ^ (255 & bArr[i])) * f22040;
            i++;
        }
    }
}
