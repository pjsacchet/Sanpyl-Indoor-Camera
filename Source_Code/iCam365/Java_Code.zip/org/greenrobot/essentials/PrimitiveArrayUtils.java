package org.greenrobot.essentials;

import com.google.common.base.Ascii;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.ByteOrder;
import java.util.NoSuchElementException;
import kotlin.jvm.internal.CharCompanionObject;
import sun.misc.Unsafe;

/* loaded from: classes7.dex */
public abstract class PrimitiveArrayUtils {

    /* renamed from: ᇰ, reason: contains not printable characters */
    public static final PrimitiveArrayUtils f22013 = new C5287();

    /* renamed from: 㫞, reason: contains not printable characters */
    public static volatile PrimitiveArrayUtils f22014;

    /* renamed from: org.greenrobot.essentials.PrimitiveArrayUtils$ᇰ, reason: contains not printable characters */
    /* loaded from: classes7.dex */
    public static class C5287 extends PrimitiveArrayUtils {
        public C5287() {
        }

        @Override // org.greenrobot.essentials.PrimitiveArrayUtils
        public int getIntBE(byte[] bArr, int i) {
            return (bArr[i] << Ascii.CAN) | (bArr[i + 3] & 255) | ((bArr[i + 2] & 255) << 8) | ((bArr[i + 1] & 255) << 16);
        }

        @Override // org.greenrobot.essentials.PrimitiveArrayUtils
        public int getIntLE(byte[] bArr, int i) {
            return (bArr[i + 3] << Ascii.CAN) | (bArr[i] & 255) | ((bArr[i + 1] & 255) << 8) | ((bArr[i + 2] & 255) << 16);
        }

        @Override // org.greenrobot.essentials.PrimitiveArrayUtils
        public long getLongBE(byte[] bArr, int i) {
            return (bArr[i] << 56) | (bArr[i + 7] & 255) | ((bArr[i + 6] & 255) << 8) | ((bArr[i + 5] & 255) << 16) | ((bArr[i + 4] & 255) << 24) | ((bArr[i + 3] & 255) << 32) | ((bArr[i + 2] & 255) << 40) | ((bArr[i + 1] & 255) << 48);
        }

        @Override // org.greenrobot.essentials.PrimitiveArrayUtils
        public long getLongLE(byte[] bArr, int i) {
            return (bArr[i + 7] << 56) | (bArr[i] & 255) | ((bArr[i + 1] & 255) << 8) | ((bArr[i + 2] & 255) << 16) | ((bArr[i + 3] & 255) << 24) | ((bArr[i + 4] & 255) << 32) | ((bArr[i + 5] & 255) << 40) | ((bArr[i + 6] & 255) << 48);
        }

        @Override // org.greenrobot.essentials.PrimitiveArrayUtils
        public int getIntLE(char[] cArr, int i) {
            return ((cArr[i + 1] & CharCompanionObject.MAX_VALUE) << 16) | (cArr[i] & CharCompanionObject.MAX_VALUE);
        }
    }

    public static PrimitiveArrayUtils getInstance() {
        PrimitiveArrayUtils primitiveArrayUtils = f22014;
        if (primitiveArrayUtils == null) {
            return f22013;
        }
        return primitiveArrayUtils;
    }

    public static PrimitiveArrayUtils getInstanceSafe() {
        return f22013;
    }

    public static boolean initUnsafeInstance() {
        if (f22014 == null && C5289.f22015 != null) {
            synchronized (PrimitiveArrayUtils.class) {
                if (f22014 != null) {
                    return true;
                }
                try {
                    f22014 = new C5289();
                    return true;
                } catch (Throwable unused) {
                    return false;
                }
            }
        }
        return false;
    }

    public abstract int getIntBE(byte[] bArr, int i);

    public abstract int getIntLE(byte[] bArr, int i);

    public abstract int getIntLE(char[] cArr, int i);

    public abstract long getLongBE(byte[] bArr, int i);

    public abstract long getLongLE(byte[] bArr, int i);

    /* renamed from: org.greenrobot.essentials.PrimitiveArrayUtils$㫿, reason: contains not printable characters */
    /* loaded from: classes7.dex */
    public static class C5289 extends PrimitiveArrayUtils {

        /* renamed from: ᦜ, reason: contains not printable characters */
        public static final Unsafe f22015;

        /* renamed from: ⴄ, reason: contains not printable characters */
        public static final long f22016;

        /* renamed from: 㡷, reason: contains not printable characters */
        public static final long f22017;

        /* renamed from: 㫿, reason: contains not printable characters */
        public static final boolean f22018 = ByteOrder.nativeOrder().equals(ByteOrder.BIG_ENDIAN);

        /* renamed from: 㯿, reason: contains not printable characters */
        public static final boolean f22019;

        static {
            boolean m17591 = m17591();
            f22019 = m17591;
            if (m17591) {
                Unsafe m17592 = m17592();
                f22015 = m17592;
                if (m17592 != null) {
                    f22017 = m17592.arrayBaseOffset(byte[].class);
                    f22016 = m17592.arrayBaseOffset(char[].class);
                    return;
                } else {
                    f22017 = 0L;
                    f22016 = 0L;
                    return;
                }
            }
            f22015 = null;
            f22017 = 0L;
            f22016 = 0L;
        }

        public C5289() {
        }

        /* renamed from: ᇰ, reason: contains not printable characters */
        public static boolean m17589() {
            String property = System.getProperty("os.arch");
            if (property != null && property.matches("^(i[3-6]86|x86(_64)?|x64|amd64)$")) {
                return true;
            }
            return false;
        }

        /* renamed from: 㫿, reason: contains not printable characters */
        public static boolean m17591() {
            boolean z;
            String property = System.getProperty("java.vendor");
            if (property != null && property.contains("Android")) {
                z = true;
            } else {
                z = false;
            }
            if (z) {
                return m17589();
            }
            try {
                Method declaredMethod = Class.forName("java.nio.Bits", false, ClassLoader.getSystemClassLoader()).getDeclaredMethod("unaligned", new Class[0]);
                declaredMethod.setAccessible(true);
                return Boolean.TRUE.equals(declaredMethod.invoke(null, new Object[0]));
            } catch (Throwable unused) {
                return m17589();
            }
        }

        /* renamed from: 㯿, reason: contains not printable characters */
        public static Unsafe m17592() {
            Field declaredField;
            try {
                try {
                    declaredField = Unsafe.class.getDeclaredField("theUnsafe");
                } catch (NoSuchElementException unused) {
                    declaredField = Unsafe.class.getDeclaredField("THE_ONE");
                }
                declaredField.setAccessible(true);
                Unsafe unsafe = (Unsafe) declaredField.get(null);
                int i = unsafe.getInt(new byte[]{-54, -2, -70, -66}, unsafe.arrayBaseOffset(byte[].class));
                if (i == -889275714) {
                    if (f22018) {
                        return unsafe;
                    }
                    System.err.println("Big endian confusion");
                } else if (i == -1095041334) {
                    if (!f22018) {
                        return unsafe;
                    }
                    System.err.println("Little endian confusion");
                }
            } catch (Throwable unused2) {
            }
            return null;
        }

        @Override // org.greenrobot.essentials.PrimitiveArrayUtils
        public int getIntBE(byte[] bArr, int i) {
            int i2 = f22015.getInt(bArr, f22017 + i);
            if (f22018) {
                return i2;
            }
            return Integer.reverseBytes(i2);
        }

        @Override // org.greenrobot.essentials.PrimitiveArrayUtils
        public int getIntLE(byte[] bArr, int i) {
            int i2 = f22015.getInt(bArr, f22017 + i);
            return f22018 ? Integer.reverseBytes(i2) : i2;
        }

        @Override // org.greenrobot.essentials.PrimitiveArrayUtils
        public long getLongBE(byte[] bArr, int i) {
            long j = f22015.getLong(bArr, f22017 + i);
            if (f22018) {
                return j;
            }
            return Long.reverseBytes(j);
        }

        @Override // org.greenrobot.essentials.PrimitiveArrayUtils
        public long getLongLE(byte[] bArr, int i) {
            long j = f22015.getLong(bArr, f22017 + i);
            if (f22018) {
                return Long.reverseBytes(j);
            }
            return j;
        }

        @Override // org.greenrobot.essentials.PrimitiveArrayUtils
        public int getIntLE(char[] cArr, int i) {
            int i2 = f22015.getInt(cArr, f22016 + (i << 2));
            return f22018 ? Integer.reverseBytes(i2) : i2;
        }
    }
}
