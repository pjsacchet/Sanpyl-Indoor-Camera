package org.greenrobot.essentials.io;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/* loaded from: classes7.dex */
public class PipelineOutputStream extends OutputStream {
    public final CircularByteBuffer buffer;
    public boolean closedIn;
    public boolean closedOut;

    /* renamed from: 㫞, reason: contains not printable characters */
    public final PipelineInputStream f22072;

    public PipelineOutputStream() {
        this(8192);
    }

    @Override // java.io.OutputStream, java.io.Closeable, java.lang.AutoCloseable
    public synchronized void close() throws IOException {
        this.closedOut = true;
        notifyBuffer();
    }

    public InputStream getInputStream() {
        return this.f22072;
    }

    public void notifyBuffer() {
        notifyAll();
    }

    public void waitForBuffer() throws IOException {
        try {
            wait();
        } catch (InterruptedException e) {
            throw new IOException(e);
        }
    }

    @Override // java.io.OutputStream
    public synchronized void write(byte[] bArr, int i, int i2) throws IOException {
        int i3 = 0;
        while (i3 != i2) {
            m17599();
            int put = this.buffer.put(bArr, i + i3, i2 - i3);
            if (put > 0) {
                i3 += put;
                notifyBuffer();
            } else {
                waitForBuffer();
            }
        }
    }

    /* renamed from: 㫞, reason: contains not printable characters */
    public final void m17599() throws IOException {
        if (!this.closedIn) {
        } else {
            throw new IOException("PipelineInputStream was closed (broken pipeline)");
        }
    }

    public PipelineOutputStream(int i) {
        this.buffer = new CircularByteBuffer(i);
        this.f22072 = new PipelineInputStream();
    }

    @Override // java.io.OutputStream
    public synchronized void write(int i) throws IOException {
        m17599();
        while (!this.buffer.put((byte) i)) {
            waitForBuffer();
            m17599();
        }
        notifyBuffer();
    }

    /* loaded from: classes7.dex */
    public class PipelineInputStream extends InputStream {
        public PipelineInputStream() {
        }

        @Override // java.io.InputStream
        public int available() throws IOException {
            return PipelineOutputStream.this.buffer.available();
        }

        @Override // java.io.InputStream, java.io.Closeable, java.lang.AutoCloseable
        public void close() throws IOException {
            PipelineOutputStream.this.closedIn = true;
        }

        @Override // java.io.InputStream
        public int read(byte[] bArr, int i, int i2) throws IOException {
            int i3;
            if (i2 == 0) {
                return PipelineOutputStream.this.closedOut ? -1 : 0;
            }
            synchronized (PipelineOutputStream.this) {
                do {
                    i3 = PipelineOutputStream.this.buffer.get(bArr, i, i2);
                    if (i3 == 0) {
                        PipelineOutputStream pipelineOutputStream = PipelineOutputStream.this;
                        if (pipelineOutputStream.closedOut) {
                            return -1;
                        }
                        pipelineOutputStream.waitForBuffer();
                    }
                } while (i3 == 0);
                PipelineOutputStream.this.notifyBuffer();
                return i3;
            }
        }

        @Override // java.io.InputStream
        public long skip(long j) throws IOException {
            int min = (int) Math.min(j, 2147483647L);
            synchronized (PipelineOutputStream.this) {
                int i = 0;
                while (i < min) {
                    int skip = PipelineOutputStream.this.buffer.skip(min - i);
                    if (skip == 0) {
                        PipelineOutputStream pipelineOutputStream = PipelineOutputStream.this;
                        if (pipelineOutputStream.closedOut) {
                            return i;
                        }
                        pipelineOutputStream.waitForBuffer();
                    } else {
                        i += skip;
                        PipelineOutputStream.this.notifyBuffer();
                    }
                }
                return i;
            }
        }

        @Override // java.io.InputStream
        public int read() throws IOException {
            synchronized (PipelineOutputStream.this) {
                int i = PipelineOutputStream.this.buffer.get();
                while (i == -1) {
                    PipelineOutputStream pipelineOutputStream = PipelineOutputStream.this;
                    if (pipelineOutputStream.closedOut) {
                        return -1;
                    }
                    pipelineOutputStream.waitForBuffer();
                    i = PipelineOutputStream.this.buffer.get();
                }
                PipelineOutputStream.this.notifyBuffer();
                return i;
            }
        }
    }
}
