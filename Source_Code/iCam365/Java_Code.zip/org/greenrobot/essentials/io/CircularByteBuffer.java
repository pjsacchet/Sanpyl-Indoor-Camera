package org.greenrobot.essentials.io;

/* loaded from: classes7.dex */
public class CircularByteBuffer {

    /* renamed from: ᇰ, reason: contains not printable characters */
    public final int f22064;

    /* renamed from: ᦜ, reason: contains not printable characters */
    public int f22065;

    /* renamed from: 㫞, reason: contains not printable characters */
    public final byte[] f22066;

    /* renamed from: 㫿, reason: contains not printable characters */
    public int f22067;

    /* renamed from: 㯿, reason: contains not printable characters */
    public int f22068;

    public CircularByteBuffer() {
        this(8192);
    }

    public synchronized int available() {
        return this.f22067;
    }

    public int capacity() {
        return this.f22064;
    }

    public synchronized void clear() {
        this.f22067 = 0;
        this.f22065 = 0;
        this.f22068 = 0;
    }

    public synchronized int free() {
        return this.f22064 - this.f22067;
    }

    public synchronized int get() {
        int i = this.f22067;
        if (i == 0) {
            return -1;
        }
        byte[] bArr = this.f22066;
        int i2 = this.f22068;
        byte b2 = bArr[i2];
        this.f22068 = (i2 + 1) % this.f22064;
        this.f22067 = i - 1;
        return b2;
    }

    public synchronized int peek() {
        return this.f22067 > 0 ? this.f22066[this.f22068] : (byte) -1;
    }

    public synchronized boolean put(byte b2) {
        int i = this.f22067;
        int i2 = this.f22064;
        if (i == i2) {
            return false;
        }
        byte[] bArr = this.f22066;
        int i3 = this.f22065;
        bArr[i3] = b2;
        this.f22065 = (i3 + 1) % i2;
        this.f22067 = i + 1;
        return true;
    }

    public synchronized byte[] rawBuffer() {
        return this.f22066;
    }

    public synchronized int rawIndexGet() {
        return this.f22068;
    }

    public synchronized int rawIndexPut() {
        return this.f22065;
    }

    public synchronized int skip(int i) {
        int i2 = this.f22067;
        if (i > i2) {
            i = i2;
        }
        this.f22068 = (this.f22068 + i) % this.f22064;
        this.f22067 = i2 - i;
        return i;
    }

    public CircularByteBuffer(int i) {
        this.f22064 = i;
        this.f22066 = new byte[i];
    }

    public int get(byte[] bArr) {
        return get(bArr, 0, bArr.length);
    }

    public int put(byte[] bArr) {
        return put(bArr, 0, bArr.length);
    }

    public synchronized int get(byte[] bArr, int i, int i2) {
        if (this.f22067 == 0) {
            return 0;
        }
        int i3 = this.f22068;
        int i4 = this.f22065;
        if (i3 >= i4) {
            i4 = this.f22064;
        }
        int min = Math.min(i4 - i3, i2);
        System.arraycopy(this.f22066, this.f22068, bArr, i, min);
        int i5 = this.f22068 + min;
        this.f22068 = i5;
        if (i5 == this.f22064) {
            int min2 = Math.min(i2 - min, this.f22065);
            if (min2 > 0) {
                System.arraycopy(this.f22066, 0, bArr, i + min, min2);
                this.f22068 = min2;
                min += min2;
            } else {
                this.f22068 = 0;
            }
        }
        this.f22067 -= min;
        return min;
    }

    public synchronized int put(byte[] bArr, int i, int i2) {
        int i3 = this.f22067;
        int i4 = this.f22064;
        if (i3 == i4) {
            return 0;
        }
        int i5 = this.f22065;
        int i6 = this.f22068;
        if (i5 < i6) {
            i4 = i6;
        }
        int min = Math.min(i4 - i5, i2);
        System.arraycopy(bArr, i, this.f22066, this.f22065, min);
        int i7 = this.f22065 + min;
        this.f22065 = i7;
        if (i7 == this.f22064) {
            int min2 = Math.min(i2 - min, this.f22068);
            if (min2 > 0) {
                System.arraycopy(bArr, i + min, this.f22066, 0, min2);
                this.f22065 = min2;
                min += min2;
            } else {
                this.f22065 = 0;
            }
        }
        this.f22067 += min;
        return min;
    }
}
