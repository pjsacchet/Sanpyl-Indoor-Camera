package org.json;

import anetwork.channel.util.RequestConstant;
import java.io.IOException;
import java.io.Writer;

/* loaded from: classes7.dex */
public class JSONWriter {
    private static final int maxdepth = 20;
    private boolean comma = false;
    public char mode = 'i';
    private JSONObject[] stack = new JSONObject[20];
    private int top = 0;
    public Writer writer;

    public JSONWriter(Writer writer) {
        this.writer = writer;
    }

    private JSONWriter append(String str) throws JSONException {
        if (str != null) {
            char c2 = this.mode;
            if (c2 != 'o' && c2 != 'a') {
                throw new JSONException("Value out of sequence.");
            }
            try {
                if (this.comma && c2 == 'a') {
                    this.writer.write(44);
                }
                this.writer.write(str);
                if (this.mode == 'o') {
                    this.mode = 'k';
                }
                this.comma = true;
                return this;
            } catch (IOException e) {
                throw new JSONException(e);
            }
        }
        throw new JSONException("Null pointer");
    }

    private JSONWriter end(char c2, char c3) throws JSONException {
        String str;
        if (this.mode != c2) {
            if (c2 == 'o') {
                str = "Misplaced endObject.";
            } else {
                str = "Misplaced endArray.";
            }
            throw new JSONException(str);
        }
        pop(c2);
        try {
            this.writer.write(c3);
            this.comma = true;
            return this;
        } catch (IOException e) {
            throw new JSONException(e);
        }
    }

    private void pop(char c2) throws JSONException {
        char c3;
        int i = this.top;
        if (i > 0) {
            JSONObject[] jSONObjectArr = this.stack;
            char c4 = 'a';
            if (jSONObjectArr[i - 1] == null) {
                c3 = 'a';
            } else {
                c3 = 'k';
            }
            if (c3 == c2) {
                int i2 = i - 1;
                this.top = i2;
                if (i2 == 0) {
                    c4 = 'd';
                } else if (jSONObjectArr[i2 - 1] != null) {
                    c4 = 'k';
                }
                this.mode = c4;
                return;
            }
            throw new JSONException("Nesting error.");
        }
        throw new JSONException("Nesting error.");
    }

    private void push(JSONObject jSONObject) throws JSONException {
        char c2;
        int i = this.top;
        if (i < 20) {
            this.stack[i] = jSONObject;
            if (jSONObject == null) {
                c2 = 'a';
            } else {
                c2 = 'k';
            }
            this.mode = c2;
            this.top = i + 1;
            return;
        }
        throw new JSONException("Nesting too deep.");
    }

    public JSONWriter array() throws JSONException {
        char c2 = this.mode;
        if (c2 != 'i' && c2 != 'o' && c2 != 'a') {
            throw new JSONException("Misplaced array.");
        }
        push(null);
        append("[");
        this.comma = false;
        return this;
    }

    public JSONWriter endArray() throws JSONException {
        return end('a', ']');
    }

    public JSONWriter endObject() throws JSONException {
        return end('k', '}');
    }

    public JSONWriter key(String str) throws JSONException {
        if (str != null) {
            if (this.mode == 'k') {
                try {
                    if (this.comma) {
                        this.writer.write(44);
                    }
                    this.stack[this.top - 1].putOnce(str, Boolean.TRUE);
                    this.writer.write(JSONObject.quote(str));
                    this.writer.write(58);
                    this.comma = false;
                    this.mode = 'o';
                    return this;
                } catch (IOException e) {
                    throw new JSONException(e);
                }
            }
            throw new JSONException("Misplaced key.");
        }
        throw new JSONException("Null key.");
    }

    public JSONWriter object() throws JSONException {
        if (this.mode == 'i') {
            this.mode = 'o';
        }
        char c2 = this.mode;
        if (c2 != 'o' && c2 != 'a') {
            throw new JSONException("Misplaced object.");
        }
        append("{");
        push(new JSONObject());
        this.comma = false;
        return this;
    }

    public JSONWriter value(boolean z) throws JSONException {
        return append(z ? RequestConstant.TRUE : RequestConstant.FALSE);
    }

    public JSONWriter value(double d) throws JSONException {
        return value(new Double(d));
    }

    public JSONWriter value(long j) throws JSONException {
        return append(Long.toString(j));
    }

    public JSONWriter value(Object obj) throws JSONException {
        return append(JSONObject.valueToString(obj));
    }
}
