package org.json;

/* loaded from: classes7.dex */
public interface JSONString {
    String toJSONString();
}
