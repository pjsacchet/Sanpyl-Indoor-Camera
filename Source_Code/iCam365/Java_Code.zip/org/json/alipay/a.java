package org.json.alipay;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;

/* loaded from: classes7.dex */
public class a {

    /* renamed from: a, reason: collision with root package name */
    private ArrayList f49787a;

    public a() {
        this.f49787a = new ArrayList();
    }

    public a(Object obj) {
        this();
        if (!obj.getClass().isArray()) {
            throw new JSONException("JSONArray initial value should be a string or collection or array.");
        }
        int length = Array.getLength(obj);
        for (int i = 0; i < length; i++) {
            a(Array.get(obj, i));
        }
    }

    public a(String str) {
        this(new c(str));
    }

    public a(Collection collection) {
        this.f49787a = collection == null ? new ArrayList() : new ArrayList(collection);
    }

    public a(c cVar) {
        this();
        char c2;
        ArrayList arrayList;
        Object d;
        char c3 = cVar.c();
        if (c3 == '[') {
            c2 = ']';
        } else {
            if (c3 != '(') {
                throw cVar.a("A JSONArray text must start with '['");
            }
            c2 = ')';
        }
        if (cVar.c() == ']') {
            return;
        }
        do {
            cVar.a();
            char c4 = cVar.c();
            cVar.a();
            if (c4 == ',') {
                arrayList = this.f49787a;
                d = null;
            } else {
                arrayList = this.f49787a;
                d = cVar.d();
            }
            arrayList.add(d);
            char c5 = cVar.c();
            if (c5 != ')') {
                if (c5 != ',' && c5 != ';') {
                    if (c5 != ']') {
                        throw cVar.a("Expected a ',' or ']'");
                    }
                }
            }
            if (c2 == c5) {
                return;
            }
            throw cVar.a("Expected a '" + new Character(c2) + "'");
        } while (cVar.c() != ']');
    }

    public int a() {
        return this.f49787a.size();
    }

    public Object a(int i) {
        Object b2 = b(i);
        if (b2 != null) {
            return b2;
        }
        throw new JSONException("JSONArray[" + i + "] not found.");
    }

    public String a(String str) {
        int a2 = a();
        StringBuffer stringBuffer = new StringBuffer();
        for (int i = 0; i < a2; i++) {
            if (i > 0) {
                stringBuffer.append(str);
            }
            stringBuffer.append(b.b(this.f49787a.get(i)));
        }
        return stringBuffer.toString();
    }

    public a a(Object obj) {
        this.f49787a.add(obj);
        return this;
    }

    public Object b(int i) {
        if (i < 0 || i >= a()) {
            return null;
        }
        return this.f49787a.get(i);
    }

    public String toString() {
        try {
            return '[' + a(",") + ']';
        } catch (Exception unused) {
            return null;
        }
    }
}
