package org.json.alipay;

import anetwork.channel.util.RequestConstant;
import com.tencent.qcloud.core.util.IOUtils;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

/* loaded from: classes7.dex */
public class c {

    /* renamed from: a, reason: collision with root package name */
    private int f49790a;

    /* renamed from: b, reason: collision with root package name */
    private Reader f49791b;

    /* renamed from: c, reason: collision with root package name */
    private char f49792c;
    private boolean d;

    public c(Reader reader) {
        this.f49791b = reader.markSupported() ? reader : new BufferedReader(reader);
        this.d = false;
        this.f49790a = 0;
    }

    public c(String str) {
        this(new StringReader(str));
    }

    /* JADX WARN: Code restructure failed: missing block: B:51:0x0068, code lost:
    
        throw a("Unterminated string");
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public String a(char c2) {
        int i;
        StringBuffer stringBuffer = new StringBuffer();
        while (true) {
            char b2 = b();
            if (b2 == 0 || b2 == '\n' || b2 == '\r') {
                break;
            }
            if (b2 == '\\') {
                b2 = b();
                if (b2 == 'b') {
                    b2 = '\b';
                } else if (b2 == 'f') {
                    b2 = '\f';
                } else if (b2 == 'n') {
                    stringBuffer.append('\n');
                } else if (b2 != 'r') {
                    if (b2 != 'x') {
                        if (b2 != 't') {
                            i = b2 == 'u' ? 4 : 2;
                        } else {
                            b2 = '\t';
                        }
                    }
                    b2 = (char) Integer.parseInt(a(i), 16);
                } else {
                    stringBuffer.append('\r');
                }
            } else if (b2 == c2) {
                return stringBuffer.toString();
            }
            stringBuffer.append(b2);
        }
    }

    public String a(int i) {
        if (i == 0) {
            return "";
        }
        char[] cArr = new char[i];
        int i2 = 0;
        if (this.d) {
            this.d = false;
            cArr[0] = this.f49792c;
            i2 = 1;
        }
        while (i2 < i) {
            try {
                int read = this.f49791b.read(cArr, i2, i - i2);
                if (read == -1) {
                    break;
                }
                i2 += read;
            } catch (IOException e) {
                throw new JSONException(e);
            }
        }
        this.f49790a += i2;
        if (i2 < i) {
            throw a("Substring bounds error");
        }
        this.f49792c = cArr[i - 1];
        return new String(cArr);
    }

    public JSONException a(String str) {
        return new JSONException(str + toString());
    }

    public void a() {
        int i;
        if (this.d || (i = this.f49790a) <= 0) {
            throw new JSONException("Stepping back two steps is not supported");
        }
        this.f49790a = i - 1;
        this.d = true;
    }

    public char b() {
        if (this.d) {
            this.d = false;
            char c2 = this.f49792c;
            if (c2 != 0) {
                this.f49790a++;
            }
            return c2;
        }
        try {
            int read = this.f49791b.read();
            if (read <= 0) {
                this.f49792c = (char) 0;
                return (char) 0;
            }
            this.f49790a++;
            char c3 = (char) read;
            this.f49792c = c3;
            return c3;
        } catch (IOException e) {
            throw new JSONException(e);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:0x0054, code lost:
    
        return r0;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public char c() {
        char b2;
        char b3;
        while (true) {
            char b4 = b();
            if (b4 == '/') {
                char b5 = b();
                if (b5 != '*') {
                    if (b5 != '/') {
                        a();
                        return IOUtils.DIR_SEPARATOR_UNIX;
                    }
                    do {
                        b2 = b();
                        if (b2 != '\n' && b2 != '\r') {
                        }
                    } while (b2 != 0);
                } else {
                    while (true) {
                        char b6 = b();
                        if (b6 == 0) {
                            throw a("Unclosed comment");
                        }
                        if (b6 == '*') {
                            if (b() == '/') {
                                break;
                            }
                            a();
                        }
                    }
                }
            } else if (b4 == '#') {
                do {
                    b3 = b();
                    if (b3 != '\n' && b3 != '\r') {
                    }
                } while (b3 != 0);
            } else if (b4 == 0 || b4 > ' ') {
                break;
            }
        }
    }

    public Object d() {
        char c2 = c();
        if (c2 != '\"') {
            if (c2 != '[') {
                if (c2 == '{') {
                    a();
                    return new b(this);
                }
                if (c2 != '\'') {
                    if (c2 != '(') {
                        StringBuffer stringBuffer = new StringBuffer();
                        char c3 = c2;
                        while (c3 >= ' ' && ",:]}/\\\"[{;=#".indexOf(c3) < 0) {
                            stringBuffer.append(c3);
                            c3 = b();
                        }
                        a();
                        String trim = stringBuffer.toString().trim();
                        if (trim.equals("")) {
                            throw a("Missing value");
                        }
                        if (trim.equalsIgnoreCase(RequestConstant.TRUE)) {
                            return Boolean.TRUE;
                        }
                        if (trim.equalsIgnoreCase(RequestConstant.FALSE)) {
                            return Boolean.FALSE;
                        }
                        if (trim.equalsIgnoreCase("null")) {
                            return b.f49788a;
                        }
                        if ((c2 < '0' || c2 > '9') && c2 != '.' && c2 != '-' && c2 != '+') {
                            return trim;
                        }
                        if (c2 == '0') {
                            try {
                                return (trim.length() <= 2 || !(trim.charAt(1) == 'x' || trim.charAt(1) == 'X')) ? new Integer(Integer.parseInt(trim, 8)) : new Integer(Integer.parseInt(trim.substring(2), 16));
                            } catch (Exception unused) {
                            }
                        }
                        try {
                            try {
                                try {
                                    return new Integer(trim);
                                } catch (Exception unused2) {
                                    return new Double(trim);
                                }
                            } catch (Exception unused3) {
                                return new Long(trim);
                            }
                        } catch (Exception unused4) {
                            return trim;
                        }
                    }
                }
            }
            a();
            return new a(this);
        }
        return a(c2);
    }

    public String toString() {
        return " at character " + this.f49790a;
    }
}
