package org.json;

import com.alipay.sdk.m.p.a;
import com.tencent.qcloud.core.util.IOUtils;
import java.util.Iterator;
import kotlin.text.Typography;

/* loaded from: classes7.dex */
public class XML {
    public static final Character AMP = new Character(Typography.amp);
    public static final Character APOS = new Character('\'');
    public static final Character BANG = new Character('!');
    public static final Character EQ = new Character(a.h);
    public static final Character GT = new Character(Typography.greater);
    public static final Character LT = new Character(Typography.less);
    public static final Character QUEST = new Character('?');
    public static final Character QUOT = new Character(Typography.quote);
    public static final Character SLASH = new Character(IOUtils.DIR_SEPARATOR_UNIX);

    public static String escape(String str) {
        StringBuffer stringBuffer = new StringBuffer();
        int length = str.length();
        for (int i = 0; i < length; i++) {
            char charAt = str.charAt(i);
            if (charAt != '\"') {
                if (charAt != '&') {
                    if (charAt != '<') {
                        if (charAt != '>') {
                            stringBuffer.append(charAt);
                        } else {
                            stringBuffer.append("&gt;");
                        }
                    } else {
                        stringBuffer.append("&lt;");
                    }
                } else {
                    stringBuffer.append("&amp;");
                }
            } else {
                stringBuffer.append("&quot;");
            }
        }
        return stringBuffer.toString();
    }

    public static void noSpace(String str) throws JSONException {
        int length = str.length();
        if (length != 0) {
            for (int i = 0; i < length; i++) {
                if (Character.isWhitespace(str.charAt(i))) {
                    throw new JSONException("'" + str + "' contains a space character.");
                }
            }
            return;
        }
        throw new JSONException("Empty string.");
    }

    /* JADX WARN: Code restructure failed: missing block: B:73:0x00ef, code lost:
    
        r7 = r10.nextToken();
     */
    /* JADX WARN: Code restructure failed: missing block: B:74:0x00f5, code lost:
    
        if ((r7 instanceof java.lang.String) == false) goto L117;
     */
    /* JADX WARN: Code restructure failed: missing block: B:78:0x0107, code lost:
    
        throw r10.syntaxError("Missing value");
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private static boolean parse(XMLTokener xMLTokener, JSONObject jSONObject, String str) throws JSONException {
        String str2;
        Object nextToken;
        Object nextToken2 = xMLTokener.nextToken();
        int i = 1;
        if (nextToken2 == BANG) {
            char next = xMLTokener.next();
            if (next == '-') {
                if (xMLTokener.next() == '-') {
                    xMLTokener.skipPast("-->");
                    return false;
                }
                xMLTokener.back();
            } else if (next == '[') {
                if (xMLTokener.nextToken().equals("CDATA") && xMLTokener.next() == '[') {
                    String nextCDATA = xMLTokener.nextCDATA();
                    if (nextCDATA.length() > 0) {
                        jSONObject.accumulate("content", nextCDATA);
                    }
                    return false;
                }
                throw xMLTokener.syntaxError("Expected 'CDATA['");
            }
            do {
                Object nextMeta = xMLTokener.nextMeta();
                if (nextMeta != null) {
                    if (nextMeta == LT) {
                        i++;
                    } else if (nextMeta == GT) {
                        i--;
                    }
                } else {
                    throw xMLTokener.syntaxError("Missing '>' after '<!'.");
                }
            } while (i > 0);
            return false;
        }
        if (nextToken2 == QUEST) {
            xMLTokener.skipPast("?>");
            return false;
        }
        if (nextToken2 == SLASH) {
            Object nextToken3 = xMLTokener.nextToken();
            if (str != null) {
                if (nextToken3.equals(str)) {
                    if (xMLTokener.nextToken() == GT) {
                        return true;
                    }
                    throw xMLTokener.syntaxError("Misshaped close tag");
                }
                throw xMLTokener.syntaxError("Mismatched " + str + " and " + nextToken3);
            }
            throw xMLTokener.syntaxError("Mismatched close tag" + nextToken3);
        }
        if (!(nextToken2 instanceof Character)) {
            String str3 = (String) nextToken2;
            JSONObject jSONObject2 = new JSONObject();
            while (true) {
                Object obj = null;
                while (true) {
                    if (obj == null) {
                        obj = xMLTokener.nextToken();
                    }
                    if (obj instanceof String) {
                        str2 = (String) obj;
                        Object nextToken4 = xMLTokener.nextToken();
                        if (nextToken4 == EQ) {
                            break;
                        }
                        jSONObject2.accumulate(str2, "");
                        obj = nextToken4;
                    } else {
                        if (obj == SLASH) {
                            if (xMLTokener.nextToken() == GT) {
                                jSONObject.accumulate(str3, jSONObject2);
                                return false;
                            }
                            throw xMLTokener.syntaxError("Misshaped tag");
                        }
                        if (obj != GT) {
                            throw xMLTokener.syntaxError("Misshaped tag");
                        }
                        while (true) {
                            Object nextContent = xMLTokener.nextContent();
                            if (nextContent == null) {
                                if (str3 == null) {
                                    return false;
                                }
                                throw xMLTokener.syntaxError("Unclosed tag " + str3);
                            }
                            if (nextContent instanceof String) {
                                String str4 = (String) nextContent;
                                if (str4.length() > 0) {
                                    jSONObject2.accumulate("content", JSONObject.stringToValue(str4));
                                }
                            } else if (nextContent == LT && parse(xMLTokener, jSONObject2, str3)) {
                                if (jSONObject2.length() == 0) {
                                    jSONObject.accumulate(str3, "");
                                } else if (jSONObject2.length() == 1 && jSONObject2.opt("content") != null) {
                                    jSONObject.accumulate(str3, jSONObject2.opt("content"));
                                } else {
                                    jSONObject.accumulate(str3, jSONObject2);
                                }
                                return false;
                            }
                        }
                    }
                }
                jSONObject2.accumulate(str2, JSONObject.stringToValue((String) nextToken));
            }
        } else {
            throw xMLTokener.syntaxError("Misshaped tag");
        }
    }

    public static JSONObject toJSONObject(String str) throws JSONException {
        JSONObject jSONObject = new JSONObject();
        XMLTokener xMLTokener = new XMLTokener(str);
        while (xMLTokener.more() && xMLTokener.skipPast("<")) {
            parse(xMLTokener, jSONObject, null);
        }
        return jSONObject;
    }

    public static String toString(Object obj) throws JSONException {
        return toString(obj, null);
    }

    public static String toString(Object obj, String str) throws JSONException {
        StringBuffer stringBuffer = new StringBuffer();
        if (obj instanceof JSONObject) {
            if (str != null) {
                stringBuffer.append(Typography.less);
                stringBuffer.append(str);
                stringBuffer.append(Typography.greater);
            }
            JSONObject jSONObject = (JSONObject) obj;
            Iterator keys = jSONObject.keys();
            while (keys.hasNext()) {
                String obj2 = keys.next().toString();
                Object opt = jSONObject.opt(obj2);
                if (opt == null) {
                    opt = "";
                }
                if (opt instanceof String) {
                }
                if (obj2.equals("content")) {
                    if (opt instanceof JSONArray) {
                        JSONArray jSONArray = (JSONArray) opt;
                        int length = jSONArray.length();
                        for (int i = 0; i < length; i++) {
                            if (i > 0) {
                                stringBuffer.append('\n');
                            }
                            stringBuffer.append(escape(jSONArray.get(i).toString()));
                        }
                    } else {
                        stringBuffer.append(escape(opt.toString()));
                    }
                } else if (opt instanceof JSONArray) {
                    JSONArray jSONArray2 = (JSONArray) opt;
                    int length2 = jSONArray2.length();
                    for (int i2 = 0; i2 < length2; i2++) {
                        Object obj3 = jSONArray2.get(i2);
                        if (obj3 instanceof JSONArray) {
                            stringBuffer.append(Typography.less);
                            stringBuffer.append(obj2);
                            stringBuffer.append(Typography.greater);
                            stringBuffer.append(toString(obj3));
                            stringBuffer.append("</");
                            stringBuffer.append(obj2);
                            stringBuffer.append(Typography.greater);
                        } else {
                            stringBuffer.append(toString(obj3, obj2));
                        }
                    }
                } else if (opt.equals("")) {
                    stringBuffer.append(Typography.less);
                    stringBuffer.append(obj2);
                    stringBuffer.append("/>");
                } else {
                    stringBuffer.append(toString(opt, obj2));
                }
            }
            if (str != null) {
                stringBuffer.append("</");
                stringBuffer.append(str);
                stringBuffer.append(Typography.greater);
            }
            return stringBuffer.toString();
        }
        if (obj instanceof JSONArray) {
            JSONArray jSONArray3 = (JSONArray) obj;
            int length3 = jSONArray3.length();
            for (int i3 = 0; i3 < length3; i3++) {
                stringBuffer.append(toString(jSONArray3.opt(i3), str == null ? "array" : str));
            }
            return stringBuffer.toString();
        }
        String escape = obj == null ? "null" : escape(obj.toString());
        if (str == null) {
            return "\"" + escape + "\"";
        }
        if (escape.length() == 0) {
            return "<" + str + "/>";
        }
        return "<" + str + ">" + escape + "</" + str + ">";
    }
}
