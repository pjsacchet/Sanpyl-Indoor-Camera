package org.json;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

/* loaded from: classes7.dex */
public class JSONTokener {
    private int index;
    private char lastChar;
    private Reader reader;
    private boolean useLastChar;

    public JSONTokener(Reader reader) {
        this.reader = reader.markSupported() ? reader : new BufferedReader(reader);
        this.useLastChar = false;
        this.index = 0;
    }

    public static int dehexchar(char c2) {
        if (c2 >= '0' && c2 <= '9') {
            return c2 - '0';
        }
        if (c2 >= 'A' && c2 <= 'F') {
            return c2 - '7';
        }
        if (c2 < 'a' || c2 > 'f') {
            return -1;
        }
        return c2 - 'W';
    }

    public void back() throws JSONException {
        int i;
        if (!this.useLastChar && (i = this.index) > 0) {
            this.index = i - 1;
            this.useLastChar = true;
            return;
        }
        throw new JSONException("Stepping back two steps is not supported");
    }

    public boolean more() throws JSONException {
        if (next() == 0) {
            return false;
        }
        back();
        return true;
    }

    public char next() throws JSONException {
        if (this.useLastChar) {
            this.useLastChar = false;
            char c2 = this.lastChar;
            if (c2 != 0) {
                this.index++;
            }
            return c2;
        }
        try {
            int read = this.reader.read();
            if (read <= 0) {
                this.lastChar = (char) 0;
                return (char) 0;
            }
            this.index++;
            char c3 = (char) read;
            this.lastChar = c3;
            return c3;
        } catch (IOException e) {
            throw new JSONException(e);
        }
    }

    public char nextClean() throws JSONException {
        char next;
        do {
            next = next();
            if (next == 0) {
                break;
            }
        } while (next <= ' ');
        return next;
    }

    /* JADX WARN: Code restructure failed: missing block: B:66:0x0084, code lost:
    
        throw syntaxError("Unterminated string");
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public String nextString(char c2) throws JSONException {
        StringBuffer stringBuffer = new StringBuffer();
        while (true) {
            char next = next();
            if (next == 0 || next == '\n' || next == '\r') {
                break;
            }
            if (next != '\\') {
                if (next == c2) {
                    return stringBuffer.toString();
                }
                stringBuffer.append(next);
            } else {
                char next2 = next();
                if (next2 != 'b') {
                    if (next2 != 'f') {
                        if (next2 != 'n') {
                            if (next2 != 'r') {
                                if (next2 != 'x') {
                                    if (next2 != 't') {
                                        if (next2 != 'u') {
                                            stringBuffer.append(next2);
                                        } else {
                                            stringBuffer.append((char) Integer.parseInt(next(4), 16));
                                        }
                                    } else {
                                        stringBuffer.append('\t');
                                    }
                                } else {
                                    stringBuffer.append((char) Integer.parseInt(next(2), 16));
                                }
                            } else {
                                stringBuffer.append('\r');
                            }
                        } else {
                            stringBuffer.append('\n');
                        }
                    } else {
                        stringBuffer.append('\f');
                    }
                } else {
                    stringBuffer.append('\b');
                }
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:12:0x001c, code lost:
    
        back();
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public String nextTo(char c2) throws JSONException {
        StringBuffer stringBuffer = new StringBuffer();
        while (true) {
            char next = next();
            if (next == c2 || next == 0 || next == '\n' || next == '\r') {
                break;
            }
            stringBuffer.append(next);
        }
        return stringBuffer.toString().trim();
    }

    public Object nextValue() throws JSONException {
        char nextClean = nextClean();
        if (nextClean != '\"') {
            if (nextClean != '[') {
                if (nextClean != '{') {
                    if (nextClean != '\'') {
                        if (nextClean != '(') {
                            StringBuffer stringBuffer = new StringBuffer();
                            while (nextClean >= ' ' && ",:]}/\\\"[{;=#".indexOf(nextClean) < 0) {
                                stringBuffer.append(nextClean);
                                nextClean = next();
                            }
                            back();
                            String trim = stringBuffer.toString().trim();
                            if (!trim.equals("")) {
                                return JSONObject.stringToValue(trim);
                            }
                            throw syntaxError("Missing value");
                        }
                    }
                } else {
                    back();
                    return new JSONObject(this);
                }
            }
            back();
            return new JSONArray(this);
        }
        return nextString(nextClean);
    }

    public char skipTo(char c2) throws JSONException {
        char next;
        try {
            int i = this.index;
            this.reader.mark(Integer.MAX_VALUE);
            do {
                next = next();
                if (next == 0) {
                    this.reader.reset();
                    this.index = i;
                    return next;
                }
            } while (next != c2);
            back();
            return next;
        } catch (IOException e) {
            throw new JSONException(e);
        }
    }

    public JSONException syntaxError(String str) {
        return new JSONException(str + toString());
    }

    public String toString() {
        return " at character " + this.index;
    }

    public JSONTokener(String str) {
        this(new StringReader(str));
    }

    /* JADX WARN: Code restructure failed: missing block: B:12:0x0020, code lost:
    
        back();
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public String nextTo(String str) throws JSONException {
        StringBuffer stringBuffer = new StringBuffer();
        while (true) {
            char next = next();
            if (str.indexOf(next) >= 0 || next == 0 || next == '\n' || next == '\r') {
                break;
            }
            stringBuffer.append(next);
        }
        return stringBuffer.toString().trim();
    }

    public char next(char c2) throws JSONException {
        char next = next();
        if (next == c2) {
            return next;
        }
        throw syntaxError("Expected '" + c2 + "' and instead saw '" + next + "'");
    }

    public String next(int i) throws JSONException {
        if (i == 0) {
            return "";
        }
        char[] cArr = new char[i];
        int i2 = 0;
        if (this.useLastChar) {
            this.useLastChar = false;
            cArr[0] = this.lastChar;
            i2 = 1;
        }
        while (i2 < i) {
            try {
                int read = this.reader.read(cArr, i2, i - i2);
                if (read == -1) {
                    break;
                }
                i2 += read;
            } catch (IOException e) {
                throw new JSONException(e);
            }
        }
        this.index += i2;
        if (i2 >= i) {
            this.lastChar = cArr[i - 1];
            return new String(cArr);
        }
        throw syntaxError("Substring bounds error");
    }
}
