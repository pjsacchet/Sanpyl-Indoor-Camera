package org.mozilla.universalchardet;

import java.io.FileInputStream;
import org.mozilla.universalchardet.prober.CharsetProber;
import org.mozilla.universalchardet.prober.EscCharsetProber;
import org.mozilla.universalchardet.prober.Latin1Prober;
import org.mozilla.universalchardet.prober.MBCSGroupProber;
import org.mozilla.universalchardet.prober.SBCSGroupProber;

/* loaded from: classes7.dex */
public class UniversalDetector {
    public static final float MINIMUM_THRESHOLD = 0.2f;
    public static final float SHORTCUT_THRESHOLD = 0.95f;

    /* renamed from: ᇰ, reason: contains not printable characters */
    public boolean f22120;

    /* renamed from: ᝠ, reason: contains not printable characters */
    public CharsetListener f22121;

    /* renamed from: ᦜ, reason: contains not printable characters */
    public byte f22122;

    /* renamed from: 㡷, reason: contains not printable characters */
    public String f22125;

    /* renamed from: 㫞, reason: contains not printable characters */
    public InputState f22126;

    /* renamed from: 㫿, reason: contains not printable characters */
    public boolean f22127;

    /* renamed from: 㯿, reason: contains not printable characters */
    public boolean f22128;

    /* renamed from: 㛧, reason: contains not printable characters */
    public CharsetProber f22124 = null;

    /* renamed from: ⴄ, reason: contains not printable characters */
    public CharsetProber[] f22123 = new CharsetProber[3];

    /* loaded from: classes7.dex */
    public enum InputState {
        PURE_ASCII,
        ESC_ASCII,
        HIGHBYTE
    }

    /* renamed from: org.mozilla.universalchardet.UniversalDetector$㫞, reason: contains not printable characters */
    /* loaded from: classes7.dex */
    public static class C5298 implements CharsetListener {
        @Override // org.mozilla.universalchardet.CharsetListener
        public void report(String str) {
            System.out.println("charset = " + str);
        }
    }

    public UniversalDetector(CharsetListener charsetListener) {
        this.f22121 = charsetListener;
        int i = 0;
        while (true) {
            CharsetProber[] charsetProberArr = this.f22123;
            if (i < charsetProberArr.length) {
                charsetProberArr[i] = null;
                i++;
            } else {
                reset();
                return;
            }
        }
    }

    public static void main(String[] strArr) throws Exception {
        if (strArr.length != 1) {
            System.out.println("USAGE: java UniversalDetector filename");
            return;
        }
        UniversalDetector universalDetector = new UniversalDetector(new C5298());
        byte[] bArr = new byte[4096];
        FileInputStream fileInputStream = new FileInputStream(strArr[0]);
        while (true) {
            int read = fileInputStream.read(bArr);
            if (read <= 0 || universalDetector.isDone()) {
                break;
            } else {
                universalDetector.handleData(bArr, 0, read);
            }
        }
        universalDetector.dataEnd();
    }

    public void dataEnd() {
        CharsetProber[] charsetProberArr;
        if (!this.f22128) {
            return;
        }
        String str = this.f22125;
        if (str != null) {
            this.f22120 = true;
            CharsetListener charsetListener = this.f22121;
            if (charsetListener != null) {
                charsetListener.report(str);
                return;
            }
            return;
        }
        if (this.f22126 == InputState.HIGHBYTE) {
            float f = 0.0f;
            int i = 0;
            int i2 = 0;
            while (true) {
                charsetProberArr = this.f22123;
                if (i >= charsetProberArr.length) {
                    break;
                }
                float confidence = charsetProberArr[i].getConfidence();
                if (confidence > f) {
                    i2 = i;
                    f = confidence;
                }
                i++;
            }
            if (f > 0.2f) {
                String charSetName = charsetProberArr[i2].getCharSetName();
                this.f22125 = charSetName;
                CharsetListener charsetListener2 = this.f22121;
                if (charsetListener2 != null) {
                    charsetListener2.report(charSetName);
                    return;
                }
                return;
            }
            return;
        }
        InputState inputState = InputState.ESC_ASCII;
    }

    public String getDetectedCharset() {
        return this.f22125;
    }

    public CharsetListener getListener() {
        return this.f22121;
    }

    public void handleData(byte[] bArr, int i, int i2) {
        if (this.f22120) {
            return;
        }
        if (i2 > 0) {
            this.f22128 = true;
        }
        int i3 = 0;
        if (this.f22127) {
            this.f22127 = false;
            if (i2 > 3) {
                int i4 = bArr[i] & 255;
                int i5 = bArr[i + 1] & 255;
                int i6 = bArr[i + 2] & 255;
                int i7 = bArr[i + 3] & 255;
                if (i4 != 0) {
                    if (i4 != 239) {
                        if (i4 != 254) {
                            if (i4 == 255) {
                                if (i5 == 254 && i6 == 0 && i7 == 0) {
                                    this.f22125 = Constants.CHARSET_UTF_32LE;
                                } else if (i5 == 254) {
                                    this.f22125 = Constants.CHARSET_UTF_16LE;
                                }
                            }
                        } else if (i5 == 255 && i6 == 0 && i7 == 0) {
                            this.f22125 = Constants.CHARSET_X_ISO_10646_UCS_4_3412;
                        } else if (i5 == 255) {
                            this.f22125 = Constants.CHARSET_UTF_16BE;
                        }
                    } else if (i5 == 187 && i6 == 191) {
                        this.f22125 = Constants.CHARSET_UTF_8;
                    }
                } else if (i5 == 0 && i6 == 254 && i7 == 255) {
                    this.f22125 = Constants.CHARSET_UTF_32BE;
                } else if (i5 == 0 && i6 == 255 && i7 == 254) {
                    this.f22125 = Constants.CHARSET_X_ISO_10646_UCS_4_2143;
                }
                if (this.f22125 != null) {
                    this.f22120 = true;
                    return;
                }
            }
        }
        int i8 = i + i2;
        for (int i9 = i; i9 < i8; i9++) {
            byte b2 = bArr[i9];
            int i10 = b2 & 255;
            if ((i10 & 128) != 0 && i10 != 160) {
                InputState inputState = this.f22126;
                InputState inputState2 = InputState.HIGHBYTE;
                if (inputState != inputState2) {
                    this.f22126 = inputState2;
                    if (this.f22124 != null) {
                        this.f22124 = null;
                    }
                    CharsetProber[] charsetProberArr = this.f22123;
                    if (charsetProberArr[0] == null) {
                        charsetProberArr[0] = new MBCSGroupProber();
                    }
                    CharsetProber[] charsetProberArr2 = this.f22123;
                    if (charsetProberArr2[1] == null) {
                        charsetProberArr2[1] = new SBCSGroupProber();
                    }
                    CharsetProber[] charsetProberArr3 = this.f22123;
                    if (charsetProberArr3[2] == null) {
                        charsetProberArr3[2] = new Latin1Prober();
                    }
                }
            } else {
                if (this.f22126 == InputState.PURE_ASCII && (i10 == 27 || (i10 == 123 && this.f22122 == 126))) {
                    this.f22126 = InputState.ESC_ASCII;
                }
                this.f22122 = b2;
            }
        }
        InputState inputState3 = this.f22126;
        if (inputState3 == InputState.ESC_ASCII) {
            if (this.f22124 == null) {
                this.f22124 = new EscCharsetProber();
            }
            if (this.f22124.handleData(bArr, i, i2) == CharsetProber.ProbingState.FOUND_IT) {
                this.f22120 = true;
                this.f22125 = this.f22124.getCharSetName();
                return;
            }
            return;
        }
        if (inputState3 != InputState.HIGHBYTE) {
            return;
        }
        while (true) {
            CharsetProber[] charsetProberArr4 = this.f22123;
            if (i3 < charsetProberArr4.length) {
                if (charsetProberArr4[i3].handleData(bArr, i, i2) == CharsetProber.ProbingState.FOUND_IT) {
                    this.f22120 = true;
                    this.f22125 = this.f22123[i3].getCharSetName();
                    return;
                }
                i3++;
            } else {
                return;
            }
        }
    }

    public boolean isDone() {
        return this.f22120;
    }

    public void reset() {
        int i = 0;
        this.f22120 = false;
        this.f22127 = true;
        this.f22125 = null;
        this.f22128 = false;
        this.f22126 = InputState.PURE_ASCII;
        this.f22122 = (byte) 0;
        CharsetProber charsetProber = this.f22124;
        if (charsetProber != null) {
            charsetProber.reset();
        }
        while (true) {
            CharsetProber[] charsetProberArr = this.f22123;
            if (i < charsetProberArr.length) {
                CharsetProber charsetProber2 = charsetProberArr[i];
                if (charsetProber2 != null) {
                    charsetProber2.reset();
                }
                i++;
            } else {
                return;
            }
        }
    }

    public void setListener(CharsetListener charsetListener) {
        this.f22121 = charsetListener;
    }
}
