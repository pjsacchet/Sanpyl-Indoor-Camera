package org.mozilla.universalchardet;

/* loaded from: classes7.dex */
public interface CharsetListener {
    void report(String str);
}
