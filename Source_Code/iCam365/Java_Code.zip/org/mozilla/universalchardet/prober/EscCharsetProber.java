package org.mozilla.universalchardet.prober;

import org.mozilla.universalchardet.prober.CharsetProber;
import org.mozilla.universalchardet.prober.statemachine.CodingStateMachine;
import org.mozilla.universalchardet.prober.statemachine.HZSMModel;
import org.mozilla.universalchardet.prober.statemachine.ISO2022CNSMModel;
import org.mozilla.universalchardet.prober.statemachine.ISO2022JPSMModel;
import org.mozilla.universalchardet.prober.statemachine.ISO2022KRSMModel;

/* loaded from: classes7.dex */
public class EscCharsetProber extends CharsetProber {

    /* renamed from: ᇰ, reason: contains not printable characters */
    public int f22154;

    /* renamed from: 㫞, reason: contains not printable characters */
    public CodingStateMachine[] f22155;

    /* renamed from: 㫿, reason: contains not printable characters */
    public CharsetProber.ProbingState f22156;

    /* renamed from: 㯿, reason: contains not printable characters */
    public String f22157;

    /* renamed from: ᦜ, reason: contains not printable characters */
    public static final HZSMModel f22150 = new HZSMModel();

    /* renamed from: 㡷, reason: contains not printable characters */
    public static final ISO2022CNSMModel f22153 = new ISO2022CNSMModel();

    /* renamed from: ⴄ, reason: contains not printable characters */
    public static final ISO2022JPSMModel f22151 = new ISO2022JPSMModel();

    /* renamed from: 㛧, reason: contains not printable characters */
    public static final ISO2022KRSMModel f22152 = new ISO2022KRSMModel();

    public EscCharsetProber() {
        CodingStateMachine[] codingStateMachineArr = new CodingStateMachine[4];
        this.f22155 = codingStateMachineArr;
        codingStateMachineArr[0] = new CodingStateMachine(f22150);
        this.f22155[1] = new CodingStateMachine(f22153);
        this.f22155[2] = new CodingStateMachine(f22151);
        this.f22155[3] = new CodingStateMachine(f22152);
        reset();
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public String getCharSetName() {
        return this.f22157;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public float getConfidence() {
        return 0.99f;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState getState() {
        return this.f22156;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState handleData(byte[] bArr, int i, int i2) {
        int i3 = i2 + i;
        while (i < i3 && this.f22156 == CharsetProber.ProbingState.DETECTING) {
            for (int i4 = this.f22154 - 1; i4 >= 0; i4--) {
                int nextState = this.f22155[i4].nextState(bArr[i]);
                if (nextState == 1) {
                    int i5 = this.f22154 - 1;
                    this.f22154 = i5;
                    if (i5 <= 0) {
                        CharsetProber.ProbingState probingState = CharsetProber.ProbingState.NOT_ME;
                        this.f22156 = probingState;
                        return probingState;
                    }
                    if (i4 != i5) {
                        CodingStateMachine[] codingStateMachineArr = this.f22155;
                        CodingStateMachine codingStateMachine = codingStateMachineArr[i5];
                        codingStateMachineArr[i5] = codingStateMachineArr[i4];
                        codingStateMachineArr[i4] = codingStateMachine;
                    }
                } else if (nextState == 2) {
                    this.f22156 = CharsetProber.ProbingState.FOUND_IT;
                    this.f22157 = this.f22155[i4].getCodingStateMachine();
                    return this.f22156;
                }
            }
            i++;
        }
        return this.f22156;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void reset() {
        this.f22156 = CharsetProber.ProbingState.DETECTING;
        int i = 0;
        while (true) {
            CodingStateMachine[] codingStateMachineArr = this.f22155;
            if (i < codingStateMachineArr.length) {
                codingStateMachineArr[i].reset();
                i++;
            } else {
                this.f22154 = codingStateMachineArr.length;
                this.f22157 = null;
                return;
            }
        }
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void setOption() {
    }
}
