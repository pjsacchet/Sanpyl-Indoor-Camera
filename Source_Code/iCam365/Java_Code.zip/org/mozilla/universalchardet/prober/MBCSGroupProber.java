package org.mozilla.universalchardet.prober;

import org.mozilla.universalchardet.prober.CharsetProber;

/* loaded from: classes7.dex */
public class MBCSGroupProber extends CharsetProber {

    /* renamed from: ᇰ, reason: contains not printable characters */
    public CharsetProber[] f22174;

    /* renamed from: ᦜ, reason: contains not printable characters */
    public int f22175;

    /* renamed from: 㫞, reason: contains not printable characters */
    public CharsetProber.ProbingState f22176;

    /* renamed from: 㫿, reason: contains not printable characters */
    public boolean[] f22177 = new boolean[7];

    /* renamed from: 㯿, reason: contains not printable characters */
    public int f22178;

    public MBCSGroupProber() {
        CharsetProber[] charsetProberArr = new CharsetProber[7];
        this.f22174 = charsetProberArr;
        charsetProberArr[0] = new UTF8Prober();
        this.f22174[1] = new SJISProber();
        this.f22174[2] = new EUCJPProber();
        this.f22174[3] = new GB18030Prober();
        this.f22174[4] = new EUCKRProber();
        this.f22174[5] = new Big5Prober();
        this.f22174[6] = new EUCTWProber();
        reset();
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public String getCharSetName() {
        if (this.f22178 == -1) {
            getConfidence();
            if (this.f22178 == -1) {
                this.f22178 = 0;
            }
        }
        return this.f22174[this.f22178].getCharSetName();
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public float getConfidence() {
        CharsetProber.ProbingState probingState = this.f22176;
        if (probingState == CharsetProber.ProbingState.FOUND_IT) {
            return 0.99f;
        }
        if (probingState == CharsetProber.ProbingState.NOT_ME) {
            return 0.01f;
        }
        int i = 0;
        float f = 0.0f;
        while (true) {
            CharsetProber[] charsetProberArr = this.f22174;
            if (i < charsetProberArr.length) {
                if (this.f22177[i]) {
                    float confidence = charsetProberArr[i].getConfidence();
                    if (f < confidence) {
                        this.f22178 = i;
                        f = confidence;
                    }
                }
                i++;
            } else {
                return f;
            }
        }
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState getState() {
        return this.f22176;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState handleData(byte[] bArr, int i, int i2) {
        byte[] bArr2 = new byte[i2];
        int i3 = i2 + i;
        int i4 = 0;
        boolean z = true;
        while (i < i3) {
            byte b2 = bArr[i];
            if ((b2 & 128) != 0) {
                bArr2[i4] = b2;
                i4++;
                z = true;
            } else if (z) {
                bArr2[i4] = b2;
                i4++;
                z = false;
            }
            i++;
        }
        int i5 = 0;
        while (true) {
            CharsetProber[] charsetProberArr = this.f22174;
            if (i5 >= charsetProberArr.length) {
                break;
            }
            if (this.f22177[i5]) {
                CharsetProber.ProbingState handleData = charsetProberArr[i5].handleData(bArr2, 0, i4);
                CharsetProber.ProbingState probingState = CharsetProber.ProbingState.FOUND_IT;
                if (handleData == probingState) {
                    this.f22178 = i5;
                    this.f22176 = probingState;
                    break;
                }
                CharsetProber.ProbingState probingState2 = CharsetProber.ProbingState.NOT_ME;
                if (handleData == probingState2) {
                    this.f22177[i5] = false;
                    int i6 = this.f22175 - 1;
                    this.f22175 = i6;
                    if (i6 <= 0) {
                        this.f22176 = probingState2;
                        break;
                    }
                } else {
                    continue;
                }
            }
            i5++;
        }
        return this.f22176;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void reset() {
        int i = 0;
        this.f22175 = 0;
        while (true) {
            CharsetProber[] charsetProberArr = this.f22174;
            if (i < charsetProberArr.length) {
                charsetProberArr[i].reset();
                this.f22177[i] = true;
                this.f22175++;
                i++;
            } else {
                this.f22178 = -1;
                this.f22176 = CharsetProber.ProbingState.DETECTING;
                return;
            }
        }
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void setOption() {
    }
}
