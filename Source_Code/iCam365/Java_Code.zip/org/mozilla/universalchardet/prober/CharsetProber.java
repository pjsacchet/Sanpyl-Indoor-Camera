package org.mozilla.universalchardet.prober;

import java.nio.ByteBuffer;

/* loaded from: classes7.dex */
public abstract class CharsetProber {
    public static final int ASCII_A = 97;
    public static final int ASCII_A_CAPITAL = 65;
    public static final int ASCII_GT = 62;
    public static final int ASCII_LT = 60;
    public static final int ASCII_SP = 32;
    public static final int ASCII_Z = 122;
    public static final int ASCII_Z_CAPITAL = 90;
    public static final float SHORTCUT_THRESHOLD = 0.95f;

    /* loaded from: classes7.dex */
    public enum ProbingState {
        DETECTING,
        FOUND_IT,
        NOT_ME
    }

    public ByteBuffer filterWithEnglishLetters(byte[] bArr, int i, int i2) {
        ByteBuffer allocate = ByteBuffer.allocate(i2);
        int i3 = i2 + i;
        int i4 = i;
        boolean z = false;
        while (i < i3) {
            byte b2 = bArr[i];
            if (b2 == 62) {
                z = false;
            } else if (b2 == 60) {
                z = true;
            }
            if (m17614(b2) && m17613(b2)) {
                if (i > i4 && !z) {
                    allocate.put(bArr, i4, i - i4);
                    allocate.put((byte) 32);
                }
                i4 = i + 1;
            }
            i++;
        }
        if (!z && i > i4) {
            allocate.put(bArr, i4, i - i4);
        }
        return allocate;
    }

    public ByteBuffer filterWithoutEnglishLetters(byte[] bArr, int i, int i2) {
        ByteBuffer allocate = ByteBuffer.allocate(i2);
        int i3 = i2 + i;
        int i4 = i;
        boolean z = false;
        while (i < i3) {
            byte b2 = bArr[i];
            if (!m17614(b2)) {
                z = true;
            } else if (m17613(b2)) {
                if (z && i > i4) {
                    allocate.put(bArr, i4, i - i4);
                    allocate.put((byte) 32);
                    i4 = i + 1;
                    z = false;
                } else {
                    i4 = i + 1;
                }
            }
            i++;
        }
        if (z && i > i4) {
            allocate.put(bArr, i4, i - i4);
        }
        return allocate;
    }

    public abstract String getCharSetName();

    public abstract float getConfidence();

    public abstract ProbingState getState();

    public abstract ProbingState handleData(byte[] bArr, int i, int i2);

    public abstract void reset();

    public abstract void setOption();

    /* renamed from: ᇰ, reason: contains not printable characters */
    public final boolean m17613(byte b2) {
        int i = b2 & 255;
        return i < 65 || (i > 90 && i < 97) || i > 122;
    }

    /* renamed from: 㫞, reason: contains not printable characters */
    public final boolean m17614(byte b2) {
        return (b2 & 128) == 0;
    }
}
