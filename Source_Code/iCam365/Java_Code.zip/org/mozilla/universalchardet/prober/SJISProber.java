package org.mozilla.universalchardet.prober;

import java.util.Arrays;
import org.mozilla.universalchardet.Constants;
import org.mozilla.universalchardet.prober.CharsetProber;
import org.mozilla.universalchardet.prober.contextanalysis.SJISContextAnalysis;
import org.mozilla.universalchardet.prober.distributionanalysis.SJISDistributionAnalysis;
import org.mozilla.universalchardet.prober.statemachine.CodingStateMachine;
import org.mozilla.universalchardet.prober.statemachine.SJISSMModel;
import org.mozilla.universalchardet.prober.statemachine.SMModel;

/* loaded from: classes7.dex */
public class SJISProber extends CharsetProber {

    /* renamed from: 㡷, reason: contains not printable characters */
    public static final SMModel f22195 = new SJISSMModel();

    /* renamed from: ᇰ, reason: contains not printable characters */
    public CharsetProber.ProbingState f22196;

    /* renamed from: 㫞, reason: contains not printable characters */
    public CodingStateMachine f22198 = new CodingStateMachine(f22195);

    /* renamed from: 㫿, reason: contains not printable characters */
    public SJISContextAnalysis f22199 = new SJISContextAnalysis();

    /* renamed from: 㯿, reason: contains not printable characters */
    public SJISDistributionAnalysis f22200 = new SJISDistributionAnalysis();

    /* renamed from: ᦜ, reason: contains not printable characters */
    public byte[] f22197 = new byte[2];

    public SJISProber() {
        reset();
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public String getCharSetName() {
        return Constants.CHARSET_SHIFT_JIS;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public float getConfidence() {
        return Math.max(this.f22199.getConfidence(), this.f22200.getConfidence());
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState getState() {
        return this.f22196;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState handleData(byte[] bArr, int i, int i2) {
        int i3 = i2 + i;
        int i4 = i;
        while (true) {
            if (i4 >= i3) {
                break;
            }
            int nextState = this.f22198.nextState(bArr[i4]);
            if (nextState == 1) {
                this.f22196 = CharsetProber.ProbingState.NOT_ME;
                break;
            }
            if (nextState == 2) {
                this.f22196 = CharsetProber.ProbingState.FOUND_IT;
                break;
            }
            if (nextState == 0) {
                int currentCharLen = this.f22198.getCurrentCharLen();
                if (i4 == i) {
                    byte[] bArr2 = this.f22197;
                    bArr2[1] = bArr[i];
                    this.f22199.handleOneChar(bArr2, 2 - currentCharLen, currentCharLen);
                    this.f22200.handleOneChar(this.f22197, 0, currentCharLen);
                } else {
                    this.f22199.handleOneChar(bArr, (i4 + 1) - currentCharLen, currentCharLen);
                    this.f22200.handleOneChar(bArr, i4 - 1, currentCharLen);
                }
            }
            i4++;
        }
        this.f22197[0] = bArr[i3 - 1];
        if (this.f22196 == CharsetProber.ProbingState.DETECTING && this.f22199.gotEnoughData() && getConfidence() > 0.95f) {
            this.f22196 = CharsetProber.ProbingState.FOUND_IT;
        }
        return this.f22196;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void reset() {
        this.f22198.reset();
        this.f22196 = CharsetProber.ProbingState.DETECTING;
        this.f22199.reset();
        this.f22200.reset();
        Arrays.fill(this.f22197, (byte) 0);
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void setOption() {
    }
}
