package org.mozilla.universalchardet.prober;

import org.mozilla.universalchardet.Constants;
import org.mozilla.universalchardet.prober.CharsetProber;
import org.mozilla.universalchardet.prober.statemachine.CodingStateMachine;
import org.mozilla.universalchardet.prober.statemachine.SMModel;
import org.mozilla.universalchardet.prober.statemachine.UTF8SMModel;

/* loaded from: classes7.dex */
public class UTF8Prober extends CharsetProber {
    public static final float ONE_CHAR_PROB = 0.5f;

    /* renamed from: 㯿, reason: contains not printable characters */
    public static final SMModel f22210 = new UTF8SMModel();

    /* renamed from: ᇰ, reason: contains not printable characters */
    public CharsetProber.ProbingState f22211;

    /* renamed from: 㫿, reason: contains not printable characters */
    public int f22213 = 0;

    /* renamed from: 㫞, reason: contains not printable characters */
    public CodingStateMachine f22212 = new CodingStateMachine(f22210);

    public UTF8Prober() {
        reset();
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public String getCharSetName() {
        return Constants.CHARSET_UTF_8;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public float getConfidence() {
        float f = 0.99f;
        if (this.f22213 >= 6) {
            return 0.99f;
        }
        for (int i = 0; i < this.f22213; i++) {
            f *= 0.5f;
        }
        return 1.0f - f;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState getState() {
        return this.f22211;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState handleData(byte[] bArr, int i, int i2) {
        int i3 = i2 + i;
        while (true) {
            if (i >= i3) {
                break;
            }
            int nextState = this.f22212.nextState(bArr[i]);
            if (nextState == 1) {
                this.f22211 = CharsetProber.ProbingState.NOT_ME;
                break;
            }
            if (nextState == 2) {
                this.f22211 = CharsetProber.ProbingState.FOUND_IT;
                break;
            }
            if (nextState == 0 && this.f22212.getCurrentCharLen() >= 2) {
                this.f22213++;
            }
            i++;
        }
        if (this.f22211 == CharsetProber.ProbingState.DETECTING && getConfidence() > 0.95f) {
            this.f22211 = CharsetProber.ProbingState.FOUND_IT;
        }
        return this.f22211;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void reset() {
        this.f22212.reset();
        this.f22213 = 0;
        this.f22211 = CharsetProber.ProbingState.DETECTING;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void setOption() {
    }
}
