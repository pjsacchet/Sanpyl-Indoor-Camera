package org.mozilla.universalchardet.prober.statemachine;

/* loaded from: classes7.dex */
public class CodingStateMachine {
    public int currentBytePos;
    public int currentCharLen;
    public int currentState = 0;
    public SMModel model;

    public CodingStateMachine(SMModel sMModel) {
        this.model = sMModel;
    }

    public String getCodingStateMachine() {
        return this.model.getName();
    }

    public int getCurrentCharLen() {
        return this.currentCharLen;
    }

    public int nextState(byte b2) {
        int i = this.model.getClass(b2);
        if (this.currentState == 0) {
            this.currentBytePos = 0;
            this.currentCharLen = this.model.getCharLen(i);
        }
        int nextState = this.model.getNextState(i, this.currentState);
        this.currentState = nextState;
        this.currentBytePos++;
        return nextState;
    }

    public void reset() {
        this.currentState = 0;
    }
}
