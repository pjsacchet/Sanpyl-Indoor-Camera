package org.mozilla.universalchardet.prober.statemachine;

import org.mozilla.universalchardet.Constants;

/* loaded from: classes7.dex */
public class ISO2022JPSMModel extends SMModel {
    public static final int ISO2022JP_CLASS_FACTOR = 10;

    /* renamed from: 㫞, reason: contains not printable characters */
    public static int[] f22264 = {PkgInt.pack4bits(2, 0, 0, 0, 0, 0, 0, 0), PkgInt.pack4bits(0, 0, 0, 0, 0, 0, 2, 2), PkgInt.pack4bits(0, 0, 0, 0, 0, 0, 0, 0), PkgInt.pack4bits(0, 0, 0, 1, 0, 0, 0, 0), PkgInt.pack4bits(0, 0, 0, 0, 7, 0, 0, 0), PkgInt.pack4bits(3, 0, 0, 0, 0, 0, 0, 0), PkgInt.pack4bits(0, 0, 0, 0, 0, 0, 0, 0), PkgInt.pack4bits(0, 0, 0, 0, 0, 0, 0, 0), PkgInt.pack4bits(6, 0, 4, 0, 8, 0, 0, 0), PkgInt.pack4bits(0, 9, 5, 0, 0, 0, 0, 0), PkgInt.pack4bits(0, 0, 0, 0, 0, 0, 0, 0), PkgInt.pack4bits(0, 0, 0, 0, 0, 0, 0, 0), PkgInt.pack4bits(0, 0, 0, 0, 0, 0, 0, 0), PkgInt.pack4bits(0, 0, 0, 0, 0, 0, 0, 0), PkgInt.pack4bits(0, 0, 0, 0, 0, 0, 0, 0), PkgInt.pack4bits(0, 0, 0, 0, 0, 0, 0, 0), PkgInt.pack4bits(2, 2, 2, 2, 2, 2, 2, 2), PkgInt.pack4bits(2, 2, 2, 2, 2, 2, 2, 2), PkgInt.pack4bits(2, 2, 2, 2, 2, 2, 2, 2), PkgInt.pack4bits(2, 2, 2, 2, 2, 2, 2, 2), PkgInt.pack4bits(2, 2, 2, 2, 2, 2, 2, 2), PkgInt.pack4bits(2, 2, 2, 2, 2, 2, 2, 2), PkgInt.pack4bits(2, 2, 2, 2, 2, 2, 2, 2), PkgInt.pack4bits(2, 2, 2, 2, 2, 2, 2, 2), PkgInt.pack4bits(2, 2, 2, 2, 2, 2, 2, 2), PkgInt.pack4bits(2, 2, 2, 2, 2, 2, 2, 2), PkgInt.pack4bits(2, 2, 2, 2, 2, 2, 2, 2), PkgInt.pack4bits(2, 2, 2, 2, 2, 2, 2, 2), PkgInt.pack4bits(2, 2, 2, 2, 2, 2, 2, 2), PkgInt.pack4bits(2, 2, 2, 2, 2, 2, 2, 2), PkgInt.pack4bits(2, 2, 2, 2, 2, 2, 2, 2), PkgInt.pack4bits(2, 2, 2, 2, 2, 2, 2, 2)};

    /* renamed from: ᇰ, reason: contains not printable characters */
    public static int[] f22263 = {PkgInt.pack4bits(0, 3, 1, 0, 0, 0, 0, 0), PkgInt.pack4bits(0, 0, 1, 1, 1, 1, 1, 1), PkgInt.pack4bits(1, 1, 1, 1, 2, 2, 2, 2), PkgInt.pack4bits(2, 2, 2, 2, 2, 2, 1, 1), PkgInt.pack4bits(1, 5, 1, 1, 1, 4, 1, 1), PkgInt.pack4bits(1, 1, 1, 6, 2, 1, 2, 1), PkgInt.pack4bits(1, 1, 1, 1, 1, 1, 2, 2), PkgInt.pack4bits(1, 1, 1, 2, 1, 1, 1, 1), PkgInt.pack4bits(1, 1, 1, 1, 2, 1, 0, 0)};

    /* renamed from: 㫿, reason: contains not printable characters */
    public static int[] f22265 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    public ISO2022JPSMModel() {
        super(new PkgInt(3, 7, 2, 15, f22264), 10, new PkgInt(3, 7, 2, 15, f22263), f22265, Constants.CHARSET_ISO_2022_JP);
    }
}
