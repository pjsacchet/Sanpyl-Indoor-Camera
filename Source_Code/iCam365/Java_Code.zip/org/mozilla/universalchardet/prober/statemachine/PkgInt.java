package org.mozilla.universalchardet.prober.statemachine;

/* loaded from: classes7.dex */
public class PkgInt {
    public static final int BIT_SHIFT_16BITS = 4;
    public static final int BIT_SHIFT_4BITS = 2;
    public static final int BIT_SHIFT_8BITS = 3;
    public static final int INDEX_SHIFT_16BITS = 1;
    public static final int INDEX_SHIFT_4BITS = 3;
    public static final int INDEX_SHIFT_8BITS = 2;
    public static final int SHIFT_MASK_16BITS = 1;
    public static final int SHIFT_MASK_4BITS = 7;
    public static final int SHIFT_MASK_8BITS = 3;
    public static final int UNIT_MASK_16BITS = 65535;
    public static final int UNIT_MASK_4BITS = 15;
    public static final int UNIT_MASK_8BITS = 255;

    /* renamed from: ᇰ, reason: contains not printable characters */
    public int f22269;

    /* renamed from: ᦜ, reason: contains not printable characters */
    public int[] f22270;

    /* renamed from: 㫞, reason: contains not printable characters */
    public int f22271;

    /* renamed from: 㫿, reason: contains not printable characters */
    public int f22272;

    /* renamed from: 㯿, reason: contains not printable characters */
    public int f22273;

    public PkgInt(int i, int i2, int i3, int i4, int[] iArr) {
        this.f22271 = i;
        this.f22269 = i2;
        this.f22272 = i3;
        this.f22273 = i4;
        this.f22270 = iArr;
    }

    public static int pack16bits(int i, int i2) {
        return i | (i2 << 16);
    }

    public static int pack4bits(int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
        return pack8bits(i | (i2 << 4), (i4 << 4) | i3, (i6 << 4) | i5, (i8 << 4) | i7);
    }

    public static int pack8bits(int i, int i2, int i3, int i4) {
        return pack16bits(i | (i2 << 8), (i4 << 8) | i3);
    }

    public int unpack(int i) {
        return (this.f22270[i >> this.f22271] >> ((i & this.f22269) << this.f22272)) & this.f22273;
    }
}
