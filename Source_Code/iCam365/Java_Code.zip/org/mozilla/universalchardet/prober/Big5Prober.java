package org.mozilla.universalchardet.prober;

import java.util.Arrays;
import org.mozilla.universalchardet.Constants;
import org.mozilla.universalchardet.prober.CharsetProber;
import org.mozilla.universalchardet.prober.distributionanalysis.Big5DistributionAnalysis;
import org.mozilla.universalchardet.prober.statemachine.Big5SMModel;
import org.mozilla.universalchardet.prober.statemachine.CodingStateMachine;
import org.mozilla.universalchardet.prober.statemachine.SMModel;

/* loaded from: classes7.dex */
public class Big5Prober extends CharsetProber {

    /* renamed from: ᦜ, reason: contains not printable characters */
    public static final SMModel f22129 = new Big5SMModel();

    /* renamed from: ᇰ, reason: contains not printable characters */
    public CharsetProber.ProbingState f22130;

    /* renamed from: 㫞, reason: contains not printable characters */
    public CodingStateMachine f22131 = new CodingStateMachine(f22129);

    /* renamed from: 㫿, reason: contains not printable characters */
    public Big5DistributionAnalysis f22132 = new Big5DistributionAnalysis();

    /* renamed from: 㯿, reason: contains not printable characters */
    public byte[] f22133 = new byte[2];

    public Big5Prober() {
        reset();
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public String getCharSetName() {
        return Constants.CHARSET_BIG5;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public float getConfidence() {
        return this.f22132.getConfidence();
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState getState() {
        return this.f22130;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState handleData(byte[] bArr, int i, int i2) {
        int i3 = i2 + i;
        int i4 = i;
        while (true) {
            if (i4 >= i3) {
                break;
            }
            int nextState = this.f22131.nextState(bArr[i4]);
            if (nextState == 1) {
                this.f22130 = CharsetProber.ProbingState.NOT_ME;
                break;
            }
            if (nextState == 2) {
                this.f22130 = CharsetProber.ProbingState.FOUND_IT;
                break;
            }
            if (nextState == 0) {
                int currentCharLen = this.f22131.getCurrentCharLen();
                if (i4 == i) {
                    byte[] bArr2 = this.f22133;
                    bArr2[1] = bArr[i];
                    this.f22132.handleOneChar(bArr2, 0, currentCharLen);
                } else {
                    this.f22132.handleOneChar(bArr, i4 - 1, currentCharLen);
                }
            }
            i4++;
        }
        this.f22133[0] = bArr[i3 - 1];
        if (this.f22130 == CharsetProber.ProbingState.DETECTING && this.f22132.gotEnoughData() && getConfidence() > 0.95f) {
            this.f22130 = CharsetProber.ProbingState.FOUND_IT;
        }
        return this.f22130;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void reset() {
        this.f22131.reset();
        this.f22130 = CharsetProber.ProbingState.DETECTING;
        this.f22132.reset();
        Arrays.fill(this.f22133, (byte) 0);
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void setOption() {
    }
}
