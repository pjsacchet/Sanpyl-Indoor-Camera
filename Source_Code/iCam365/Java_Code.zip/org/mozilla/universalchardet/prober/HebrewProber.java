package org.mozilla.universalchardet.prober;

import org.mozilla.universalchardet.Constants;
import org.mozilla.universalchardet.prober.CharsetProber;

/* loaded from: classes7.dex */
public class HebrewProber extends CharsetProber {
    public static final int FINAL_KAF = 234;
    public static final int FINAL_MEM = 237;
    public static final int FINAL_NUN = 239;
    public static final int FINAL_PE = 243;
    public static final int FINAL_TSADI = 245;
    public static final int MIN_FINAL_CHAR_DISTANCE = 5;
    public static final float MIN_MODEL_DISTANCE = 0.01f;
    public static final int NORMAL_KAF = 235;
    public static final int NORMAL_MEM = 238;
    public static final int NORMAL_NUN = 240;
    public static final int NORMAL_PE = 244;
    public static final int NORMAL_TSADI = 246;
    public static final byte SPACE = 32;

    /* renamed from: ᇰ, reason: contains not printable characters */
    public int f22163;

    /* renamed from: ᦜ, reason: contains not printable characters */
    public CharsetProber f22164 = null;

    /* renamed from: 㡷, reason: contains not printable characters */
    public CharsetProber f22165 = null;

    /* renamed from: 㫞, reason: contains not printable characters */
    public int f22166;

    /* renamed from: 㫿, reason: contains not printable characters */
    public byte f22167;

    /* renamed from: 㯿, reason: contains not printable characters */
    public byte f22168;

    public HebrewProber() {
        reset();
    }

    public static boolean isFinal(byte b2) {
        int i = b2 & 255;
        return i == 234 || i == 237 || i == 239 || i == 243 || i == 245;
    }

    public static boolean isNonFinal(byte b2) {
        int i = b2 & 255;
        return i == 235 || i == 238 || i == 240 || i == 244;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public String getCharSetName() {
        int i = this.f22166 - this.f22163;
        if (i >= 5) {
            return Constants.CHARSET_WINDOWS_1255;
        }
        if (i <= -5) {
            return Constants.CHARSET_ISO_8859_8;
        }
        float confidence = this.f22164.getConfidence() - this.f22165.getConfidence();
        if (confidence > 0.01f) {
            return Constants.CHARSET_WINDOWS_1255;
        }
        if (confidence < -0.01f) {
            return Constants.CHARSET_ISO_8859_8;
        }
        if (i < 0) {
            return Constants.CHARSET_ISO_8859_8;
        }
        return Constants.CHARSET_WINDOWS_1255;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public float getConfidence() {
        return 0.0f;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState getState() {
        CharsetProber.ProbingState state = this.f22164.getState();
        CharsetProber.ProbingState probingState = CharsetProber.ProbingState.NOT_ME;
        if (state == probingState && this.f22165.getState() == probingState) {
            return probingState;
        }
        return CharsetProber.ProbingState.DETECTING;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState handleData(byte[] bArr, int i, int i2) {
        CharsetProber.ProbingState state = getState();
        CharsetProber.ProbingState probingState = CharsetProber.ProbingState.NOT_ME;
        if (state == probingState) {
            return probingState;
        }
        int i3 = i2 + i;
        while (i < i3) {
            byte b2 = bArr[i];
            if (b2 == 32) {
                if (this.f22168 != 32) {
                    if (isFinal(this.f22167)) {
                        this.f22166++;
                    } else if (isNonFinal(this.f22167)) {
                        this.f22163++;
                    }
                }
            } else if (this.f22168 == 32 && isFinal(this.f22167) && b2 != 32) {
                this.f22163++;
            }
            this.f22168 = this.f22167;
            this.f22167 = b2;
            i++;
        }
        return CharsetProber.ProbingState.DETECTING;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void reset() {
        this.f22166 = 0;
        this.f22163 = 0;
        this.f22167 = (byte) 32;
        this.f22168 = (byte) 32;
    }

    public void setModalProbers(CharsetProber charsetProber, CharsetProber charsetProber2) {
        this.f22164 = charsetProber;
        this.f22165 = charsetProber2;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void setOption() {
    }
}
