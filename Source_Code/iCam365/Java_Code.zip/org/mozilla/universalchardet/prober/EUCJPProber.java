package org.mozilla.universalchardet.prober;

import java.util.Arrays;
import org.mozilla.universalchardet.Constants;
import org.mozilla.universalchardet.prober.CharsetProber;
import org.mozilla.universalchardet.prober.contextanalysis.EUCJPContextAnalysis;
import org.mozilla.universalchardet.prober.distributionanalysis.EUCJPDistributionAnalysis;
import org.mozilla.universalchardet.prober.statemachine.CodingStateMachine;
import org.mozilla.universalchardet.prober.statemachine.EUCJPSMModel;
import org.mozilla.universalchardet.prober.statemachine.SMModel;

/* loaded from: classes7.dex */
public class EUCJPProber extends CharsetProber {

    /* renamed from: 㡷, reason: contains not printable characters */
    public static final SMModel f22134 = new EUCJPSMModel();

    /* renamed from: ᇰ, reason: contains not printable characters */
    public CharsetProber.ProbingState f22135;

    /* renamed from: 㫞, reason: contains not printable characters */
    public CodingStateMachine f22137 = new CodingStateMachine(f22134);

    /* renamed from: 㫿, reason: contains not printable characters */
    public EUCJPContextAnalysis f22138 = new EUCJPContextAnalysis();

    /* renamed from: 㯿, reason: contains not printable characters */
    public EUCJPDistributionAnalysis f22139 = new EUCJPDistributionAnalysis();

    /* renamed from: ᦜ, reason: contains not printable characters */
    public byte[] f22136 = new byte[2];

    public EUCJPProber() {
        reset();
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public String getCharSetName() {
        return Constants.CHARSET_EUC_JP;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public float getConfidence() {
        return Math.max(this.f22138.getConfidence(), this.f22139.getConfidence());
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState getState() {
        return this.f22135;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState handleData(byte[] bArr, int i, int i2) {
        int i3 = i2 + i;
        int i4 = i;
        while (true) {
            if (i4 >= i3) {
                break;
            }
            int nextState = this.f22137.nextState(bArr[i4]);
            if (nextState == 1) {
                this.f22135 = CharsetProber.ProbingState.NOT_ME;
                break;
            }
            if (nextState == 2) {
                this.f22135 = CharsetProber.ProbingState.FOUND_IT;
                break;
            }
            if (nextState == 0) {
                int currentCharLen = this.f22137.getCurrentCharLen();
                if (i4 == i) {
                    byte[] bArr2 = this.f22136;
                    bArr2[1] = bArr[i];
                    this.f22138.handleOneChar(bArr2, 0, currentCharLen);
                    this.f22139.handleOneChar(this.f22136, 0, currentCharLen);
                } else {
                    int i5 = i4 - 1;
                    this.f22138.handleOneChar(bArr, i5, currentCharLen);
                    this.f22139.handleOneChar(bArr, i5, currentCharLen);
                }
            }
            i4++;
        }
        this.f22136[0] = bArr[i3 - 1];
        if (this.f22135 == CharsetProber.ProbingState.DETECTING && this.f22138.gotEnoughData() && getConfidence() > 0.95f) {
            this.f22135 = CharsetProber.ProbingState.FOUND_IT;
        }
        return this.f22135;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void reset() {
        this.f22137.reset();
        this.f22135 = CharsetProber.ProbingState.DETECTING;
        this.f22138.reset();
        this.f22139.reset();
        Arrays.fill(this.f22136, (byte) 0);
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void setOption() {
    }
}
