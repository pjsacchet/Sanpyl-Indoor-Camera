package org.mozilla.universalchardet.prober;

import java.nio.ByteBuffer;
import org.mozilla.universalchardet.prober.CharsetProber;
import org.mozilla.universalchardet.prober.sequence.HebrewModel;
import org.mozilla.universalchardet.prober.sequence.Ibm855Model;
import org.mozilla.universalchardet.prober.sequence.Ibm866Model;
import org.mozilla.universalchardet.prober.sequence.Koi8rModel;
import org.mozilla.universalchardet.prober.sequence.Latin5BulgarianModel;
import org.mozilla.universalchardet.prober.sequence.Latin5Model;
import org.mozilla.universalchardet.prober.sequence.Latin7Model;
import org.mozilla.universalchardet.prober.sequence.MacCyrillicModel;
import org.mozilla.universalchardet.prober.sequence.SequenceModel;
import org.mozilla.universalchardet.prober.sequence.Win1251BulgarianModel;
import org.mozilla.universalchardet.prober.sequence.Win1251Model;
import org.mozilla.universalchardet.prober.sequence.Win1253Model;

/* loaded from: classes7.dex */
public class SBCSGroupProber extends CharsetProber {

    /* renamed from: ᇰ, reason: contains not printable characters */
    public CharsetProber[] f22190;

    /* renamed from: ᦜ, reason: contains not printable characters */
    public int f22191;

    /* renamed from: 㫞, reason: contains not printable characters */
    public CharsetProber.ProbingState f22192;

    /* renamed from: 㫿, reason: contains not printable characters */
    public boolean[] f22193 = new boolean[13];

    /* renamed from: 㯿, reason: contains not printable characters */
    public int f22194;

    /* renamed from: 㡷, reason: contains not printable characters */
    public static final SequenceModel f22187 = new Win1251Model();

    /* renamed from: ⴄ, reason: contains not printable characters */
    public static final SequenceModel f22184 = new Koi8rModel();

    /* renamed from: 㛧, reason: contains not printable characters */
    public static final SequenceModel f22186 = new Latin5Model();

    /* renamed from: ᝠ, reason: contains not printable characters */
    public static final SequenceModel f22181 = new MacCyrillicModel();

    /* renamed from: થ, reason: contains not printable characters */
    public static final SequenceModel f22179 = new Ibm866Model();

    /* renamed from: ᵻ, reason: contains not printable characters */
    public static final SequenceModel f22182 = new Ibm855Model();

    /* renamed from: 㼬, reason: contains not printable characters */
    public static final SequenceModel f22189 = new Latin7Model();

    /* renamed from: 㳏, reason: contains not printable characters */
    public static final SequenceModel f22188 = new Win1253Model();

    /* renamed from: ᕾ, reason: contains not printable characters */
    public static final SequenceModel f22180 = new Latin5BulgarianModel();

    /* renamed from: ⶂ, reason: contains not printable characters */
    public static final SequenceModel f22185 = new Win1251BulgarianModel();

    /* renamed from: Ⲵ, reason: contains not printable characters */
    public static final SequenceModel f22183 = new HebrewModel();

    public SBCSGroupProber() {
        CharsetProber[] charsetProberArr = new CharsetProber[13];
        this.f22190 = charsetProberArr;
        charsetProberArr[0] = new SingleByteCharsetProber(f22187);
        this.f22190[1] = new SingleByteCharsetProber(f22184);
        this.f22190[2] = new SingleByteCharsetProber(f22186);
        this.f22190[3] = new SingleByteCharsetProber(f22181);
        this.f22190[4] = new SingleByteCharsetProber(f22179);
        this.f22190[5] = new SingleByteCharsetProber(f22182);
        this.f22190[6] = new SingleByteCharsetProber(f22189);
        this.f22190[7] = new SingleByteCharsetProber(f22188);
        this.f22190[8] = new SingleByteCharsetProber(f22180);
        this.f22190[9] = new SingleByteCharsetProber(f22185);
        HebrewProber hebrewProber = new HebrewProber();
        CharsetProber[] charsetProberArr2 = this.f22190;
        charsetProberArr2[10] = hebrewProber;
        SequenceModel sequenceModel = f22183;
        charsetProberArr2[11] = new SingleByteCharsetProber(sequenceModel, false, hebrewProber);
        this.f22190[12] = new SingleByteCharsetProber(sequenceModel, true, hebrewProber);
        CharsetProber[] charsetProberArr3 = this.f22190;
        hebrewProber.setModalProbers(charsetProberArr3[11], charsetProberArr3[12]);
        reset();
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public String getCharSetName() {
        if (this.f22194 == -1) {
            getConfidence();
            if (this.f22194 == -1) {
                this.f22194 = 0;
            }
        }
        return this.f22190[this.f22194].getCharSetName();
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public float getConfidence() {
        CharsetProber.ProbingState probingState = this.f22192;
        if (probingState == CharsetProber.ProbingState.FOUND_IT) {
            return 0.99f;
        }
        if (probingState == CharsetProber.ProbingState.NOT_ME) {
            return 0.01f;
        }
        int i = 0;
        float f = 0.0f;
        while (true) {
            CharsetProber[] charsetProberArr = this.f22190;
            if (i < charsetProberArr.length) {
                if (this.f22193[i]) {
                    float confidence = charsetProberArr[i].getConfidence();
                    if (f < confidence) {
                        this.f22194 = i;
                        f = confidence;
                    }
                }
                i++;
            } else {
                return f;
            }
        }
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState getState() {
        return this.f22192;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState handleData(byte[] bArr, int i, int i2) {
        ByteBuffer filterWithoutEnglishLetters = filterWithoutEnglishLetters(bArr, i, i2);
        if (filterWithoutEnglishLetters.position() != 0) {
            int i3 = 0;
            while (true) {
                CharsetProber[] charsetProberArr = this.f22190;
                if (i3 >= charsetProberArr.length) {
                    break;
                }
                if (this.f22193[i3]) {
                    CharsetProber.ProbingState handleData = charsetProberArr[i3].handleData(filterWithoutEnglishLetters.array(), 0, filterWithoutEnglishLetters.position());
                    CharsetProber.ProbingState probingState = CharsetProber.ProbingState.FOUND_IT;
                    if (handleData == probingState) {
                        this.f22194 = i3;
                        this.f22192 = probingState;
                        break;
                    }
                    CharsetProber.ProbingState probingState2 = CharsetProber.ProbingState.NOT_ME;
                    if (handleData == probingState2) {
                        this.f22193[i3] = false;
                        int i4 = this.f22191 - 1;
                        this.f22191 = i4;
                        if (i4 <= 0) {
                            this.f22192 = probingState2;
                            break;
                        }
                    } else {
                        continue;
                    }
                }
                i3++;
            }
        }
        return this.f22192;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void reset() {
        int i = 0;
        this.f22191 = 0;
        while (true) {
            CharsetProber[] charsetProberArr = this.f22190;
            if (i < charsetProberArr.length) {
                charsetProberArr[i].reset();
                this.f22193[i] = true;
                this.f22191++;
                i++;
            } else {
                this.f22194 = -1;
                this.f22192 = CharsetProber.ProbingState.DETECTING;
                return;
            }
        }
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void setOption() {
    }
}
