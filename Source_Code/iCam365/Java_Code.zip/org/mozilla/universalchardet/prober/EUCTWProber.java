package org.mozilla.universalchardet.prober;

import java.util.Arrays;
import org.mozilla.universalchardet.Constants;
import org.mozilla.universalchardet.prober.CharsetProber;
import org.mozilla.universalchardet.prober.distributionanalysis.EUCTWDistributionAnalysis;
import org.mozilla.universalchardet.prober.statemachine.CodingStateMachine;
import org.mozilla.universalchardet.prober.statemachine.EUCTWSMModel;
import org.mozilla.universalchardet.prober.statemachine.SMModel;

/* loaded from: classes7.dex */
public class EUCTWProber extends CharsetProber {

    /* renamed from: ᦜ, reason: contains not printable characters */
    public static final SMModel f22145 = new EUCTWSMModel();

    /* renamed from: ᇰ, reason: contains not printable characters */
    public CharsetProber.ProbingState f22146;

    /* renamed from: 㫞, reason: contains not printable characters */
    public CodingStateMachine f22147 = new CodingStateMachine(f22145);

    /* renamed from: 㫿, reason: contains not printable characters */
    public EUCTWDistributionAnalysis f22148 = new EUCTWDistributionAnalysis();

    /* renamed from: 㯿, reason: contains not printable characters */
    public byte[] f22149 = new byte[2];

    public EUCTWProber() {
        reset();
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public String getCharSetName() {
        return Constants.CHARSET_EUC_TW;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public float getConfidence() {
        return this.f22148.getConfidence();
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState getState() {
        return this.f22146;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState handleData(byte[] bArr, int i, int i2) {
        int i3 = i2 + i;
        int i4 = i;
        while (true) {
            if (i4 >= i3) {
                break;
            }
            int nextState = this.f22147.nextState(bArr[i4]);
            if (nextState == 1) {
                this.f22146 = CharsetProber.ProbingState.NOT_ME;
                break;
            }
            if (nextState == 2) {
                this.f22146 = CharsetProber.ProbingState.FOUND_IT;
                break;
            }
            if (nextState == 0) {
                int currentCharLen = this.f22147.getCurrentCharLen();
                if (i4 == i) {
                    byte[] bArr2 = this.f22149;
                    bArr2[1] = bArr[i];
                    this.f22148.handleOneChar(bArr2, 0, currentCharLen);
                } else {
                    this.f22148.handleOneChar(bArr, i4 - 1, currentCharLen);
                }
            }
            i4++;
        }
        this.f22149[0] = bArr[i3 - 1];
        if (this.f22146 == CharsetProber.ProbingState.DETECTING && this.f22148.gotEnoughData() && getConfidence() > 0.95f) {
            this.f22146 = CharsetProber.ProbingState.FOUND_IT;
        }
        return this.f22146;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void reset() {
        this.f22147.reset();
        this.f22146 = CharsetProber.ProbingState.DETECTING;
        this.f22148.reset();
        Arrays.fill(this.f22149, (byte) 0);
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void setOption() {
    }
}
