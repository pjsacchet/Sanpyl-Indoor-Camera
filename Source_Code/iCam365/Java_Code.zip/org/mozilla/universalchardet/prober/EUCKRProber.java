package org.mozilla.universalchardet.prober;

import java.util.Arrays;
import org.mozilla.universalchardet.Constants;
import org.mozilla.universalchardet.prober.CharsetProber;
import org.mozilla.universalchardet.prober.distributionanalysis.EUCKRDistributionAnalysis;
import org.mozilla.universalchardet.prober.statemachine.CodingStateMachine;
import org.mozilla.universalchardet.prober.statemachine.EUCKRSMModel;
import org.mozilla.universalchardet.prober.statemachine.SMModel;

/* loaded from: classes7.dex */
public class EUCKRProber extends CharsetProber {

    /* renamed from: ᦜ, reason: contains not printable characters */
    public static final SMModel f22140 = new EUCKRSMModel();

    /* renamed from: ᇰ, reason: contains not printable characters */
    public CharsetProber.ProbingState f22141;

    /* renamed from: 㫞, reason: contains not printable characters */
    public CodingStateMachine f22142 = new CodingStateMachine(f22140);

    /* renamed from: 㫿, reason: contains not printable characters */
    public EUCKRDistributionAnalysis f22143 = new EUCKRDistributionAnalysis();

    /* renamed from: 㯿, reason: contains not printable characters */
    public byte[] f22144 = new byte[2];

    public EUCKRProber() {
        reset();
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public String getCharSetName() {
        return Constants.CHARSET_EUC_KR;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public float getConfidence() {
        return this.f22143.getConfidence();
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState getState() {
        return this.f22141;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState handleData(byte[] bArr, int i, int i2) {
        int i3 = i2 + i;
        int i4 = i;
        while (true) {
            if (i4 >= i3) {
                break;
            }
            int nextState = this.f22142.nextState(bArr[i4]);
            if (nextState == 1) {
                this.f22141 = CharsetProber.ProbingState.NOT_ME;
                break;
            }
            if (nextState == 2) {
                this.f22141 = CharsetProber.ProbingState.FOUND_IT;
                break;
            }
            if (nextState == 0) {
                int currentCharLen = this.f22142.getCurrentCharLen();
                if (i4 == i) {
                    byte[] bArr2 = this.f22144;
                    bArr2[1] = bArr[i];
                    this.f22143.handleOneChar(bArr2, 0, currentCharLen);
                } else {
                    this.f22143.handleOneChar(bArr, i4 - 1, currentCharLen);
                }
            }
            i4++;
        }
        this.f22144[0] = bArr[i3 - 1];
        if (this.f22141 == CharsetProber.ProbingState.DETECTING && this.f22143.gotEnoughData() && getConfidence() > 0.95f) {
            this.f22141 = CharsetProber.ProbingState.FOUND_IT;
        }
        return this.f22141;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void reset() {
        this.f22142.reset();
        this.f22141 = CharsetProber.ProbingState.DETECTING;
        this.f22143.reset();
        Arrays.fill(this.f22144, (byte) 0);
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void setOption() {
    }
}
