package org.mozilla.universalchardet.prober;

import java.util.Arrays;
import org.mozilla.universalchardet.Constants;
import org.mozilla.universalchardet.prober.CharsetProber;
import org.mozilla.universalchardet.prober.distributionanalysis.GB2312DistributionAnalysis;
import org.mozilla.universalchardet.prober.statemachine.CodingStateMachine;
import org.mozilla.universalchardet.prober.statemachine.GB18030SMModel;
import org.mozilla.universalchardet.prober.statemachine.SMModel;

/* loaded from: classes7.dex */
public class GB18030Prober extends CharsetProber {

    /* renamed from: ᦜ, reason: contains not printable characters */
    public static final SMModel f22158 = new GB18030SMModel();

    /* renamed from: ᇰ, reason: contains not printable characters */
    public CharsetProber.ProbingState f22159;

    /* renamed from: 㫞, reason: contains not printable characters */
    public CodingStateMachine f22160 = new CodingStateMachine(f22158);

    /* renamed from: 㫿, reason: contains not printable characters */
    public GB2312DistributionAnalysis f22161 = new GB2312DistributionAnalysis();

    /* renamed from: 㯿, reason: contains not printable characters */
    public byte[] f22162 = new byte[2];

    public GB18030Prober() {
        reset();
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public String getCharSetName() {
        return Constants.CHARSET_GB18030;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public float getConfidence() {
        return this.f22161.getConfidence();
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState getState() {
        return this.f22159;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState handleData(byte[] bArr, int i, int i2) {
        int i3 = i2 + i;
        int i4 = i;
        while (true) {
            if (i4 >= i3) {
                break;
            }
            int nextState = this.f22160.nextState(bArr[i4]);
            if (nextState == 1) {
                this.f22159 = CharsetProber.ProbingState.NOT_ME;
                break;
            }
            if (nextState == 2) {
                this.f22159 = CharsetProber.ProbingState.FOUND_IT;
                break;
            }
            if (nextState == 0) {
                int currentCharLen = this.f22160.getCurrentCharLen();
                if (i4 == i) {
                    byte[] bArr2 = this.f22162;
                    bArr2[1] = bArr[i];
                    this.f22161.handleOneChar(bArr2, 0, currentCharLen);
                } else {
                    this.f22161.handleOneChar(bArr, i4 - 1, currentCharLen);
                }
            }
            i4++;
        }
        this.f22162[0] = bArr[i3 - 1];
        if (this.f22159 == CharsetProber.ProbingState.DETECTING && this.f22161.gotEnoughData() && getConfidence() > 0.95f) {
            this.f22159 = CharsetProber.ProbingState.FOUND_IT;
        }
        return this.f22159;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void reset() {
        this.f22160.reset();
        this.f22159 = CharsetProber.ProbingState.DETECTING;
        this.f22161.reset();
        Arrays.fill(this.f22162, (byte) 0);
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void setOption() {
    }
}
