package org.mozilla.universalchardet.prober.distributionanalysis;

/* loaded from: classes7.dex */
public abstract class CharDistributionAnalysis {
    public static final int ENOUGH_DATA_THRESHOLD = 1024;
    public static final int MINIMUM_DATA_THRESHOLD = 4;
    public static final float SURE_NO = 0.01f;
    public static final float SURE_YES = 0.99f;
    public int[] charToFreqOrder;
    public boolean done;
    public float typicalDistributionRatio;

    /* renamed from: ᇰ, reason: contains not printable characters */
    public int f22221;

    /* renamed from: 㫞, reason: contains not printable characters */
    public int f22222;

    public CharDistributionAnalysis() {
        reset();
    }

    public float getConfidence() {
        int i;
        int i2 = this.f22221;
        if (i2 > 0 && (i = this.f22222) > 4) {
            if (i2 != i) {
                float f = (i / (i2 - i)) * this.typicalDistributionRatio;
                if (f < 0.99f) {
                    return f;
                }
            }
            return 0.99f;
        }
        return 0.01f;
    }

    public abstract int getOrder(byte[] bArr, int i);

    public boolean gotEnoughData() {
        return this.f22221 > 1024;
    }

    public void handleData(byte[] bArr, int i, int i2) {
    }

    public void handleOneChar(byte[] bArr, int i, int i2) {
        int i3;
        if (i2 == 2) {
            i3 = getOrder(bArr, i);
        } else {
            i3 = -1;
        }
        if (i3 >= 0) {
            this.f22221++;
            int[] iArr = this.charToFreqOrder;
            if (i3 < iArr.length && 512 > iArr[i3]) {
                this.f22222++;
            }
        }
    }

    public void reset() {
        this.done = false;
        this.f22221 = 0;
        this.f22222 = 0;
    }

    public void setOption() {
    }
}
