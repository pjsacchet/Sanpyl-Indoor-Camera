package org.mozilla.universalchardet.prober;

import org.mozilla.universalchardet.prober.CharsetProber;
import org.mozilla.universalchardet.prober.sequence.SequenceModel;

/* loaded from: classes7.dex */
public class SingleByteCharsetProber extends CharsetProber {
    public static final int NEGATIVE_CAT = 0;
    public static final float NEGATIVE_SHORTCUT_THRESHOLD = 0.05f;
    public static final int NUMBER_OF_SEQ_CAT = 4;
    public static final int POSITIVE_CAT = 3;
    public static final float POSITIVE_SHORTCUT_THRESHOLD = 0.95f;
    public static final int SAMPLE_SIZE = 64;
    public static final int SB_ENOUGH_REL_THRESHOLD = 1024;
    public static final int SYMBOL_CAT_ORDER = 250;

    /* renamed from: ᇰ, reason: contains not printable characters */
    public SequenceModel f22201;

    /* renamed from: ᝠ, reason: contains not printable characters */
    public CharsetProber f22202;

    /* renamed from: ᦜ, reason: contains not printable characters */
    public int f22203;

    /* renamed from: ⴄ, reason: contains not printable characters */
    public int f22204;

    /* renamed from: 㛧, reason: contains not printable characters */
    public int f22205;

    /* renamed from: 㡷, reason: contains not printable characters */
    public int[] f22206;

    /* renamed from: 㫞, reason: contains not printable characters */
    public CharsetProber.ProbingState f22207;

    /* renamed from: 㫿, reason: contains not printable characters */
    public boolean f22208;

    /* renamed from: 㯿, reason: contains not printable characters */
    public short f22209;

    public SingleByteCharsetProber(SequenceModel sequenceModel) {
        this.f22201 = sequenceModel;
        this.f22208 = false;
        this.f22202 = null;
        this.f22206 = new int[4];
        reset();
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public String getCharSetName() {
        CharsetProber charsetProber = this.f22202;
        if (charsetProber == null) {
            return this.f22201.getCharsetName();
        }
        return charsetProber.getCharSetName();
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public float getConfidence() {
        int i = this.f22203;
        if (i > 0) {
            float typicalPositiveRatio = ((((this.f22206[3] * 1.0f) / i) / this.f22201.getTypicalPositiveRatio()) * this.f22205) / this.f22204;
            if (typicalPositiveRatio >= 1.0f) {
                return 0.99f;
            }
            return typicalPositiveRatio;
        }
        return 0.01f;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState getState() {
        return this.f22207;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState handleData(byte[] bArr, int i, int i2) {
        int i3 = i2 + i;
        while (i < i3) {
            short order = this.f22201.getOrder(bArr[i]);
            if (order < 250) {
                this.f22204++;
            }
            if (order < 64) {
                this.f22205++;
                short s = this.f22209;
                if (s < 64) {
                    this.f22203++;
                    if (!this.f22208) {
                        int[] iArr = this.f22206;
                        byte precedence = this.f22201.getPrecedence((s * 64) + order);
                        iArr[precedence] = iArr[precedence] + 1;
                    } else {
                        int[] iArr2 = this.f22206;
                        byte precedence2 = this.f22201.getPrecedence((order * 64) + s);
                        iArr2[precedence2] = iArr2[precedence2] + 1;
                    }
                }
            }
            this.f22209 = order;
            i++;
        }
        if (this.f22207 == CharsetProber.ProbingState.DETECTING && this.f22203 > 1024) {
            float confidence = getConfidence();
            if (confidence > 0.95f) {
                this.f22207 = CharsetProber.ProbingState.FOUND_IT;
            } else if (confidence < 0.05f) {
                this.f22207 = CharsetProber.ProbingState.NOT_ME;
            }
        }
        return this.f22207;
    }

    public boolean keepEnglishLetters() {
        return this.f22201.getKeepEnglishLetter();
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void reset() {
        this.f22207 = CharsetProber.ProbingState.DETECTING;
        this.f22209 = (short) 255;
        for (int i = 0; i < 4; i++) {
            this.f22206[i] = 0;
        }
        this.f22203 = 0;
        this.f22204 = 0;
        this.f22205 = 0;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void setOption() {
    }

    public SingleByteCharsetProber(SequenceModel sequenceModel, boolean z, CharsetProber charsetProber) {
        this.f22201 = sequenceModel;
        this.f22208 = z;
        this.f22202 = charsetProber;
        this.f22206 = new int[4];
        reset();
    }
}
